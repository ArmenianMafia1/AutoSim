import tkinter as tk
from tkinter import *

#from nascar_sim import *

from pathlib import Path

global start_year

game_gui = Tk()

def init05():
    from gui import init2005
    game_gui.withdraw()
    init2005()

def init20():
    start_year = 2020
    print("year = 2020")
    from gui2020 import init2020
    game_gui.withdraw()
    init2020()

def init4():
    pass


def init5():
    from owner2020 import start_game
    game_gui.withdraw()
    start_game()
    pass

def init6():
    pass

def init_load():
    global start_year
    from gui import load_game
    from gui2020 import load_game2020
    from gui2020 import init2020
    from gui import init2005

    f = open("save.txt", "r")
    f2 = f.readlines()
    i = 0
    for x in f2:
        x2 = f2[i].split("~")
        loaded = int(x2[3])
    print(loaded)

    if loaded == 2020:
        load_game2020()
        init2020()
    else:
        load_game()
        init2005()
    pass

def credits():
    credits = Tk()
    myLabelc = Label(credits, text = "Lead Dev & Game Director:\n Steve H \n-----------------\nAssociate Devs:\n ArmenianWave \nJoe T AKA Racecarboy93\n----------------\nBETA Testers: \nJoe Y AKA Taquito\n Remi T")
    myLabelc.grid(row=0, column=0)


class Passwordchecker(tk.Frame):


    def __init__(self, parent):
        tk.Frame.__init__(self, parent)
        self.parent = parent
        self.initialize_user_interface()
        # year = 2005
        # week = 1


    def initialize_user_interface(self):
        global mylist

        # self.parent.maxsize(750, 550)
        self.parent.minsize(300, 120)
        self.parent.title("AutoSim BETA")

        # myButton1 = Button(root, text = "Time", command = update)
        # myButton1.grid(row=0, column=0)

        cuplabel = Label(game_gui, text="AutoSim BETA")

        cuplabel.grid(row=1, column=0, columnspan = 2)
        cuplabel.configure(anchor="center")

        s05 = Button(game_gui, text="Simulation Mode (2005)", width=20, height=2, command=init05)
        s05.grid(row=5, column=0, columnspan =1)

        s20 = Button(game_gui, text="Simulation Mode (2020)", width=20, height=2, command=init20)
        s20.grid(row=5, column=1, columnspan =1)

        o05 = Button(game_gui, text="Owner Mode (2005)", width=20, height=2, command=init4)
        o05.grid(row=6, column=0 , columnspan =1)
        o05["state"] = DISABLED

        o20 = Button(game_gui, text="Owner Mode (2020)", width=20, height=2, command=init5)
        o20.grid(row=6, column=1, columnspan=1)
        #o20["state"] = DISABLED
        '''
        dvrstats = Button(game_gui, text="Load", width=20, height=2, command=init_load)
        dvrstats.grid(row=7, column=0, columnspan=1)
        '''
        cred = Button(game_gui, text="Credits", width=20, height=2, command=credits)
        cred.grid(row=7, column=1, columnspan=1)

if __name__ == '__main__':

    run = Passwordchecker(game_gui)
    game_gui.mainloop()
