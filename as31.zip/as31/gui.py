import tkinter as tk
from tkinter import *
from nascar_sim import *
from pathlib import Path

week = 2
year = 2005


root = Tk()

global yearstring
yearstring = ""

global wrestlemania
wrestlemania = 21

global retired
retired = []

global afc
global nfc
afc = ["The New England Patriots", "The Kansas City Chiefs", "The Baltimore Ravens", "The Pittsburgh Steelers", "The Oakland Raiders", "The Indianapolis Colts", "The Cleveland Browns", "The Denver Broncos", "The San Diego Chargers", "The Tenessee Titans"]
nfc = ["The Detroit Lions", "The Green Bay Packers", "The Chicago Bears", "The Minnesota Vikings", "The New York Giants", "The New Orleans Saints", "The Washington Redskins", "The St Louis Rams", "The Arizona Cardinals", "The Philadelphia Eagles", "The Seattle Seahawks"]
east = ["The New Jersey Nets", "The Detroit Pistons", "The Cleveland Caveliers", "The Boston Celtics", "The Toronto Raptors", "The Chicago Bulls", "The Milwaukee Bucks", "The Miami Heat"]
west = ["The Denver Nuggets", "The Utah Jazz", "The LA Lakers", "The LA Clippers", "The Golden State Warriors", "The San Antonio Spurs", "The Dallas Mavericks", "The Houston Rockets" ]
global mylist1

mylist1 = []

global cities
global newnames
cities = ["Detroit", "Las Vegas", "New York", "Texas", "Michigan", "Toldeo", "West Virginia", "Charlotte", "London", "Mexico City", "Quebec", "Montreal", "Las Vegas", "Portland", "San Antonio", "Orlando"]

newnames = ["Firehawks", "Triangles", "Warriors", "Knights", "Panthers", "Cubs", "Cougars", "Aztecs", "Tigers", "Thunderbolts", "Mavericks", "Lions", "SuperSonics", "Nomads", "Apollo's", "Nationals"]


global president
president = ["George Bush", "Republican"]
president_yr = 6

global schedule
schedule = [["1", "Daytona" , "N/A"],  ["2", "Fontana" , "N/A"], ["3", "Las Vegas" , "N/A"], ["4", "Atlanta" , "N/A"], ["5", "Bristol", "N/A"],
            ["6", "Martinsville", "N/A"], ["7", "Texas" , "N/A"],  ["8", "Phoenix" , "N/A"], ["9", "Talladega" , "N/A"], ["10", "Darlington" , "N/A"], ["11", "Richmond" , "N/A"],
            ["12", "Charlotte", "N/A"], ["13", "Dover", "N/A"], ["14", "Pocono" , "N/A"],  ["15", "Michigan" , "N/A"], ["16", "Sonoma" , "N/A"], ["17", "Daytona", "N/A"],
            ["18", "Chicagoland" , "N/A"], ["19", "New Hampshire", "N/A"], ["20", "Pocono" , "N/A"],  ["21", "Indianapolis" , "N/A"], ["22", "Watkins Glen" , "N/A"], ["23", "Michigan", "N/A"],
            ["24", "Bristol" , "N/A"], ["25", "Fontana", "N/A"], ["26", "Richmond" , "N/A"],  ["27", "New Hampshire" , "N/A"], ["28", "Dover" , "N/A"], ["29", "Talladega", "N/A"],
            ["30", "Kansas" , "N/A"], ["31", "Charlotte", "N/A"], ["32", "Martinsville" , "N/A"],  ["33", "Atlanta" , "N/A"], ["34", "Texas" , "N/A"], ["35", "Phoenix", "N/A"],
            ["36", "Homestead", "N/A"]]

global cup

cup = "Nextel Cup Series"

global freeagentlist
freeagentlist = [FreeAgent0, FreeAgent1, FreeAgent2, FreeAgent3, FreeAgent4, FreeAgent5, FreeAgent6, FreeAgent7, FreeAgent8,
                 FreeAgent9, FreeAgent10, FreeAgent11, FreeAgent12, FreeAgent13, FreeAgent14, FreeAgent15, FreeAgent16,
                 FreeAgent17, FreeAgent18, FreeAgent19, FreeAgent20, FreeAgent21, FreeAgent22, FreeAgent23, FreeAgent24,
                 FreeAgent25, FreeAgent26, FreeAgent27, FreeAgent28, FreeAgent29, FreeAgent30, FreeAgent31, FreeAgent32,
                 FreeAgent33, FreeAgent34, FreeAgent35, FreeAgent36, FreeAgent37, FreeAgent38, FreeAgent39, FreeAgent40,
                 FreeAgent41, FreeAgent42, FreeAgent43, FreeAgent44, FreeAgent45, FreeAgent47, FreeAgent48,
                 FreeAgent49, FreeAgent50, FreeAgent51, FreeAgent52, FreeAgent53, FreeAgent54, FreeAgent55,
                 FreeAgent57, FreeAgent58, FreeAgent59, FreeAgent60, FreeAgent61, FreeAgent62, FreeAgent63,
                 FreeAgent64, FreeAgent65, FreeAgent66, FreeAgent67, FreeAgentC1, FreeAgentC2,
                 FreeAgentC3,
                 FreeAgentC4, FreeAgentC5, FreeAgentC6, FreeAgentC7, FreeAgentC8, FreeAgentC9, FreeAgentC10, FreeAgentC11,
                 FreeAgentC12, FreeAgentC13, FreeAgentC14, FreeAgentC15, FreeAgentC16, FreeAgentC17, FreeAgentC18, FreeAgentC19,
                 FreeAgentC20, FreeAgentC21, FreeAgentC22, FreeAgentC23, FreeAgentC24, FreeAgentC25, FreeAgentC26, FreeAgentC27,
                 FreeAgentC28, FreeAgentC29, FreeAgentC30, FreeAgentC31, FreeAgentC32, FreeAgentC33, FreeAgentC34,
                 FreeAgentC35,FreeAgentC36, FreeAgentC37, FreeAgentC38, FreeAgentC39, FreeAgentC40]


global sponsorlist
global sponsorlist
sponsorlist = ["Arby's", "Adidas", "Amrock", "AMP Energy", "AC Delco", "Burger King", "Bass Pro Shops", "Coca Cola", "Coke Zero", "Champion Apparel",
               "Craftsman", "Duracell", "Energizer", "GEICO", "Grey Goose", "Great Clips", "Jet's Pizza", "Keystone Light", "Little Ceaser's", "Lifelock", "Nike", "Mixwell",
               "New Amsterdam", "Monster Energy", "Quicken Loans", "Pizza Hut", "Pepsi", "Purell", "Ragu", "TJ Maxx", "Stanley Tools", "Steak-Umm",
               "Sportclips", "Menards", "White Claw", "LegalizeMarijuanaNOW.com", "Visteon", "Visa", "Zaxby's",  "racingreference.com", "Funai", "corvetteparts.com", "Hickory Farms",
                "Hull Kogan's", "DC Solar", "100% Electronica", "Reese's", "Action Replay", "Supercuts", "Whelen Engineering", "Rockwell Automation", "Shop-Vac", "Frank's Red Hot", "IGN", "Machinima",
               "Stacker2", "DEX Imaging", "Yard-Man", "Mammoth Video", "Siemens", "Oreo", "Best Buy", "Pedigree", "Crest", "John Deere", "Head & Shoulders", "IMAX", "Corsair", "ASE", "eBay", "Lucky 7 Casino", "Harrah's", "Motor Burger" ]


global champions
champions = {}
champions[2000] = "#18 Bobby Labonte - Joe Gibbs Racing"
champions[2001] = "#24 Jeff Gordon - Hendrick Motorsports"
champions[2002] = "#20 Tony Stewart - Joe Gibbs Racing"
champions[2003] = "#17 Matt Kenseth - Roush Racing"
champions[2004] = "#97 Kurt Busch - Roush Racing"

global daytona
daytona = {}
daytona[2000] = "#88 Dale Jarrett - Roush Racing"
daytona[2001] = "#15 Michael Waltrip - Dale Earnhardt Inc"
daytona[2002] = "#22 Ward Burton - Bill Davis Racing"
daytona[2003] = "#15 Michael Waltrip - Dale Earnhardt Inc"
daytona[2004] = "#8 Dale Earnhardt Jr - Dale Earnhardt Inc"

global toptwenty
toptwenty = []

global mylist
mylist = {}
mylist = {"00", "01", "07", "08", "09", "0", "1", "2", "4", "5", "6", "7", "8", "9", "10", "11", "12", "14", "15",
          "16", "17", "18",
          "19", "20", "21", "22", "24", "25", "29", "31", "32", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45",
          "48", "49", "50", "55", "66", "77", "88", "89", "91", "97", "99"}

global mylist_real
mylist_real = []
for i in mylist:
    mylist_real.append(i)

global mylist_inactive
mylist_inactive = {"3", "33", "34", "47", "78", "83", "84", "93", "96", "100"}


def gui_order(finish, randomcar):
    if randomcar == "0":
        return Driver0.gui_displayMedium()
    elif randomcar == "00":
        return Driver00.gui_displayMedium()
    elif randomcar == "01":
        return Driver01.gui_displayMedium()
    elif randomcar == "07":
        return Driver07.gui_displayMedium()
    elif randomcar == "08":
        return Driver08.gui_displayMedium()
    elif randomcar == "09":
        return Driver09.gui_displayMedium()
    elif randomcar == "1":
        return Driver1.gui_displayMedium()
    elif randomcar == "2":
        return Driver2.gui_displayMedium()
    elif randomcar == "3":
        return Driver3.gui_displayMedium()
    elif randomcar == "4":
        return Driver4.gui_displayMedium()
    elif randomcar == "5":
        return Driver5.gui_displayMedium()
    elif randomcar == "6":
        return Driver6.gui_displayMedium()
    elif randomcar == "7":
        return Driver7.gui_displayMedium()
    elif randomcar == "8":
        return Driver8.gui_displayMedium()
    elif randomcar == "9":
        return Driver9.gui_displayMedium()
    elif randomcar == "10":
        return Driver10.gui_displayMedium()
    elif randomcar == "11":
        return Driver11.gui_displayMedium()
    elif randomcar == "12":
        return Driver12.gui_displayMedium()
    elif randomcar == "14":
        return Driver14.gui_displayMedium()
    elif randomcar == "15":
        return Driver15.gui_displayMedium()
    elif randomcar == "16":
        return Driver16.gui_displayMedium()
    elif randomcar == "17":
        return Driver17.gui_displayMedium()
    elif randomcar == "18":
        return Driver18.gui_displayMedium()
    elif randomcar == "19":
        return Driver19.gui_displayMedium()
    elif randomcar == "20":
        return Driver20.gui_displayMedium()
    elif randomcar == "21":
        return Driver21.gui_displayMedium()
    elif randomcar == "22":
        return Driver22.gui_displayMedium()
    elif randomcar == "24":
        return Driver24.gui_displayMedium()
    elif randomcar == "25":
        return Driver25.gui_displayMedium()
    elif randomcar == "29":
        return Driver29.gui_displayMedium()
    elif randomcar == "31":
        return Driver31.gui_displayMedium()
    elif randomcar == "32":
        return Driver32.gui_displayMedium()
    elif randomcar == "33":
        return Driver33.gui_displayMedium()
    elif randomcar == "34":
        return Driver34.gui_displayMedium()
    elif randomcar == "36":
        return Driver36.gui_displayMedium()
    elif randomcar == "37":
        return Driver37.gui_displayMedium()
    elif randomcar == "38":
        return Driver38.gui_displayMedium()
    elif randomcar == "39":
        return Driver39.gui_displayMedium()
    elif randomcar == "40":
        return Driver40.gui_displayMedium()
    elif randomcar == "41":
        return Driver41.gui_displayMedium()
    elif randomcar == "42":
        return Driver42.gui_displayMedium()
    elif randomcar == "43":
        return Driver43.gui_displayMedium()
    elif randomcar == "44":
        return Driver44.gui_displayMedium()
    elif randomcar == "45":
        return Driver45.gui_displayMedium()
    elif randomcar == "46":
        return Driver46.gui_displayMedium()
    elif randomcar == "47":
        return Driver47.gui_displayMedium()
    elif randomcar == "48":
        return Driver48.gui_displayMedium()
    elif randomcar == "49":
        return Driver49.gui_displayMedium()
    elif randomcar == "50":
        return Driver50.gui_displayMedium()
    elif randomcar == "55":
        return Driver55.gui_displayMedium()
    elif randomcar == "66":
        return Driver66.gui_displayMedium()
    elif randomcar == "77":
        return Driver77.gui_displayMedium()
    elif randomcar == "78":
        return Driver78.gui_displayMedium()
    elif randomcar == "83":
        return Driver83.gui_displayMedium()
    elif randomcar == "84":
        return Driver84.gui_displayMedium()
    elif randomcar == "88":
        return Driver88.gui_displayMedium()
    elif randomcar == "89":
        return Driver89.gui_displayMedium()
    elif randomcar == "91":
        return Driver91.gui_displayMedium()
    elif randomcar == "93":
        return Driver93.gui_displayMedium()
    elif randomcar == "96":
        return Driver96.gui_displayMedium()
    elif randomcar == "97":
        return Driver97.gui_displayMedium()
    elif randomcar == "99":
        return Driver99.gui_displayMedium()
    else:
        pass


def save_game(): #ADD SAVE FREE AGENT LIST
    if Path("save.txt").is_file():
        file = open("save.txt", "r+")
        file.truncate(0)
        file.close()
    if Path("save_a.txt").is_file():
        file = open("save_a.txt", "r+")
        file.truncate(0)
        file.close()
    if Path("save_b.txt").is_file():
        file = open("save_b.txt", "r+")
        file.truncate(0)
        file.close()
    if Path("save_c.txt").is_file():
        file1 = open("save_c.txt", "r+")
        file1.truncate(0)
        file1.close()
    if Path("save_d.txt").is_file():
        file1 = open("save_d.txt", "r+")
        file1.truncate(0)
        file1.close()
    if Path("save_fa.txt").is_file():
        file1 = open("save_fa.txt", "r+")
        file1.truncate(0)
        file1.close()
    if Path("save_misc.txt").is_file():
        file1 = open("save_misc.txt", "r+")
        file1.truncate(0)
        file1.close()

    if Path("save_s.txt").is_file():
        file1 = open("save_s.txt", "r+")
        file1.truncate(0)
        file1.close()



    global week
    global year
    global cup
    global mylist

    global champions
    global mylist_inactive

    f = open("save_a.txt", "w+")
    z = 0
    for i in mylist:
        if z == 0:
            f.write(i)
        else:
            f.write("~" + i)
        z+=1
    f.close()
    f = open("save_b.txt", "w+")
    z=0
    for i in mylist_inactive:
        if z == 0:
            f.write(i)
        else:
            f.write("~" + i)
        z += 1
    f.close()
    f = open("save.txt", "w+")
    TEMP1 = []
    '''
    for i in mylist:
        car = assign(i)

        if car:
            if str(car.dvr.name) not in TEMP1 and str(car.dvr.name) != "N/A":
                TEMP1.append(str(car.dvr.name))

            else:
                fix = Driver()
                fix.name = namegenerator()
                fix.age = 32
                fix.rating = 60
                car.dvr = fix

            f.write(str(car.num1) + "~" + str(car.dvr.name) + "~" + str(car.dvr.age) + "~" + str(
                car.dvr.rating) + "~" + str(car.prestige) + "~" + str(car.dvr.t) + "~" + str(car.dvr.totalwins) +
                    "~" + str(car.dvr.totaltopfives) + "~" + str(car.dvr.totaltoptens) + "~" + str(
                car.sponsor) + "~" + str(car.team1) + "~" +
                    str(car.dvr.pts) + "~" + str(car.dvr.wins) + "~" + str(car.dvr.topfives) + "~" + str(
                car.dvr.toptens) + "~" +
                    str(car.dvr.races) + "~" + str(car.dvr.morale) + "~" + str(car.active) + "~" + "\n")
    '''
    f = open("save.txt", "a+")
    f.write(cup + "~" + str(week) + "~" + str(year) + "~" + "\n")
    for i in mylist:
        car = assign(i)
        if car:
            f.write(str(car.num1) + "~" + str(car.dvr.name) + "~" + str(car.dvr.age) + "~" + str(
                        car.dvr.rating) + "~" + str(car.prestige) + "~" + str(car.dvr.t) + "~" + str(car.dvr.totalwins) +
                            "~" + str(car.dvr.totaltopfives) + "~" + str(car.dvr.totaltoptens) + "~" + str(
                        car.sponsor) + "~" + str(car.team1) + "~" +
                            str(car.dvr.pts) + "~" + str(car.dvr.wins) + "~" + str(car.dvr.topfives) + "~" + str(
                        car.dvr.toptens) + "~" +
                            str(car.dvr.races) + "~" + str(car.dvr.morale) + "~" + str(car.active) + "~" + "\n")
    f.close()

    f1 = open("save_d.txt", "a+")
    z = 0
    global daytona
    global champions
    z = 0

    for i in range(abs(len(daytona)), 0, -1):
        print("I IS", i)

        f1.write(str(2000+z) + "~" + daytona[2000 + z] + "~" + "\n")
        z += 1
    f1.close()
    f2 = open("save_c.txt", "a+")
    z=0
    for i in range(abs(len(champions)),0, -1):
        print("i is", i)
        #print("suck it", str(year - 5 + z), champions[year-5+ z])
        f2.write(str(2000+z)+"~"+champions[2000+ z]+ "~" +"\n")
        z+=1

    f2.close()
    f3 = open("save_misc.txt", "a+")
    z = 0
    global wrestlemania
    f3.write(str(wrestlemania))
    f3.write("\n")

    for r in retired:
        print(r)
        f3.write(r[0]+"~"+r[1]+"~"+r[2]+"~"+r[3]+"~"+r[4]+"~"+r[5]+"~"+"\n")
        #f3.write(str(r[0])+"~"+str(r[1])+"~"+str(r[2])+"~"+str(r[3])+"~"+str(r[4]))+"~"+str(r[5])+"\n"
        z+=1
    f3.close()
    f4 = open("save_fa.txt", "a+")
    z = 0
    global freeagentlist
    for fa in freeagentlist:
        print(fa.dvr.name)
        f4.write(str(fa.dvr.name) + "~" + str(fa.dvr.age) + "~" + str(fa.dvr.rating) + "~" + "\n")

    f4.close()

    f5 = open("save_s.txt", "a+")
    z = 0
    global schedule
    for fa in schedule:
        print(fa, "sched")
        f5.write(fa[0] + "~" + fa[1] + "~" + fa[2] + "~" + "\n")

    f5.close()


def load_game():
    global week
    global year
    global cup
    global champions
    global daytona
    global wrestlemania
    champions = {}
    daytona = {}
    global mylist
    global mylist1
    global mylist_inactive
    mylist = set()
    mylist_inactive = set()
    f = open("save.txt", "r")
    f1 = f.readlines()
    print(f1, "e")
    i=0
    temp = year
    for x in f1:
        if i == 0:
            print(f1[i], "!!!!")
            x2 = f1[i].split("~")
            cup = x2[0]
            week = int(x2[1])
            year = int(x2[2])

        else:
            print("loaded!")
            print(f1[i], "!!!!")
            x2 = f1[i].split("~")
            #x3 = x2.split("~")
            print("EEEEEEEe", (x2))
            car = assign(x2[0])
            if car:
                print("car.dv", car.dvr.name)
                car.dvr.name = x2[1]
                car.dvr.age = int(x2[2])
                car.dvr.rating = float(x2[3])
                car.prestige = float(x2[4])
                car.dvr.t = int(x2[5])
                car.dvr.totalwins = int(x2[6])
                print("total wins", x2[6])
                car.dvr.totaltopfives = int(x2[7])
                car.dvr.totaltoptens = int(x2[8])
                car.sponsor = x2[9]
                car.team1 = x2[10]
                car.dvr.pts = int(x2[11])
                car.dvr.wins = int(x2[12])
                car.dvr.topfives = int(x2[13])
                car.dvr.toptens = int(x2[14])
                car.dvr.races = int(x2[15])
                car.dvr.morale = int(x2[16])
                car.active = x2[17]
        i += 1

    f.close()
    f2 = open("save_a.txt", "r")
    f7 = f2.readlines()
    print(f7)
    i = 0
    test = f7[0].split("~")
    print(test)
    for car in test:
        if assign(car):
            print(car, "FUCKSHITBITCH")
            mylist.add(car)

    f2.close()
    f = open("save_b.txt", "r")
    f7 = f.readlines()
    print
    test = f7[0].split("~")
    print(test)
    for car in test:
        mylist_inactive.add(car)

    f.close()
    fc = open("save_c.txt", "r")
    fc1 = fc.readlines()
    i = 0
    val = year-2000
    for x in fc1:

        xc = fc1[i].split("~")
        print(xc, "poo")
        champions[int(xc[0])] = xc[1]
        i+=1

    fc.close()
    fd = open("save_d.txt", "r")
    fd1 = fd.readlines()
    i=0
    for x in fd1:
        xd = fd1[i].split("~")
        daytona[int(xd[0])] = xd[1]
        i+=1
    fd.close()

    fe = open("save_misc.txt", "r")
    fe1 = fe.readlines()
    i = 0
    global retired
    retired = []
    #retired = List()
    for x in fe1:
        if i == 0:
            xd = fe1[i].split("~")
            wrestlemania = int(xd[0])
        else:
            xd = x.split("~")
            print(xd)
            lst1 = [xd[0], xd[1], xd[2], xd[3],xd[4], xd[5]]
            retired.append(lst1)
        i+=1
    fe.close()
    global freeagentlist
    freeagentlist = []
    ff = open("save_fa.txt", "r")
    ff1 = ff.readlines()
    i = 0
    for x in ff1:
        xd = x.split("~")
        d = Driver()
        d.name = xd[0]
        print("d.name, ", d.name)
        d.age = int(xd[1])
        d.rating = float(xd[2])
        freeagentlist.append(Team(dvr=d))
    ff.close()
    global schedule
    schedule = []
    fs = open("save_s.txt", "r")
    ff1 = fs.readlines()
    i = 0
    for x in ff1:
        xd = x.split("~")
        lst = []
        lst = [xd[0], xd[1], xd[2]]

        schedule.append(lst)
    fs.close()


def calculate_progression(i, carvalue):
    if i == 1 or i == 2:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            if i == 1:
                carvalue.dvr.morale += 10
            if i == 2:
                carvalue.dvr.morale += 5
        if carvalue.dvr.rating > 90 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            if i == 1:
                carvalue.dvr.morale += 12
            if i == 2:
                carvalue.dvr.morale += 6
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 90:
            carvalue.dvr.rating += 2
            carvalue.prestige += 2
            if i == 1:
                carvalue.dvr.morale += 14
            if i == 2:
                carvalue.dvr.morale += 7
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating += 3
            carvalue.prestige += 3
            if i == 1:
                carvalue.dvr.morale += 15
            if i == 2:
                carvalue.dvr.morale += 10
        if carvalue.dvr.rating <= 70:
            carvalue.dvr.rating += 4
            carvalue.prestige += 4
            if i == 1:
                carvalue.dvr.morale += 20
            if i == 2:
                carvalue.dvr.morale += 15

    if i > 3 and i <= 5:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.rating += .5
            carvalue.prestige += .5
            carvalue.dvr.morale += 5
        if carvalue.dvr.rating > 90 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            carvalue.dvr.morale += 6
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 90:
            carvalue.dvr.rating += 2
            carvalue.prestige += 2
            carvalue.dvr.morale += 7
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating += 2.5
            carvalue.prestige += 2.5
            carvalue.dvr.morale += 8
        if carvalue.dvr.rating <= 70:
            carvalue.dvr.rating += 2.5
            carvalue.prestige += 2.5
            carvalue.dvr.morale += 10

    if i > 5 and i <= 10:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.morale += 2
        if carvalue.dvr.rating > 90 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating += .5
            carvalue.prestige += .5
            carvalue.dvr.morale += 3
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 90:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            carvalue.dvr.morale += 4
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating += 1.5
            carvalue.prestige += 1.5
            carvalue.dvr.morale += 5
        if carvalue.dvr.rating <= 70:
            carvalue.dvr.rating += 1.5
            carvalue.prestige += 1.5
            carvalue.dvr.morale += 7

    if i > 10 and i <= 20:
        if carvalue.dvr.rating > 85 and carvalue.dvr.rating <= 95:
            carvalue.dvr.morale += 1
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 85:
            carvalue.dvr.rating += .5
            carvalue.prestige += .5
            carvalue.dvr.morale += 2
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            carvalue.dvr.morale += 3
        if carvalue.dvr.rating <= 70:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            carvalue.dvr.morale += 5

    if i > 20 and i <= 30:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.rating -= 1
            carvalue.prestige -= 1
            carvalue.dvr.morale -= 2
        if carvalue.dvr.rating > 85 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating -= .5
            carvalue.prestige -= .5
            carvalue.dvr.morale -= 1

    if i > 30 and i <= 36:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.rating -= 2
            carvalue.prestige -= 2
            carvalue.dvr.morale -= 7
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating -= 1
            carvalue.prestige -= 1
            carvalue.dvr.morale -= 5
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating -= .5
            carvalue.prestige -= .5
            carvalue.dvr.morale -= 3

    if i > 36:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.rating -= 3
            carvalue.prestige -= 3
            carvalue.dvr.morale -= 10
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating -= 2
            carvalue.prestige -= 2
            carvalue.dvr.morale -= 8
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating -= 1
            carvalue.prestige -= 1
            carvalue.dvr.morale -= 7
        if carvalue.dvr.rating <= 70:
            carvalue.dvr.morale -= 5

    if carvalue.dvr.rating > 100:
        carvalue.dvr.rating = 100
    if carvalue.prestige > 100:
        carvalue.prestige = 100
    if carvalue.dvr.morale > 100:
        carvalue.dvr.morale = 100

    if carvalue.dvr.rating < 0:
        carvalue.dvr.rating = 0
    if carvalue.prestige < 0:
        carvalue.prestige = 0
    if carvalue.dvr.morale < 0:
        carvalue.dvr.morale = 0


def gui_race(racelistbox=None, racelistbox2=None):
    global week
    i = 0
    odds = []
    for o in range(1, 101):
        odds.append(o)

    TEMP1=[]
    global mylist
    for i in mylist:
        car = assign(i)

        if car:
            if str(car.dvr.name) not in TEMP1 and str(car.dvr.name) != "N/A":
                TEMP1.append(str(car.dvr.name))

            else:
                fix = Driver()
                fix.name = namegenerator()
                fix.age = 32
                fix.rating = 60
                car.dvr = fix

    ratings = {}
    elite = []
    upperpack = []
    midpack = []
    lowpack = []
    startandpark = []
    parttime = []
    deepparttime = []
    temp = ""
    crashed = []
    crashed2 = []
    winner = None
    toptwelve = []

    for i in mylist:
        car = assign(i)
        if car and car.parttime is False and car.deepparttime is False:
            ratings[i] = ((car.dvr.rating + car.prestige) / 2)
        if car and car.parttime:
            parttime.append(i)
        if car and car.deepparttime:
            deepparttime.append(i)
        if car and car.dvr.name == "N/A":
            car.dvr.name = namegenerator()

    global year

    if year < 2006 and week < 11:
        elite = ["6", "8", "12", "17", "20", "24", "29", "48", "97"]
        upperpack = ["2", "5", "9", "16", "38", "42", "99"]
        midpack = ["01", "15", "18", "19", "25", "31", "40", "88"]
        lowpack = ["07", "0", "10", "11", "21", "22", "41", "43", "77"]
        startandpark = ["4", "7", "32", "45", "49"]
        parttime = ["09", "14", "36", "37", "44", "50", "66", "91"]
        deepparttime = ["00", "08", "1", "39", "55", "89"]

    else:

        ratings_sorted = sorted(ratings, key=ratings.get, reverse=True)
        for i in range(len(ratings_sorted)):
            if i <= 8:
                # print("elite, ", ratings_sorted[i])
                elite.append(str(ratings_sorted[i]))
            if i > 8 and i <= 16:
                # print("upper, ", ratings_sorted[i])
                upperpack.append(str(ratings_sorted[i]))
            if i > 17 and i <= 25:
                # print("mid, ", ratings_sorted[i])
                midpack.append(str(ratings_sorted[i]))
            if i > 26 and i <= 34:
                # print("low, ", ratings_sorted[i])
                lowpack.append(str(ratings_sorted[i]))
            if i > 35:
                # print("s&p, ", ratings_sorted[i])
                startandpark.append((str(ratings_sorted[i])))

        for i in mylist:

            if i not in elite and i not in upperpack and i not in midpack and i not in lowpack and i not in startandpark:
                car = assign(i)
                if i == Driver83:
                    print("APPENDED")
                    upperpack.append(Driver83)
                else:
                    if car and car.parttime is False and car.deepparttime is False:
                        if car.prestige > 80:
                            upperpack.append(i)
                        if car.prestige <= 80 and car.prestige > 70:
                            midpack.append(i)
                        if car.prestige <= 70 and car.prestige > 60:
                            startandpark.append(i)
                        if car.prestige <= 60:
                            parttime.append(i)

    '''
    elite = ["6", "8", "12", "17", "20", "24", "29", "48", "97"]
    upperpack = ["2", "5", "9", "16", "38", "99"]
    midpack = ["01", "15", "18", "19", "25", "31", "40", "42", "88"]
    lowpack = ["07", "0", "10", "11", "21", "22", "41", "43", "77"]
    startandpark = ["4", "7", "32", "45", "49"]
    parttime = ["09", "14", "36", "37", "44", "50", "66", "91"]
    deepparttime = ["00", "08", "1", "39", "55", "89"]
    '''
    tempsum = len(elite) + len(upperpack) + len(midpack)
    tempcount = 0
    if week < 2:
        global toptwenty
        toptwenty = []
    global schedule
    for i in range(1, 44):
        if i < 26:
            if len(elite) > 0:
                val = odds.pop(random.randrange(len(odds)))
                if val >= 40:
                    randomcar = elite.pop(random.randrange(len(elite)))
                if val >= 20 and val < 40:
                    if len(upperpack) > 0:
                        randomcar = upperpack.pop(random.randrange(len(upperpack)))
                    else:
                        randomcar = elite.pop(random.randrange(len(elite)))

                if val >= 5 and val < 20:
                    if len(midpack) > 0:
                        randomcar = midpack.pop(random.randrange(len(midpack)))
                    else:
                        if len(upperpack) > 0:
                            randomcar = upperpack.pop(random.randrange(len(upperpack)))
                        else:
                            randomcar = elite.pop(random.randrange(len(elite)))

                if val < 5:
                    if len(lowpack) > 0:
                        randomcar = lowpack.pop(random.randrange(len(lowpack)))
                    else:
                        if len(midpack) > 0:
                            randomcar = midpack.pop(random.randrange(len(midpack)))
                        else:
                            if len(upperpack) > 0:
                                randomcar = upperpack.pop(random.randrange(len(upperpack)))
                            else:
                                randomcar = elite.pop(random.randrange(len(elite)))

            else:

                if len(upperpack) > 0:
                    randomcar = upperpack.pop(random.randrange(len(upperpack)))
                else:
                    if len(midpack) > 0:
                        randomcar = midpack.pop(random.randrange(len(midpack)))
                    else:
                        if len(parttime) > 0:
                            randomcar = parttime.pop(random.randrange(len(parttime)))
                        else:
                            if len(lowpack) > 0:
                                randomcar = lowpack.pop(random.randrange(len(lowpack)))
                            else:
                                if len(deepparttime) > 0:
                                    randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                else:
                                    randomcar = None

        if i >= 26:
            if len(lowpack) > 0:
                val = odds.pop(random.randrange(len(odds)))
                if val >= 30:
                    randomcar = lowpack.pop(random.randrange(len(lowpack)))
                else:
                    if len(startandpark) > 0:
                        randomcar = startandpark.pop(random.randrange(len(startandpark)))
                    else:
                        if len(lowpack) > 0:
                            randomcar = lowpack.pop(random.randrange(len(lowpack)))
                        else:
                            if len(startandpark) > 0:
                                randomcar = startandpark.pop(random.randrange(len(startandpark)))
                            else:
                                if len(deepparttime) > 0:
                                    randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                else:
                                    randomcar = None
            else:
                if len(startandpark) > 0:
                    randomcar = startandpark.pop(random.randrange(len(startandpark)))
                else:
                    if len(upperpack) > 0:
                        randomcar = upperpack.pop(random.randrange(len(upperpack)))
                    else:
                        if len(midpack) > 0:
                            randomcar = midpack.pop(random.randrange(len(midpack)))
                        else:
                            if len(lowpack) > 0:
                                randomcar = lowpack.pop(random.randrange(len(lowpack)))
                            else:
                                if len(elite) > 0:
                                    randomcar = elite.pop(random.randrange(len(elite)))
                                else:
                                    if val > 40:
                                        if len(parttime) > 0:
                                            randomcar = parttime.pop(random.randrange(len(parttime)))
                                        else:
                                            if len(deepparttime) > 0:
                                                randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                            else:
                                                randomcar = None
                                    else:
                                        if len(deepparttime) > 0:
                                            randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                        else:
                                            if len(parttime) > 0:
                                                randomcar = parttime.pop(random.randrange(len(parttime)))
                                            else:
                                                randomcar = None

        carvalue = assign(randomcar)


        if carvalue:
            if i < 12:
                toptwelve.append(randomcar)
            if i == 1:
                print(randomcar, "winner is")
                if year == 2005:
                    if week != 37:
                        schedule[week-2][2] = "#" + str(carvalue.num1) + " " + carvalue.dvr.name
                    if week == 36:
                        schedule[35][2] = "#" + str(carvalue.num1) + " " + carvalue.dvr.name
                else:
                    schedule[week - 1][2] = "#" + str(carvalue.num1) + " " + carvalue.dvr.name
                carvalue.dvr.pts += 180
                carvalue.dvr.wins += 1
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totalwins += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1
                winner = carvalue
                print("winner is", winner.dvr.name)
                print("the week is, ", week)
                global daytona
                if week == 2 and year == 2005:
                    print("true! daytoan 500")

                    temp = "#"
                    temp += str(carvalue.num1) + " " + carvalue.dvr.name + " - " + carvalue.team1
                    daytona[year] = temp
                    print(daytona)
                if week == 1 and year != 2005:
                    print("true! daytoan 500")

                    temp = "#"
                    temp += str(carvalue.num1) + " " + carvalue.dvr.name + " - " + carvalue.team1
                    daytona[year] = temp
                    print(daytona)

            if (i >= 2) and (i < 6):
                carvalue.dvr.pts += 175 - (5 * (i - 1))
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1

            if i == 6:
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1
                carvalue.dvr.pts += 175 - (5 * (i - 1))

            if i == 7:
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1
                carvalue.dvr.pts += 175 - (5 * (i - 1)) + 1

            if (i > 7) and (i < 11):
                carvalue.dvr.pts += 175 - (5 * (i - 1)) + 3
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltoptens += 1

            if (i >= 11) and (i < 21):
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))
            if i >= 21 and i < 30:
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))

            if i >= 30:
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))
                if carvalue.prestige > 80:
                    crashed.append(carvalue)

            if i >= 37:
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))
                if carvalue not in crashed:
                    crashed2.append(carvalue)

            carvalue.dvr.races += 1
            carvalue.dvr.totalraces += 1
            carvalue.dvr.finishes.append(i)

            total = 0
            for p in carvalue.dvr.finishes:
                total += p
            carvalue.dvr.avgfinish = total / carvalue.dvr.races

            if week == 1 or week % 3 == 0:
                calculate_progression(i, carvalue)

            if racelistbox:
                if i in [1, 21, 31, 41]:
                    racelistbox.insert(END, (
                        "{}st Place ---------------------------------------------------------------------------- ".format(
                            i)))
                elif i in [2, 12, 22, 32, 42]:
                    racelistbox.insert(END, (
                        "{}nd Place ---------------------------------------------------------------------------- ".format(
                            i)))
                elif i in [3, 13, 23, 33, 43]:
                    racelistbox.insert(END, (
                        "{}rd Place ---------------------------------------------------------------------------- ".format(
                            i)))
                else:
                    racelistbox.insert(END, (
                        "{}th Place ---------------------------------------------------------------------------- ".format(
                            i)))

            finish1 = gui_order(i, randomcar)
            if racelistbox:
                racelistbox.insert(END, (finish1))
        else:
            print("fail, ", randomcar)
    global mylist_real
    print(mylist_real, "e")
    print(winner, "jj")
    for o in range(1, 101):
        odds.append(o)

    odds2 = []
    for o in range(2, 14):
        odds2.append(o)

    odds3 = []
    for o in range(5, 16):
        odds3.append(o)
    # test = president[0]
    choice = random.choice(odds)
    print("toptwelve", toptwelve)

    mylist_real = []
    for i in mylist:
        mylist_real.append(i)

    print(mylist_real, "e")
    if racelistbox2:

        racelistbox2.insert(END, "Today's NASCAR Cup Series race was won by #" + str(winner.num1) + " " + str(
            winner.dvr.name) + ".")
        rando = assign(random.choice(toptwelve))
        rando1 = assign(mylist_real.pop(random.randrange(len(mylist_real))))
        rando2 = assign(mylist_real.pop(random.randrange(len(mylist_real))))
        print(crashed)
        print(rando.num1, "wingsofredemption")
        racelistbox2.insert(END, "#" + str(rando.num1) + " " + str(rando.dvr.name) + " led the most laps.")
        choice2 = random.choice(odds2)
        choice3 = random.choice(odds3)
        racelistbox2.insert(END, str(choice3) + " different drivers led a lap today, and there were " + str(
            choice2) + " cautions for " + str(choice2 * 3) + " laps.")
        racelistbox2.insert(END, "------------------------------------------------------------------------")
        choice = random.choice(odds)
        if choice < 9:
            racelistbox2.insert(END, "# " + str(rando1.num1) + " " + str(rando1.dvr.name) +
                                " and " + "#" + str(rando2.num1) + " " + str(rando2.dvr.name) + " got in a fight!")

        for i in crashed:
            choice = random.choice(odds)
            if choice < 50:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " was involved in a crash!")
            if choice < 50 and choice > 30:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to engine trouble!")
            if choice < 30 and choice > 22:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a blown tire!")
            if choice <= 22 and choice >= 10:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to overheating!")
            if choice < 10:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a piston failure!")
        for i in crashed2:
            choice = random.choice(odds)
            if choice > 90:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " was involved in a crash!")
            if choice > 60 and choice <= 90:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to engine trouble!")
            if choice >= 30 and choice <= 60:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a blown tire!")
            if choice < 30 and choice > 10:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to overheating!")
            if choice < 10:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a blown tire!")


def selection():
    try:
        driverWindow = tk.Toplevel(root)
        driverWindow.geometry("400x300")
        myLabel4 = Label(driverWindow, text="Driver Statistics:")
        myLabel4.grid(row=0, column=0)
    except:
        pass

def gui_schedule():
    # standings
    global schedule
    sceWindow = tk.Toplevel(root)
    sceWindow.geometry("800x250")
    # myLabel4.grid(row=0,column=0)
    racescrollbar = Scrollbar(sceWindow)
    racescrollbar.grid(row=9, column=40)

    racelistbox = Listbox(sceWindow, width=150)
    racelistbox.grid(row=9, column=50)
    for s in schedule:
        print(schedule)
        racelistbox.insert(END, "Race " + s[0] + " at " + s[1] + " | Winner : " + s[2])


def gui_standings():
    # standings
    global mylist
    raceWindow = tk.Toplevel(root)
    raceWindow.geometry("800x250")
    # myLabel4.grid(row=0,column=0)
    racescrollbar = Scrollbar(raceWindow)
    racescrollbar.grid(row=9, column=40)

    racelistbox = Listbox(raceWindow, width=150)
    racelistbox.grid(row=9, column=50)
    stg = standing(mylist)
    for i in stg.splitlines():
        racelistbox.insert(END, i)


def good_fit(dvr, team):
    print("check")
    print(team.prestige)
    print(team.team1, "team")
    print(dvr.name, "dvr112s2")
    if team.team1 == "Chip Ganassi Racing" and dvr.name == "Reed Sorenson":
        print("AAAAH COME ON")
        return True
    if team.prestige > 80 and team.team1 != "Chip Ganassi Racing":
        if dvr.rating > 80:
            return True
    if team.prestige > 70 and team.team1!= "Chip Ganassi Racing":
        if dvr.rating > 70:
            return True
    if dvr.team == team.team1:
        return True
    if dvr.dvrmanu == team.manu:
        return True
    if team.team1 == "Michael Waltrip Racing" and dvr.name == "Michael Waltrip":
        return True
    if team.team1 == "Evernham Motorsports" and dvr.name == "Paul Wolfe":
        return True
    if team.team1 == "Evernham Motorsports" and dvr.name == "Erin Crocker":
        return True
    if team.team1 == "Penske Racing" and dvr.name == "Paul Wolfe":
        return True
    if team.team1 == "Chip Ganassi Racing" and dvr.name == "Erin Crocker":
        return True
    if team.team1 == "Joe Gibbs Racing" and dvr.name == "Denny Hamlin":
        return True
    if team.team1 == "Joe Gibbs Racing" and dvr.name == "JJ Yeley":
        return True
    if team.team1 == "Dale Earnhardt Inc" and dvr.name == "Paul Menard":
        return True
    if team.team1 == "Richard Childress Racing" and dvr.name == "Paul Menard":
        return True
    if team.team1 == "Richard Childress Racing" and dvr.name == "Clint Bowyer":
        return True
    if team.team1 == "Dale Earnhardt Inc" and dvr.name == "Clint Bowyer":
        return True
    if team.team1 == "Chip Ganassi Racing" and dvr.name == "David Stremme":
        return True
    if team.team1 == "Chip Ganassi Racing" and dvr.name == "Reed Sorenson":
        return True
    if team.team1 == "Evernham Motorsports" and dvr.name == "David Stremme":
        return True
    if team.team1 == "Evernham Motorsports" and dvr.name == "Reed Sorenson":
        return True
    if team.team1 == "Penske Racing" and dvr.name == "David Stremme":
        return True
    if team.team1 == "Penske Racing" and dvr.name == "Reed Sorenson":
        return True
    if team.team1 == "Richard Childress Racing" and dvr.name == "Kerry Earnhardt":
        return True
    if team.team1 == "Dale Earnhardt Inc" and dvr.name == "Kerry Earnhardt":
        return True
    if team.team1 == "Michael Waltrip Racing" and dvr.name == "Kerry Earnhardt":
        return True
    if team.prestige > 80 and dvr.age < 26:
        return True
    return False

def good_fit2(dvr, team):
    print("check")
    print(team.prestige)
    print(team.team1, "team")
    print(dvr.name, "dvr112s2")
    if team.prestige > 80 and dvr.age < 26:
        return True
    if dvr.team == team.team1:
        return True
    if dvr.dvrmanu == team.manu:
        return True
    if team.team1 == "Michael Waltrip Racing" and dvr.name == "Michael Waltrip":
        return True
    if team.team1 == "Evernham Motorsports" and dvr.name == "Paul Wolfe":
        return True
    if team.team1 == "Evernham Motorsports" and dvr.name == "Erin Crocker":
        return True
    return False



def clean(rosterlist):
    global freeagentlist
    for d in freeagentlist:
        if d.dvr.name in rosterlist:
            freeagentlist.remove(d)
        if d.dvr.name == "N/A":
            freeagentlist.remove(d)


def president_event():
    rtn = ""
    global year
    global president
    global president_yr
    if year == 2007 or year == 2008:
        running_d = ["Barack Obama", "Joe Biden", "Hillary Clinton"]
        running_r = ["John McCain", "Mitt Romney", "Ron Paul"]
        running_3 = ["Rand Paul", "Jill Stein"]
    if year == 2011 or year == 2012:
        running_d = ["Barack Obama", "Tim Kane", "Joe Biden", "Hillary Clinton"]
        running_r = ["John McCain", "Mitt Romney", "Newt Gingrich", "Paul Ryan", "Rick Perry", "Herman Cain"]
        running_3 = ["Jill Stein", "Gary Johnson"]
    if year == 2015 or year == 2016:
        running_d = ["Tim Kane", "Joe Biden", "Hillary Clinton", "Bernie Sanders"]
        running_r = ["Donald Trump", "Mitt Romney", "Ted Cruz", "Paul Ryan", "Jeb Bush", "Chris Christie", "Ben Carson"]
        running_3 = ["Jill Stein", "Gary Johnson", "Joe Exotic"]
    if year == 2019 or year == 2020:
        running_d = ["Tim Kane", "Joe Biden", "Hillary Clinton", "Bernie Sanders", "Pete Buttigeig", "Michael Bloomberg", "Andrew Yang"]
        running_r = ["Donald Trump", "Mitt Romney", "Ted Cruz", "Paul Ryan", "Jeb Bush",
                     "Chris Christie", "Ben Carson", "Hulk Hogan", "Kanye West", "Mike Pence", "Linda McMahon"]
        running_3 = ["Jill Stein", "Gary Johnson", "Gary Oldman"]
    if year == 2023 or year == 2024:
        running_d = ["Tim Kane", "Joe Biden", "Hillary Clinton", "Bernie Sanders", "Pete Buttigeig", "Michael Bloomberg", "Andrew Yang"]
        running_r = ["Donald Trump", "Mitt Romney", "Ted Cruz", "Paul Ryan", "Jeb Bush",
                     "Chris Christie", "Ben Carson", "Hulk Hogan", "Kanye West", "Mike Pence", "Vince McMahon"]
        running_3 = ["Jill Stein", "Gary Johnson", "Gary Oldman", "Vermin Surpeme", "Dan Behrman", "Christan Weston Chandler"]
    if year > 2024:
        running_d = ["Tim Kane", "Joe Biden", "Hillary Clinton", "Pete Buttigeig", "Michael Bloomberg", "Andrew Yang", "Corey Booker", "The Rock", "Kendrick Lamar"]
        running_r = ["Donald Trump", "Mitt Romney", "Ted Cruz", "Paul Ryan", "Jeb Bush", "Eric Trump",
                     "Chris Christie", "Ben Carson", "Hulk Hogan", "Kanye West", "Mike Pence", "Linda McMahon", "George Bush III"]
        running_3 = ["Jill Stein", "Gary Johnson", "Gary Oldman", "Christan Weston Chander", "Harrison Ford", "Salman Kahn"]


    odds = []
    score = []
    loserscore = []
    for o in range(1, 101):
        odds.append(o)
    #test = president[0]
    choice = random.choice(odds)
    if president_yr > 6:
        president = []
        if choice < 46 :
            president.append(random.choice(running_d))
            president.append("Democrat")
            president_yr = 1
            rtn = "American Politics: Democrat Candidate " + president[0] + " has become President!"
        if choice >= 46 and choice < 92 :
            president.append(random.choice(running_r))
            president.append("Republican")
            president_yr = 1
            rtn = "American Politics: Republican Candidate " + president[0] + " has become President!"
        if choice >= 92:
            president.append(random.choice(running_3))
            president.append("Third Party")
            president_yr = 1
            rtn = "American Politics: Third Party Candidate " + president[0] + " has become President in a massive upset!"
    else:

        if choice < 50 and president[1] == "Democrat" or president[1] == "Third Party":
            president = []
            president.append(random.choice(running_r))
            president.append("Republican")
            president_yr = 1
            rtn = "American Politics: Republican Candidate " + president[0] + " has become President!"
        if choice < 50 and president[1] == "Republican":
            president = []
            if choice < 45:
                president.append(random.choice(running_d))
                president.append("Democrat")
                president_yr = 1
                rtn = "American Politics: Democrat Candidate " + president[0] + " has become President!"
            if choice >= 45:
                president.append(random.choice(running_3))
                president.append("Third Party")
                president_yr = 1
                rtn = "American Politics: Third Party Candidate " + president[0] + " has become President in a massive upset!"
        if choice >= 50:
            rtn = "American Politics: The Incumbent President wins the election and will have a second term in office"

    print(president, "!!!!!!!!!!!!!!!!!!!!!!!")
    return rtn



def title_event():
    global sponsorlist
    global cup
    choice = sponsorlist.pop(random.randrange(len(sponsorlist)))
    cup = choice + " Cup Series"

def superbowl_event():
    global year
    global afc
    global nfc
    global cities
    global newnames
    rtn = ""
    odds = []
    for o in range(1, 101):
        odds.append(o)

    choice1 = random.choice(odds)
    if year > 2010:

        if choice1 < 25:
            afc1 = afc.pop(random.randrange(len(afc)))
            afc2 = afc1.split()
            afc2[-1] = random.choice(newnames)
            afc1 = ""
            for s in afc2:
                afc1 += s + " "
            print(afc2, "ass2")
            afc.append(afc1)
        if choice1 >= 25 and choice1 < 50:
            nfc1 = nfc.pop(random.randrange(len(nfc)))
            nfc2 = nfc1.split()
            nfc2[-1] = random.choice(newnames)
            nfc1 = ""
            for s in nfc2:
                nfc1 += s + " "
            print(nfc2, "ass2")
            afc.append(nfc1)
        if choice1 >= 50 and choice1 < 75:
            afc1 = afc.pop(random.randrange(len(afc)))
            afc2 = afc1.split()
            afc1 = "The " + random.choice(cities) + " " + afc2[-1]
            afc.append(afc1)
        if choice1 >= 75:
            nfc1 = nfc.pop(random.randrange(len(nfc)))
            nfc2 = nfc1.split()
            afc1 = "The " + random.choice(cities) + " " + nfc2[-1]
            nfc.append(nfc1)


    afcchoice = random.choice(afc)
    nfcchoice = random.choice(nfc)
    odds = []
    score = []
    loserscore = []
    for o in range(1, 101):
        odds.append(o)
    for s in range(10, 51):
        score.append(s)
    winner = random.choice(score)
    for l in range(3, winner-1):
        loserscore.append(l)
    loser = random.choice(loserscore)
    if loser == "4" or loser == "5":
        loser = "7"
    choice = random.choice(odds)
    if choice < 50:
        rtn += "Football: " + nfcchoice + " defeated " + afcchoice + " in the Super Bowl " + str(winner) + " - " + str(loser)
        return rtn
    if choice >= 50:
        rtn += "Football: " + afcchoice + " defeated " + nfcchoice + " in the Super Bowl " + str(winner) + " - " + str(loser)
        return rtn

def nba_event():
    global year
    global east
    global west
    global cities
    global newnames
    rtn = ""
    odds = []
    for o in range(1, 101):
        odds.append(o)

    choice1 = random.choice(odds)
    if year > 2010:

        if choice1 < 25:
            afc1 = east.pop(random.randrange(len(east)))
            afc2 = afc1.split()
            afc2[-1] = random.choice(newnames)
            afc1 = ""
            for s in afc2:
                afc1 += s + " "
            print(afc2, "ass2")
            east.append(afc1)
        if choice1 >= 25 and choice1 < 50:
            nfc1 = west.pop(random.randrange(len(west)))
            nfc2 = nfc1.split()
            nfc2[-1] = random.choice(newnames)
            nfc1 = ""
            for s in nfc2:
                nfc1 += s + " "
            print(nfc2, "ass2")
            west.append(nfc1)
        if choice1 >= 50 and choice1 < 75:
            afc1 = east.pop(random.randrange(len(east)))
            afc2 = afc1.split()
            afc1 = "The " + random.choice(cities) + " " + afc2[-1]
            east.append(afc1)
        if choice1 >= 75:
            nfc1 = west.pop(random.randrange(len(west)))
            nfc2 = nfc1.split()
            afc1 = "The " + random.choice(cities) + " " + nfc2[-1]
            west.append(nfc1)


    east1 = random.choice(east)
    west1 = random.choice(west)
    odds = []
    score = []
    loserscore = []
    for o in range(1, 101):
        odds.append(o)
    choice = random.choice(odds)
    if choice < 50:
        rtn += "Basketball: " + east1 + " defeated " + west1 + " in the NBA Finals"
        return rtn
    if choice >= 50:
        rtn += "Basketball: " + west1 + " defeated " + east1 + " in the NBA Finals"
        return rtn

def wrestling_event():
    global year
    global wrestlemania
    rtn = ""
    if year > 2004 and year < 2007:
        wrestlers = ["Shawn Michaels", "Edge", "Chris Benoit", "John Cena", "Batista", "Randy Orton", "Triple H", "Mark Henry", "The Undertaker",
                     "The Big Show", "Kane", "Bobby Lashley", "Umaga", "CM Punk", "Chris Jericho", "Ric Flair", "The Rock", "Rey Mysterio", "Jeff Hardy"]
    if year >= 2007 and year < 2011:
        wrestlers = ["Shawn Michaels", "Edge", "John Cena", "Batista", "Randy Orton", "Triple H", "Mark Henry",
                     "The Undertaker", "The Great Khali",
                     "The Big Show", "Kane", "John Morrison", "Bobby Lashley", "Umaga", "CM Punk", "Chris Jericho",
                     "The Miz", "The Rock", "Rey Mysterio", "Jeff Hardy"]
    if year >= 2011 and year < 2015:
        wrestlers = ["Brock Lesnar", "Ryback", "John Cena", "Wade Barrett", "Randy Orton", "Triple H", "Mark Henry",
                     "The Undertaker", "Kane",
                     "The Big Show", "John Morrison", "CM Punk", "Chris Jericho", "The Miz", "The Rock", "Rey Mysterio", "Sheamus"]
    if year >= 2015 and year < 2022:
        wrestlers = ["AJ Styles", "Adam Cole", "Brock Lesnar", "Ryback", "Seth Rollins", "Dean Ambrose", "Roman Reigns",
                     "Daniel Bryan", "Batista", 'Goldberg', "John Cena", "Wade Barrett", "Randy Orton", "Triple H",
                     "The Undertaker", "Chris Jericho", "Samoa Joe", "Kevin Owens", "Shinsuke Nakamura", "Sting", "Bray Wyatt", "Braun Strowman",
                     "The Big Show", "Kofi Kingston", "CM Punk", "The Rock", "Sheamus"]
    if year >= 2022 and year < 2030:
        wrestlers = ["AJ Styles", "Adam Cole", "Seth Rollins", "Dean Ambrose", "Roman Reigns",
                     "Daniel Bryan", "Samoa Joe", "Shinsuke Nakamura", "Bray Wyatt", "Braun Strowman",
                    "Big E", "Kofi Kingston", "Andrade", "Drew McIntyre", "Johnny Gargano", "Tomasso Ciampa", "Austin Theory", "Kenny Omega", "Orange Cassidy"]
    if year >= 2030:
        wrestlers = ["Braun Strowman", "Xavier Woods", "Sammy Guevara", "Darby Allin", "MJF", "Ric Flair Jr", "Dominic Mysterio", "The Barbarian Jr", "Junior Mahal"
                    "Big E", "Ice Cream III", "Villano 16", "Maxel Hardy", "Cedric Alexander", "Randy Orton Jr", "Scott Speed", "Rob Gronkowski", "Grown Up Nicholas", "Andrade", "Angel Garza", "Johnny Gargano", "Tomasso Ciampa", "Austin Theory", "Orange Cassidy"]

    stip = ["Singles Match", "Singles Match", "Singles Match", "TLC Match", "Hell in a Cell Match", "Light Tubes Match", "Tournament Finale",
            "Ladder Match", "WWE vs United States Title Match", "Stairs Match", "Chairs Match", "Extreme Rules Match", "60 Minute Iron Man Match",
            "30 Minute Iron Man Match", "2/3 Falls Match", "2/3 Tables Match", "Boneyard Match", "Buried Alive Match", "2/3 Buried Alive Match", "Title vs Undefeated Streak"]

    winner = wrestlers.pop(random.randrange(len(wrestlers)))
    loser = wrestlers.pop(random.randrange(len(wrestlers)))
    match = stip.pop(random.randrange(len(stip)))
    rtn += "Wrestling: " + winner + " defeated " + loser + " in the Main Event of Wrestlemania " + str(wrestlemania) + " in a " + match
    wrestlemania += 1
    return rtn

def sponsor_event():
    global mylist
    global mylist_real
    global sponsorlist
    rtn = ""
    for i in mylist:
        mylist_real.append(i)
    if len(sponsorlist) > 0:
        choice = sponsorlist.pop(random.randrange(len(sponsorlist)))
        num = random.choice(mylist_real)
        car = assign(num)
        if car:
            print("sponsor!!!! ", choice)
            old = car.sponsor
            car.sponsor = choice
            sponsorlist.append(old)
            rtn += car.team1 + " #" + str(car.num1) + " - " + car.dvr.name + " has a new sponsor: " + choice
        return rtn


def add(num):
    global mylist
    global mylist_inactive
    global mylist_real
    print('MYLIST', mylist)
    print('MYLIST REAL', mylist)
    if num == "46":
        print("46suckmydix")
    for i in range (int(num), 100):
        if str(i+1) in mylist:
            print(str(i+1))
            if i not in mylist_real:
                index = mylist_real.index(str(i+1))
                mylist_real.insert(index, num)
            if i not in mylist:
                mylist.add(num)
                print("added this numba", num)
            if num in mylist_inactive:
                mylist_inactive.remove(num)
            print(mylist)
            return

def retirement(sillylistbox, sillyWindow):

    global schedule
    schedule = [["1", "Daytona", "N/A"], ["2", "Fontana", "N/A"], ["3", "Las Vegas", "N/A"], ["4", "Atlanta", "N/A"],
                ["5", "Bristol", "N/A"],
                ["6", "Martinsville", "N/A"], ["7", "Texas", "N/A"], ["8", "Phoenix", "N/A"], ["9", "Talladega", "N/A"],
                ["10", "Darlington", "N/A"], ["11", "Richmond", "N/A"],
                ["12", "Charlotte", "N/A"], ["13", "Dover", "N/A"], ["14", "Pocono", "N/A"], ["15", "Michigan", "N/A"],
                ["16", "Sonoma", "N/A"], ["17", "Daytona", "N/A"],
                ["18", "Chicagoland", "N/A"], ["19", "New Hampshire", "N/A"], ["20", "Pocono", "N/A"],
                ["21", "Indianapolis", "N/A"], ["22", "Watkins Glen", "N/A"], ["23", "Michigan", "N/A"],
                ["24", "Bristol", "N/A"], ["25", "Fontana", "N/A"], ["26", "Richmond", "N/A"],
                ["27", "New Hampshire", "N/A"], ["28", "Dover", "N/A"], ["29", "Talladega", "N/A"],
                ["30", "Kansas", "N/A"], ["31", "Charlotte", "N/A"], ["32", "Martinsville", "N/A"],
                ["33", "Atlanta", "N/A"], ["34", "Texas", "N/A"], ["35", "Phoenix", "N/A"],
                ["36", "Homestead", "N/A"]]

    gui_string = ""
    global year
    global freeagentlist
    global mylist
    odds = []
    for o in range(1, 101):
        odds.append(o)

    candidates = []
    rosterlist = []
    for x in mylist:
        team = assign(x)
        if team:
            rosterlist.append(team.dvr.name)

    clean(rosterlist)

    if year == 2007:
        freeagentlist.append(FreeAgent33)
        freeagentlist.append(FreeAgent56)

    for drive in freeagentlist:
        # print("FREE AGENT - ", drive.dvr.name)
        if drive.dvr.name not in rosterlist and drive not in candidates:
            # print("ok 1", drive.dvr.name)
            if drive.dvr.moveyear + 2 < year or drive.dvr.moveyear == 0:
                print("cachinga", drive.dvr.name)
                if drive.dvr.age > 24 or drive.dvr.name == "Reed Sorenson":
                    candidates.append(drive)
                    # sillylistbox.insert(END, drive.dvr.name + " is a candidate! " + str(year) + " their moveyear: " + str(drive.dvr.moveyear))

    open = []
    retirements = []
    swaps = []

    new_retirements = []


    global toptwenty
    mylist_copy = {}
    mylist_copy = mylist
    for x in mylist_copy:
        team = assign(x)
        if team:
            if team.dvr.age > 41 and team.dvr.age <= 44:
                chance = random.choice(odds)
                # print("CHANCE IS: ", chance)
                if chance < 5:
                    print(team.dvr.name, "name is")
                    open.append(team)
                    retirements.append(str(team.dvr.name))
                    temp = []
                    temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                            str(team.dvr.totaltopfives),
                            str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                    new_retirements.append(temp)

            if team.dvr.age > 45 and team.dvr.age <= 48:
                chance = random.choice(odds)
                # print("CHANCE IS: ", chance)
                if chance < 20:
                    print(team.dvr.name, "name is")
                    open.append(team)
                    retirements.append(str(team.dvr.name))
                    temp = []
                    temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                                str(team.dvr.totaltopfives),
                                str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                    new_retirements.append(temp)

            if team.dvr.age > 48 and team.dvr.age <= 51:
                chance = random.choice(odds)
                # print("CHANCE IS: ", chance)
                if chance < 40:
                    print(team.dvr.name, "name is")
                    open.append(team)
                    retirements.append(str(team.dvr.name))
                    temp = []
                    temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                            str(team.dvr.totaltopfives),
                            str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                    new_retirements.append(temp)

            if team.dvr.age > 51 and team.dvr.age <= 53:
                chance = random.choice(odds)
                # print("CHANCE IS: ", chance)
                if chance < 70:
                    print(team.dvr.name, "name is")
                    open.append(team)
                    retirements.append(str(team.dvr.name))
                    temp = []
                    temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                            str(team.dvr.totaltopfives),
                            str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                    new_retirements.append(temp)

            if team.dvr.age > 53:
                print(team.dvr.name, "name is")
                open.append(team)
                retirements.append(str(team.dvr.name))
                temp = []
                temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins), str(team.dvr.totaltopfives),
                        str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                new_retirements.append(temp)
    power_ranking = {}
    for team in freeagentlist:
        if team.dvr.age > 41 and team.dvr.age <= 44:
            chance = random.choice(odds)
            # print("CHANCE IS: ", chance)
            if chance < 5:
                print(team.dvr.name, "name is")
                #open.append(team)
                freeagentlist.remove(team)
                retirements.append(str(team.dvr.name))
                temp = []
                temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                        str(team.dvr.totaltopfives),
                        str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                new_retirements.append(temp)

        if team.dvr.age > 45 and team.dvr.age <= 48:
            chance = random.choice(odds)
            # print("CHANCE IS: ", chance)
            if chance < 20:
                print(team.dvr.name, "name is")
                retirements.append(str(team.dvr.name))
                freeagentlist.remove(team)
                temp = []
                temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                        str(team.dvr.totaltopfives),
                        str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                new_retirements.append(temp)

        if team.dvr.age > 48 and team.dvr.age <= 51:
            chance = random.choice(odds)
            # print("CHANCE IS: ", chance)
            if chance < 40:
                print(team.dvr.name, "name is")
                freeagentlist.remove(team)
                retirements.append(str(team.dvr.name))
                temp = []
                temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                        str(team.dvr.totaltopfives),
                        str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                new_retirements.append(temp)


        if team.dvr.age > 51 and team.dvr.age <= 53:
            chance = random.choice(odds)
            # print("CHANCE IS: ", chance)
            if chance < 70:
                print(team.dvr.name, "name is")
                freeagentlist.remove(team)
                retirements.append(str(team.dvr.name))
                temp = []
                temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                        str(team.dvr.totaltopfives),
                        str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                new_retirements.append(temp)

        if team.dvr.age > 53:
            print(team.dvr.name, "name is")
            freeagentlist.remove(team)
            retirements.append(str(team.dvr.name))
            temp = []
            temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins), str(team.dvr.totaltopfives),
                str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
            new_retirements.append(temp)

            # print("Safelist", toptwenty)
    ded = []
    for x in mylist_copy:
        team = assign(x)
        if team and team.dvr not in retirements:
            if team.parttime or team.deepparttime:
                chance = random.choice(odds)
                if chance >= 20 and chance < 30:
                    sillylistbox.insert(END,
                                        team.team1 + " - #" + str(team.num1) + " has moved to a full time schedule!")
                    team.parttime = False
                    team.deepparttime = False

            if str(team.num1) not in toptwenty:
                chance = random.choice(odds)
                # print("CHANCE IS: ", chance)
                if team not in open and team not in candidates and team.dvr.unsackable == False and team.dvr.moved == False:
                    if team.dvr.moveyear + 2 < year or team.dvr.moveyear == 0:
                        team.dvr.morale -= 20
                        print(chance, "chance was")
                        if chance < 15:
                            print("NOT SAFe:", team.dvr.name)
                            swaps.append(team)
                            open.append(team)
                            candidates.append(team)
                            # sillylistbox.insert(END, team.dvr.name + " has left!")
                        else:
                            print("YES SAFe:", team.dvr.name)
                        if chance >= 20 and chance < 30:
                            if team.dvr.rating < 70:
                                sillylistbox.insert(END, team.team1 + " - #" + str(
                                    team.num1) + " has moved to a part time schedule!")
                                team.parttime = True
                        global mylist1
                        if chance > 40 and chance <= 42:
                            print("DA CHANCE WAS", chance)
                            ded.append(team)

            if team.dvr not in candidates and team.dvr not in retirements:
                if drive.dvr.moveyear + 2 < year or drive.dvr.moveyear == 0:
                    if team.dvr.morale < 40 and team.dvr.morale > 0 and team.dvr.unsackable is False:
                        swaps.append(team)
                        open.append(team)
                        candidates.append(team)
                        # sillylistbox.insert(END, team.dvr.name + " has left!")

                    '''
                    if team.dvr.age < 26 and team.dvr.age > 19:
                        if team.dvr.morale < 70 and team.dvr.morale > 0:
                            chance = random.choice(odds)
                            print("CHANCE IS: ", chance)
                            if chance < 30:
                                swaps.append(team)
                                candidates.append(team)
                                sillylistbox.insert(END, team.dvr.name + " has left!")
                                if team.prestige > 60:
                                    open.append(team)
                                    print(team.num1, "shut down")
                                else:
                                    chance = random.choice(odds)
                                    print("CHANCE IS: ", chance)
                                    if chance < 90:
                                        open.append(team)
                                    else:
                                        print(team.num1, "shut down 2")
                                        temp = team.dvr
                                        FreeAgentX = Team(9999, temp)
                                        team.active = False
                        '''

                # candidates.append(team)

            # print("Candidate #", stupid, " ", z.dvr.name)
    global mylist1
    for team in ded:
        sillylistbox.insert(END, team.team1 + " - #" + str(
            team.num1) + " has shut down!")

        power_ranking[Team(dvr=team.dvr)] = team.dvr.rating
        team.active = False
        if str(team.num1) in mylist:
            mylist.remove(str(team.num1))
        if str(team.num1) in mylist_real:
            mylist_real.remove(str(team.num1))
        if str(team.num1) not in mylist_inactive:
            mylist_inactive.add(str(team.num1))


    if len(candidates) > 1:
        if year==2006:


            if Driver96.active == False:
                Driver96.active = True
                add("96")
                open.append(Driver96)
                sillylistbox.insert(END,
                                    "#" + str(Driver96.num1) + " " + Driver96.team1 + " will be joining the " + str(
                                        year) + " Cup Series!")

        if year == 2007:

            e = sponsor_event()
            f = sponsor_event()
            if e:
                sillylistbox.insert(END, e)
            if e:
                sillylistbox.insert(END, f)

            print("2007")
            sillylistbox.insert(END, "Toyota will be joining the " + str(
                year) + " Cup Series!")
            if Driver00.active:
                Driver00.manu = "Toyota"
                sillylistbox.insert(END,
                                    "#" + str(Driver00.num1) + " " + Driver00.team1 + " has moved to Toyota")
            if Driver22.active:
                Driver22.manu = "Toyota"
                sillylistbox.insert(END,
                                    "#" + str(Driver22.num1) + " " + Driver22.team1 + " has moved to Toyota")
            if Driver55.active == True:
                Driver55.team1 = "Toyota"
                Driver55.team1 = "Michael Waltrip Racing"
                sillylistbox.insert(END,
                                    "#" + str(Driver55.num1) + " " + Driver55.team1 + " has moved to Toyota")
            if Driver83.active == False:
                Driver83.active = True
                add("83")
                sillylistbox.insert(END, "#" + str(Driver83.num1) + " " + Driver83.team1 + " will be joining the " + str(
                    year) + " Cup Series!")
            if Driver84.active == False:
                Driver84.active = True
                print("yes")
                open.append(Driver84)
                add("84")
                sillylistbox.insert(END, "#" + str(Driver84.num1) + " " + Driver84.team1 + " will be joining the " + str(
                    year) + " Cup Series!")

        if year >= 2008:
            e = sponsor_event()
            if e:
                sillylistbox.insert(END, e)
            chance = random.choice(odds)
            if chance > 85:
                f = sponsor_event()
                if f:
                    sillylistbox.insert(END, f)
                g = sponsor_event()
                if g:
                    sillylistbox.insert(END, g)
            if chance < 40:
                f = sponsor_event()
                if f:
                    sillylistbox.insert(END, f)
            if year % 2 == 0 and chance < 50:
                title_event()
                sillylistbox.insert(END, "The Cup Series has a new sponsor! Its new name is The " + cup)
                cuplabel = Label(root, text=cup)
                cuplabel.grid(row=1, column=0, columnspan = 2)

            if chance < 90 and chance >= 70:
                if Driver34.active == False:
                    Driver34.active = True
                    print("yes")
                    open.append(Driver34)
                    add("34")
                    sillylistbox.insert(END,
                                        "#" + str(Driver34.num1) + " " + Driver34.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")
            if chance < 70 and chance >= 30:
                if Driver78.active == False:
                    Driver78.active = True
                    print("yes")
                    open.append(Driver78)
                    add("78")
                    open.append(Driver78)
                    sillylistbox.insert(END,
                                        "#" + str(Driver78.num1) + " " + Driver78.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")
            if chance < 30:
                if Driver47.active == False:
                    Driver47.active = True
                    print("yes")
                    open.append(Driver47)
                    add("47")
                    sillylistbox.insert(END,
                                        "#" + str(Driver47.num1) + " " + Driver47.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")
        if year >= 2012:
            chance = random.choice(odds)
            if Driver93.active == False:
                Driver93.active = True
                add("93")
                open.append(Driver93)
                sillylistbox.insert(END,
                        "#" + str(Driver93.num1) + " " + Driver93.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")

            print("chance to die", chance)
            if chance < 90:
                print(mylist_inactive, "eeexedxee")
                if "00" in mylist_inactive:
                    print("00")
                    if Driver00.active == False:
                        Driver00.active = True
                        Driver00.dvr = Temp2
                        Driver00.manu = "Dodge"
                        Driver00.team1 = "Garrison Motorsports"
                        Driver00.sponsor = "KFC"
                        Driver00.prestige = 75
                        print("yes")
                        open.append(Driver00)
                        add("00")
                        open.append(Driver00)
                        sillylistbox.insert(END,
                                            "#" + str(Driver00.num1) + " " + Driver00.team1 + " will be joining the " + str(
                                                year) + " Cup Series!")

                if Driver3.active == False:
                    print("3")
                    Driver3.active = True
                    Driver3.dvr = Temp2
                    Driver3.prestige = 80
                    print("yes")
                    open.append(Driver3)
                    add("3")
                    sillylistbox.insert(END,
                                        "#" + str(Driver3.num1) + " " + Driver3.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")

                if Driver6.active == False:
                    print("6")
                    Driver6.active = True
                    Driver6.dvr = Temp2
                    if chance < 50:
                        Driver6.manu = "Ford"
                        Driver6.team1 = "Roush Racing"
                        Driver6.sponsor = "Advocare"
                    if chance >= 50:
                        if Driver9.active or Driver19.active or Driver91.active:
                            Driver6.manu = "Dodge"
                            Driver6.team1 = "Evernham Motorsports"
                            Driver6.sponsor = "Hellman's"

                    Driver6.prestige = 80
                    print("yes")
                    open.append(Driver6)
                    add("6")
                    open.append(Driver6)
                    sillylistbox.insert(END,
                                        "#" + str(Driver6.num1) + " " + Driver6.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")

                if Driver9.active == False:
                    print("9")
                    Driver9.active = True
                    Driver9.dvr = Temp2
                    if chance < 50:
                        Driver9.manu = "Chevy"
                        Driver9.team1 = "Hendrick Motorsports"
                        Driver9.sponsor = "Mountain Dew"
                    if chance >= 50:
                        if Driver19.active or Driver91.active:
                            Driver9.manu = "Dodge"
                            Driver9.team1 = "Evernham Motorsports"
                            Driver9.sponsor = "Evernham Motorsports"



                    Driver9.prestige = 80
                    print("yes")
                    open.append(Driver9)
                    add("9")
                    sillylistbox.insert(END,
                                        "#" + str(Driver9.num1) + " " + Driver9.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")

                if Driver21.active == False:
                    Driver21.active = True
                    Driver21.manu = "Chevy"
                    Driver21.team1 = "Richard Childress Motorsports"
                    Driver21.sponsor = "Reese's"
                    Driver21.prestige = 80
                    print("yes")
                    Driver21.dvr = Temp2
                    open.append(Driver21)
                    add("21")
                    sillylistbox.insert(END,
                                        "#" + str(Driver21.num1) + " " + Driver21.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")

                if Driver22.active == False:
                    Driver22.active = True
                    Driver22.manu = "Dodge"
                    Driver22.team1 = "Penske Racing"
                    Driver22.sponsor = "Pennzoil"
                    Driver22.prestige = 83
                    print("yes")
                    Driver22.dvr = Temp2
                    add("22")
                    open.append(Driver22)
                    sillylistbox.insert(END,
                                        "#" + str(
                                            Driver22.num1) + " " + Driver22.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")

                if Driver24.active == False:
                    Driver24.active = True
                    Driver24.manu = "Chevy"
                    if chance > 60:
                        Driver24.team1 = "Hendrick Motorsports"
                    else:
                        Driver24.team1 = "Jeff Gordon Inc"
                    Driver24.sponsor = "Alaxta"
                    Driver24.prestige = 84
                    print("yes")
                    Driver24.dvr = Temp2
                    open.append(Driver24)
                    add("24")
                    sillylistbox.insert(END,
                                        "#" + str(
                                            Driver24.num1) + " " + Driver24.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")

                if Driver38.active == False:
                    Driver38.active = True
                    Driver38.manu = "Ford"
                    Driver38.team1 = "Front Row Motorsports"
                    Driver38.sponsor = "K Love"
                    Driver38.prestige = 77
                    print("yes")
                    Driver38.dvr = Temp2
                    add("38")
                    open.append(Driver38)
                    sillylistbox.insert(END,
                                        "#" + str(
                                            Driver38.num1) + " " + Driver38.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")


                print("got to 88")
                if Driver88.active == False and Driver44.active == False:
                    print("88 BABY")
                    Driver88.active = True
                    Driver88.manu = "Chevy"
                    Driver88.team1 = "Hendrick Motorsports"
                    Driver88.sponsor = "Nationwide"
                    Driver88.prestige = 80
                    print("yes")
                    Driver88.dvr = Temp2
                    add("88")
                    open.append(Driver88)
                    sillylistbox.insert(END,
                                        "#" + str(
                                            Driver88.num1) + " " + Driver88.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")

        if year >= 2018:
            if Driver24.active == False:
                Driver24.active = True
                Driver24.manu = "Chevy"
                Driver24.team1 = "Jeff Gordon Inc"
                Driver24.sponsor = "Alaxta"
                Driver24.prestige = 84
                print("yes")
                Driver24.dvr = Temp2
                open.append(Driver24)
                add("24")
            if "46" not in mylist:
                if Driver46.active == False:
                    Driver46.active = True
                    print("asperchu")
                    add("46")
                    #Driver46.dvr = Driver(name = "N/A")
                    open.append(Driver46)
                    Driver46.active = True
                    sillylistbox.insert(END,
                                        "#" + str(
                                            Driver46.num1) + " " + Driver46.team1 + " will be joining the " + str(
                                            year) + " Cup Series!")

        '''
        for x in mylist_inactive:
            if x == "83":
                car = assign_inauctive(x)
                open.append(car)
                sillylistbox.insert(END, "#" + str(car.num1) + " " + car.team1 + " will be joining the " + str(year) + " Cup Series!")
                car.active = True
                index = mylist.index("88")
                mylist.insert(index, "83")
            if x == "84":
                car = assign_inactive(x)
                open.append(car)
                sillylistbox.insert(END, "#" + str(car.num1) + " " + car.team1 + " will be joining the " + str(year) + " Cup Series!")
                car.active = True
                index = mylist.index("88")
                mylist.insert(index, "84")
        '''

    prestige_ranking = {}
    for ride in open:
        prestige_ranking[ride] = ride.prestige
    prestige_ranking_sorted = sorted(prestige_ranking, key=prestige_ranking.get, reverse=True)
    for x in prestige_ranking_sorted:
        print("prestigeranking", str(x.num1), " ", str(x.prestige))


    for team in candidates:
        if team.dvr.name not in retirements:
            if team.dvr.name != "N/A":
                power_ranking[team] = team.dvr.rating
    power_ranking_sorted = sorted(power_ranking, key=power_ranking.get, reverse=True)
    for x in power_ranking_sorted:
        print("powerranking", x.dvr.name, " ", str(x.dvr.rating))

    for x in retirements:
        print("RETIRING", x)

    FreeAgentX = Team(dvr=Temp)

    for new_team in prestige_ranking_sorted:
        '''
        rosterlist1 = []
        teamlist1 = []
        for x in mylist:
            team = assign(x)
            rosterlist1.append(team.dvr.name)
            teamlist1.append(team)
        for drivr in rosterlist1:
            if rosterlist1.count(drivr) < 2:
        '''

        flag = False
        if len(power_ranking_sorted) > 0:
            print("CAR:", new_team.num1)
            print(new_team.team1, "SUCK IT")
            for replacement in power_ranking_sorted:
                if replacement.dvr.name != "N/A":
                    print("replacement candidate: ", replacement.dvr.name)
                    if new_team.dvr != replacement.dvr and new_team not in replacement.dvr.oldrides:
                        # print("driver drive moveyar ", replacement.dvr.name, " ", str(replacement.dvr.moveyear + 2) )
                        if replacement.dvr.moveyear + 2 < year or replacement.dvr.moveyear == 0:
                            if good_fit(replacement.dvr, team):
                                flag = True
                                # print("true again")
                                print("MOVER IS C ", replacement.dvr.name)
                                oldteam = new_team
                                old = new_team.dvr
                                replacement.dvr.oldrides.append(oldteam)
                                new_team.dvr = replacement.dvr
                                replacement.dvr.moved = True
                                replacement.dvr.moveyear = year
                                replacement.dvr.morale += 60

                                print("OLD DRIVER IS:", old.name)
                                if old.name not in retirements:
                                    print("THIS DRIVER IS NOT RETIRING:", old.name)
                                    print(old.name)
                                    power_ranking_sorted.append(Team(dvr=old))
                                    for driver in freeagentlist:
                                        if driver.dvr.age > 40:
                                            driver.dvr = old
                                            break

                                print("SILLYLISTBOX", year)
                                gui_string += new_team.team1 + " #" + str(
                                    new_team.num1) + " - " + old.name + " replaced by " + new_team.dvr.name + '|'

                                # sillylistbox.insert(END, new_team.team1 + " #" + str(
                                #    new_team.num1) + " - " + old.name + " replaced by " + new_team.dvr.name)

                                break
            if flag == False:
                while len(power_ranking_sorted) > 0:
                    replacement = power_ranking_sorted.pop(random.randrange(len(power_ranking_sorted)))
                    print("replacement candidate b: ", replacement.dvr.name)
                    if new_team.dvr != replacement.dvr and replacement.dvr.moved == False and replacement.dvr.name != "N/A":
                        if replacement.dvr.moveyear + 2 < year or replacement.dvr.moveyear == 0:
                            #if (replacement.dvr.name != "Kerry Earnhardt" and team.name1 == "Richard Childress Racing")
                            print("true againDDDDDD")
                            print("MOVER IS D ", replacement.dvr.name)
                            replacement.dvr.moved = True
                            replacement.dvr.moveyear = year
                            replacement.dvr.morale += 60
                            oldteam = new_team
                            old = new_team.dvr
                            replacement.dvr.oldrides.append(oldteam)
                            new_team.dvr = replacement.dvr
                            print("OLD DRIVERDDD IS:", old.name)
                            if old.name not in retirements:
                                print("THIS DRIVER IS NOT RETIRING:", old.name)
                                FreeAgentX.dvr = old
                                FreeAgentX.dvr.oldrides.append(new_team)
                                power_ranking_sorted.append(FreeAgentX)

                            # print("e", power_ranking_sorted[0].dvr.name)

                            # print("SILLYLISTBOX1", year)
                            gui_string += new_team.team1 + " #" + str(
                                new_team.num1) + " - " + old.name + " replaced by " + new_team.dvr.name + '|'

                            # sillylistbox.insert(END, new_team.team1 + " #" + str(
                            #    new_team.num1) + " - " + old.name + " replaced by " + new_team.dvr.name)

                            break

    for d in candidates:
        flag2 = True
        print(d.dvr.name, "fa")

        for f in freeagentlist:
            # print("f dvr name", f.dvr.name)
            if d.dvr.name == f.dvr.name or d.dvr.name == "N/A":
                # freeagentlist.remove(f)
                flag2 = False
        if flag2 == True:
            # print("approved", d.dvr.name)
            freeagentlist.append(Team(dvr=d.dvr))
            flag2 = False

    validlist = []
    rosterlist2 = []
    for x in mylist:
        team = assign(x)
        for f in freeagentlist:

            if team:
                if team.dvr == f.dvr:
                    freeagentlist.remove(f)
        if team:
            validlist.append(team)
            rosterlist2.append(team.dvr.name)
    '''
    for dvivr in rosterlist2:
        i = 0
        stupidlist = []
        counter = 0
        print("DVVIIVIV", dvivr)
        if rosterlist2.count(dvivr) > 1:
            print("break in case of emergency ", dvivr, )
            for team in validlist:

                if team.dvr.name == dvivr and team.active == True:
                    i += 1

                    print("Team", team.num1)
                    if i > 1:
                        print("god dammit")
                        team.active = False
                        gui_string += team.team1 + " #" + str(team.num1) + " has shut down!" + '|'
                        mylist_inactive.append(str(team.num1))
                        if str(team.num1) in mylist:
                            mylist.remove(str(team.num1))


    '''
    for team in rosterlist2:
        print(team, "another test")
        if team == "N/A":
            team = namegenerator()
    for dvr in mylist:
        car = assign(mylist)
        if car and car.dvr.name == "N/A":
            naem = namegenerator()
            car.dvr = Driver(name = naem, age=22, rating=50)


    '''
            if len(freeagentlist) > 0:
                print("break in case of emergency")
                for i in range(len(freeagentlist)):
                    mover = freeagentlist.pop(random.randrange(len(freeagentlist)))
                    if mover.dvr.age > 21:
                        for team in validlist:
                            if team.dvr.name == dvivr:
                                team.dvr = mover.dvr
                                gui_string += team.team1 + " #" + str(
                                new_team.num1) + " - " + dvivr + " replaced by " + team.dvr.name + '|'
                                break
                    else:
                        freeagentlist.append(mover)

                break
    '''
    #for d in retirements:

    for i in range(len(new_retirements)):
        if new_retirements[i][0] not in rosterlist2:

            sillylistbox.insert(END, new_retirements[i][0] + " has retired!")
            sillylistbox.insert(END, new_retirements[i][0] + " final stats: " + new_retirements[i][1] +
                                " titles, " + new_retirements[i][2] + " wins, " +
                                new_retirements[i][3]  + " top fives, " + new_retirements[i][4]  + " top tens, "
                                + new_retirements[i][5]  + " total races" )
            for f in freeagentlist:
                if f.dvr.name == new_retirements[i][0]:
                    freeagentlist.remove(f)

    for move in gui_string.split('|'):
        sillylistbox.insert(END, move)

    for f in new_retirements:
        retired.append(f)

    print("omg", retired)
    for f in freeagentlist:
        print(f.dvr.name, "!")

    rosterlist = []

    # candidates = []


    '''
    for new_team in prestige_ranking_sorted:
        print("THIS RIDE IS", new_team.num1)
        if len(power_ranking_sorted) > 0:
            if new_team.prestige > 70:
                print("POSSIBLE FIT: ", new_team.num1)
                for gooddriver in power_ranking_sorted:
                    print("MOVER IS A ", gooddriver.dvr.name)
                    if gooddriver.dvr.rating > 70:
                        print("MOVER IS B ", gooddriver.dvr.name)
                        if new_team.dvr != gooddriver.dvr and new_team not in gooddriver.dvr.oldrides:
                            print("true")
                            power_ranking_sorted.remove(gooddriver)
                            print("MOVER IS C ", gooddriver.dvr.name)
                            oldteam = new_team
                            old = new_team.dvr
                            new_team.dvr.oldrides.append(oldteam)
                            print("OLD DRIVER IS:", old.name)

                            new_team.dvr = gooddriver.dvr
                            if old.name not in retirements:
                                print("THIS DRIVER IS NOT RETIRING:", old.name)
                                FreeAgentX.dvr = old
                                gooddriver.append(FreeAgentX)
                                if old.rating > 70:
                                    power_ranking_sorted.append(FreeAgentX)

                            sillylistbox.insert(END, new_team.team1 + " #" + str(new_team.num1) + " - " + old.name + " replaced by " + new_team.dvr.name)
                            new_team.dvr.morale += 60
                            if gooddriver in power_ranking_sorted:
                                power_ranking_sorted.remove(gooddriver)
                            if new_team in prestige_ranking_sorted:
                                print("NEWEEETEAM IS xddddddddd", new_team.num1)
                                prestige_ranking_sorted.remove(new_team)
                                for xx in prestige_ranking_sorted:
                                    print(xx.num1, "XXXXXXXX")
                            #prestige_ranking_sorted.pop()
                            pass


                mover = power_ranking_sorted.pop(random.randrange(len(power_ranking_sorted)))
                print(mover.dvr.name, "e")
                if new_team.dvr != mover.dvr and new_team not in mover.dvr.oldrides:

                    #power_ranking_sorted.remove(mover)


                FreeAgentX = Team(dvr = Temp)
                oldteam = new_team
                old = new_team.dvr
                new_team.dvr = mover.dvr
                new_team.dvr.oldrides.append(oldteam)

                sillylistbox.insert(END, new_team.team1 + " #" + str(
                    new_team.num1) + " - " + old.name + " replaced by " + new_team.dvr.name)
                new_team.dvr.morale += 60

                if old not in retirements:
                    print("OLD DRIVER IS 1:", old.name)
                    FreeAgentX.dvr = old
                    candidates.append(FreeAgentX)

                    if old.rating > 70:
                        power_ranking_sorted.append(FreeAgentX)

                if mover.dvr in power_ranking_sorted:
                    power_ranking_sorted.remove(mover.dvr)
                if new_team in prestige_ranking_sorted:
                    print("NEWEEETEAM IS xddddddddd", new_team.num1)
                    prestige_ranking_sorted.remove(new_team)
                    for xx in prestige_ranking_sorted:
                        print(xx.num1, "XXXXXXXX")


                else:
                    power_ranking_sorted.append(mover)



                #prestige_ranking_sorted.pop()
                pass


            else:
                mover = power_ranking_sorted.pop(random.randrange(len(power_ranking_sorted)))
                print(mover.dvr.name)
                if new_team.dvr != mover.dvr and new_team not in mover.dvr.oldrides:

                    # power_ranking_sorted.remove(mover)

                    FreeAgentX = Team(dvr=Temp)
                    oldteam = new_team
                    old = new_team.dvr
                    new_team.dvr = mover.dvr
                    new_team.dvr.oldrides.append(oldteam)

                    sillylistbox.insert(END, new_team.team1 + " #" + str(
                        new_team.num1) + " - " + old.name + " replaced by " + new_team.dvr.name)
                    new_team.dvr.morale += 60

                    if old not in retirements:
                        print("OLD DRIVER IS 1:", old.name)
                        FreeAgentX.dvr = old
                        candidates.append(FreeAgentX)

                        if old.rating > 70:
                            power_ranking_sorted.append(FreeAgentX)

                    if mover.dvr in power_ranking_sorted:
                        power_ranking_sorted.remove(mover.dvr)
                    if new_team in prestige_ranking_sorted:
                        print("NuTum IS xddddddddd", new_team.num1)
                        prestige_ranking_sorted.remove(new_team)
                        for xx in prestige_ranking_sorted:
                            print(xx.num1, "XyX")

                else:
                    power_ranking_sorted.append(mover)

            '''


def sillySeasonExport():
    global mylist
    global yearstring
    print("sillyseasonexport")
    if Path("standings" + str(year-1) + ".txt").is_file():
        file = open("standings" + str(year-1) + ".txt", "r+")
        file.truncate(0)
        file.close()

    f = open("standings" + str(year-1) + ".txt", "a+")
    #stg=standing(mylist)
    for i in yearstring.splitlines():
        f.write(i + "\n")

def sillySeason():
    print("test")
    sillyWindow = tk.Toplevel(root)
    sillyWindow.geometry("800x250")
    # driverlist = [KennyWallace, JoeNemechek, DaveBlaney, ShaneHmiel, JohnnySauter, MartinTruex,
    #              RustyWallace, MikeWallace, KyleBusch, MarkMartin, RobbyGordon, DaleEarnhardtJr, KaseyKahne,
    #              ReedSorenson, BillElliott]

    myButton = Button(root, text="Run Race", width=20, height=2, command=myClick)
    myButton.grid(row=5, column=0, columnspan=1)
    sillyLabel = Label(sillyWindow, text="Changes: ")
    sillyLabel.grid(row=0, column=0)
    sillylistbox = Listbox(sillyWindow, width=150)
    sillylistbox.grid(row=1, column=0)
    retirement(sillylistbox, sillyWindow)

def event_year():
    global year
    global president
    global president_yr
    president_yr += 1
    eventWindow = tk.Toplevel(root)
    eventWindow.geometry("680x220")
    eventlabel = Label(eventWindow, text=str(year-1) + " in review")
    superbowl = superbowl_event()
    wrestle = wrestling_event()
    nba = nba_event()

    eventlabel.grid(row=0, column=0)
    racescrollbar = Scrollbar(eventWindow)
    racescrollbar.grid(row=1, column=0, columnspan=1)

    racelistbox = Listbox(eventWindow, width=120)
    racelistbox.grid(row=1, column=0)
    racelistbox.insert(END, superbowl)
    racelistbox.insert(END, nba)
    racelistbox.insert(END, wrestle)
    if year % 4 == 0:
        president = president_event()
        racelistbox.insert(END, president)
    myButton = Button(root, text="Silly Season", width=20, height=2, command=sillySeason)
    myButton.grid(row=5, column=0, columnspan=1)


def champion(year):
    global yearstring
    yearstring = ""
    global mylist
    standings = {}
    for i in mylist:
        car = assign(i)
        if car:
            standings[i] = car.dvr.pts

    standings_sorted = sorted(standings, key=standings.get, reverse=True)
    print(standings_sorted)
    global champions
    global toptwenty
    for i in range(0, 21):
        toptwenty.append(standings_sorted[i])
    champ = assign(standings_sorted[0])
    if champ:
        champ.dvr.t += 1
        temp = "#" + str(champ.num1) + " " + str(champ.dvr.name) + " - " + str(champ.team1)
        champions[year] = temp

    finalWindow = tk.Toplevel(root)
    finalWindow.geometry("580x220")
    finallabel = Label(finalWindow, text="Your " + str(year) + " Champion : #" + str(champ.num1) + " " + champ.dvr.name)
    finallabel.grid(row=0, column=0)
    racescrollbar = Scrollbar(finalWindow)
    racescrollbar.grid(row=1, column=0,columnspan=2)

    racelistbox = Listbox(finalWindow, width=120)
    racelistbox.grid(row=1, column=0)
    stg = standing(mylist)
    yearstring = standing(mylist)
    myButton = Button(finalWindow, text="Export Standings", width=20, height=2, command=sillySeasonExport)
    myButton.grid(row=5, column=0, columnspan=1)


    for i in stg.splitlines():
        racelistbox.insert(END, i)
        #yearstring += "#" + str(champ.num1) + " " + str(champ.dvr.name) + " - " + str(champ.team1) + "\n"

    for x in mylist:
        print("drake", x)
        driver = assign(x)
        if driver:
            driver.dvr.age += 1

    for s in range(len(standings_sorted)):
        driver = assign(standings_sorted[s]).dvr
        if driver:
            driver.wins = 0
            driver.topfives = 0
            driver.toptens = 0
            driver.avgfinish = 0
            driver.races = 0
            driver.pts = 0
            driver.finishes = []
            if driver.moved == True:
                print("f")
            driver.moved = False
            if driver.age > 20 and driver.age <= 26:
                driver.rating += 4
            if driver.age > 27 and driver.age <= 32:
                driver.rating += 2
            if driver.age > 40 and driver.age <= 45:
                driver.rating -= 3
            if driver.age > 45:
                driver.rating -= 6

            if driver.rating > 100:
                driver.rating = 100
            if driver.morale > 100:
                driver.morale = 100

            if driver.rating < 0:
                driver.rating = 0
            if driver.morale < 0:
                driver.morale = 0

    for fa in freeagentlist:
        fa.dvr.age += 1
        print("fa is", fa.dvr.name, fa.dvr.age)
        if fa.dvr.age < 26:
            fa.dvr.rating += 4
        if fa.dvr.rating > 100:
            fa.dvr.rating = 90

    myButton = Button(root, text="The Year in Review", width=20, height=2, command=event_year)
    myButton.grid(row=5, column=0, columnspan=1)




def gui_champ():
    global champions
    champWindow = tk.Toplevel(root)
    champWindow.geometry("400x170")
    champWindow.title("Hall of Champions")
    racelistbox = Listbox(champWindow, width=450)
    racelistbox.grid(row=0, column=0)
    racescrollbar = Scrollbar(champWindow)
    racescrollbar.grid(row=1, column=0)

    for k in champions:
        racelistbox.insert(END, str(k) + " | " + champions[k])


def gui_500():
    global daytona


    daytonaWindow = tk.Toplevel(root)
    daytonaWindow.geometry("400x170")
    daytonaWindow.title("Daytona 500 Winners")

    #dw = Label(daytonaWindow, text="Daytona 500 Winners")
    #dw.grid(row=0, column=0, column)
    racelistbox = Listbox(daytonaWindow, width=450)
    racelistbox.grid(row=0, column=0)
    racescrollbar = Scrollbar(daytonaWindow)
    racescrollbar.grid(row=1, column=0)

    for k in daytona:
        racelistbox.insert(END, str(k) + " | " + daytona[k])


def time_add():
    global week
    week += 1
    global year
    global schedule
    if year == 2005:
        if week == 37:
            print("EJ")
            myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
            myButton2.grid(row=5, column=1, columnspan=1)
            myButton2["state"] = DISABLED
            champion(year)
            week = 1
            year += 1

        else:
            if week != 2:
                myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
                myButton2.grid(row=5, column=1, columnspan=1)
                myButton2["state"] = NORMAL
    if year != 2005:
        if week == 37:
            myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
            myButton2.grid(row=5, column=1, columnspan=1)
            myButton2["state"] = DISABLED
            champion(year)
            week = 1
            year += 1


        else:
            if week != 1:
                myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
                myButton2.grid(row=5, column=1, columnspan=1)
                myButton2["state"] = NORMAL


def update(myButton2=None):
    # raceWindow = tk.Toplevel(root)
    # raceWindow.geometry("300x100")
    global week
    global year
    #cuplabel = Label(root, text=cup)
    if year == 2005:
        weeklabel = Label(root, text="Week:" + str(week - 1))
    else:
        weeklabel = Label(root, text="Week:" + str(week))
    yearlabel = Label(root, text="Year:" + str(year))
    weeklabel.grid(row=0, column=0)
    yearlabel.grid(row=0, column=1)


def myClick2(myButton2=None):
    # running race
    global year
    for i in range(0, 10):
        if year == 2005:
            if week == 36:
                break
        if year != 2005:
            if week == 36:
                break
        gui_race()
        update()
        time_add()


def myClick(myButton2=None):
    # running race
    raceWindow = tk.Toplevel(root)
    raceWindow.geometry("700x400")
    myLabel4 = Label(raceWindow, text="Race Results")
    myLabel4.grid(row=0, column=0)
    racescrollbar = Scrollbar(raceWindow)
    racescrollbar.grid(row=1, column=1)
    racelistbox = Listbox(raceWindow, width=120)
    racelistbox.grid(row=1, column=0)
    myLabel4 = Label(raceWindow, text="Race Notes")
    myLabel4.grid(row=2, column=0)
    racelistbox2 = Listbox(raceWindow, width=120)
    racelistbox2.grid(row=3, column=0)
    gui_race(racelistbox, racelistbox2)
    update(myButton2)
    time_add()


def click(event):
    global mylist
    global mylist1
    widget = event.widget
    selection = widget.curselection()
    value = widget.get(selection[0])
    driverWindow = tk.Toplevel(root)
    driverWindow.geometry("200x150")
    driverWindow.title("Driver Window")
    car = assign(mylist1[(selection[0])])
    if car:
        myLabel4 = Label(driverWindow, text="Driver Statistics: " + car.dvr.name)
        myLabel4.grid(row=2, column=7, columnspan = 2)
        myLabel5 = Label(driverWindow, text="Career Wins: " + str(car.dvr.totalwins))
        myLabel5.grid(row=5, column=7,  columnspan = 1)
        myLabel6 = Label(driverWindow, text="Career Top Fives: " + str(car.dvr.totaltopfives))
        myLabel6.grid(row=6, column=7,  columnspan = 1)
        myLabel7 = Label(driverWindow, text="Career Top Tens: " + str(car.dvr.totaltoptens))
        myLabel7.grid(row=7, column=7,  columnspan = 1)
        myLabel7 = Label(driverWindow, text="Championships: " + str(car.dvr.t))
        myLabel7.grid(row=8, column=7,  columnspan = 1)

def retireInfo():
    # listbox.get(listbox.curselection())
    driverWindow = tk.Toplevel(root)
    driverWindow.geometry("500x300")
    myLabel4 = Label(driverWindow, text="Retired Driver Statistics:")
    myLabel4.grid(row=0, column=0)
    scrollbar = Scrollbar(driverWindow)
    scrollbar.grid(row=0, column=1)

    listbox = Listbox(driverWindow, width=90)
    listbox.grid(row=1, column=0)
    print(retired)
    for i in retired:
        listbox.insert(END, "Driver: " + i[0] + " | Titles: " + str(i[1]) + " | Wins: " + str(i[2]) + " | Top Fives: " + str(i[3]) + " | Top Tens: " + str(i[4]) + " | Races: " + str(i[5]))
        # listbox.insert(END, "#" + str(i) + " - " + car.dvr.name)

        # standings[i] = car.dvr.pts

    listbox.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=listbox.yview)
    #listbox.bind("<Double-Button-1>", click)
    # listbox.grid(row=4,column=1)

def driverInfo():
    # listbox.get(listbox.curselection())
    driverWindow = tk.Toplevel(root)
    driverWindow.geometry("900x300")
    myLabel4 = Label(driverWindow, text="Driver Statistics:")
    myLabel4.grid(row=0, column=0)
    scrollbar = Scrollbar(driverWindow)
    scrollbar.grid(row=3, column=0)

    listbox = Listbox(driverWindow, width=120)
    listbox.grid(row=5, column=1)
    add = []
    for i in mylist:
        car = assign(i)
        if car and str(car.num1) >= str(1):
            add.append(car.num1)
            print("ADDED", add)
    add.sort()
    global mylist1
    mylist1 = []
    mylist1  = list()
    for i in add:
        if i not in mylist1:
            mylist1.append(str(i))
            print("ADDEDjr", i)
    print(mylist1)
    if "0" in mylist_real and assign("0"):
        mylist1.insert(0, "0")
    if "09" in mylist_real and assign("09"):
        mylist1.insert(0, "09")
    if "08" in mylist_real and assign("08"):
        mylist1.insert(0, "08")
    if "07" in mylist_real and assign("07"):
        mylist1.insert(0, "07")
    if "02" in mylist_real and assign("02"):
        mylist1.insert(0, "02")
    if "01" in mylist_real and assign("01"):
        mylist1.insert(0, "01")
    if "00" in mylist_real and assign("00"):
        mylist1.insert(0, "00")
    for i in mylist1:
        car = assign(i)
        if car:
            listbox.insert(END, car.displayMedium1())
        # listbox.insert(END, "#" + str(i) + " - " + car.dvr.name)

        # standings[i] = car.dvr.pts

    listbox.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=listbox.yview)
    listbox.bind("<Double-Button-1>", click)
    # listbox.grid(row=4,column=1)


def init2005():
    global mylist
    #game_gui.destroy()
    # self.parent.maxsize(750, 550)
    #root = tk.Tk()
    global champions
    global daytona
    root.minsize(300, 120)
    root.title("AutoSim BETA")
    champions[2000] = "#18 Bobby Labonte - Joe Gibbs Racing"
    champions[2001] = "#24 Jeff Gordon - Hendrick Motorsports"
    champions[2002] = "#20 Tony Stewart - Joe Gibbs Racing"
    champions[2003] = "#17 Matt Kenseth - Roush Racing"
    champions[2004] = "#97 Kurt Busch - Roush Racing"
    daytona[2000] = "#88 Dale Jarrett - Roush Racing"
    daytona[2001] = "#15 Michael Waltrip - Dale Earnhardt Inc"
    daytona[2002] = "#22 Ward Burton - Bill Davis Racing"
    daytona[2003] = "#15 Michael Waltrip - Dale Earnhardt Inc"
    daytona[2004] = "#8 Dale Earnhardt Jr - Dale Earnhardt Inc"

    # myButton1 = Button(root, text = "Time", command = update)
    # myButton1.grid(row=0, column=0)

    global week
    global year
    global cup
    global start_year
    year = 2005
    start_year = 2005
    if year == 2005:
        weeklabel = Label(root, text="Week:" + str(week))
    if year == 2020 and week == 2:
        weeklabel = Label(root, text="Week:" + str(week+1))
    else:
        weeklabel = Label(root, text="Week:" + str(week))
    yearlabel = Label(root, text="Year:" + str(year))
    cuplabel = Label(root, text=cup)
    weeklabel.grid(row=0, column=0)
    yearlabel.grid(row=0, column=1)
    cuplabel.grid(row=1, column=0, columnspan = 2)
    cuplabel.configure(anchor="center")

    myButton = Button(root, text="Run Race", width=20, height=2, command=myClick)
    myButton.grid(row=5, column=0, columnspan =1)

    myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
    myButton2.grid(row=5, column=1, columnspan =1)

    stg = Button(root, text="Standings", width=20, height=2, command=gui_standings)
    stg.grid(row=6, column=0 , columnspan =1)

    sceg = Button(root, text="Schedule", width=20, height=2, command=gui_schedule)
    sceg.grid(row=6, column=1, columnspan=1)
    #sceg["state"] = DISABLED

    dvrstats = Button(root, text="Driver Stats", width=20, height=2, command=driverInfo)
    dvrstats.grid(row=7, column=0 , columnspan =1)

    rtrstats = Button(root, text="Retired Driver Stats", width=20, height=2, command=retireInfo)
    rtrstats.grid(row=7, column=1, columnspan=1)

    dvrstats = Button(root, text="Hall of Champions", width=20, height=2, command=gui_champ)
    dvrstats.grid(row=8, column=0 , columnspan =1)

    dvrstats = Button(root, text="Daytona 500 Winners", width=20, height=2, command=gui_500)
    dvrstats.grid(row=8, column=1 , columnspan =1)

    dvrstats = Button(root, text="Load", width=20, height=2, command=load_game)
    dvrstats.grid(row=9, column=0, columnspan=1)

    dvrstats = Button(root, text="Save", width=20, height=2, command=save_game)
    dvrstats.grid(row=9, column=1, columnspan=1)
    #game_gui.destroy()

class Passwordchecker(tk.Frame):
    def __init__(self, parent):
        tk.Frame.__init__(self, parent)
        self.parent = parent
        self.initialize_user_interface()
        # year = 2005
        # week = 1

    def OnDouble(self, event):
        global mylist
        widget = event.widget
        selection = widget.curselection()
        value = widget.get(selection[0])
        driverWindow = tk.Toplevel(root)
        driverWindow.geometry("400x300")
        driverWindow.title("Driver Window")
        car = assign(mylist[(selection[0])])
        myLabel4 = Label(driverWindow, text="Driver Statistics: " + str(car.dvr.name))
        myLabel4.grid(row=4, column=0)
        myLabel5 = Label(driverWindow, text="Wins: " + str(car.dvr.wins))
        myLabel5.grid(row=5, column=0)
        myLabel6 = Label(driverWindow, text="Top Fives: " + str(car.dvr.topfives))
        myLabel6.grid(row=6, column=0)
        myLabel7 = Label(driverWindow, text="Top Tens: " + str(car.dvr.toptens))
        myLabel7.grid(row=7, column=0)
        myLabel7 = Label(driverWindow, text="Championships: " + str(car.dvr.titles))
        myLabel7.grid(row=8, column=0)

    def initialize_user_interface(self):
        global mylist

        # self.parent.maxsize(750, 550)
        self.parent.minsize(300, 120)
        self.parent.title("AutoSim BETA")

        # myButton1 = Button(root, text = "Time", command = update)
        # myButton1.grid(row=0, column=0)

        global week
        global year
        global cup
        if year == 2005:
            weeklabel = Label(root, text="Week:" + str(week-1))
        else:
            weeklabel = Label(root, text="Week:" + str(week))
        yearlabel = Label(root, text="Year:" + str(year))
        cuplabel = Label(root, text=cup)
        weeklabel.grid(row=0, column=0)
        yearlabel.grid(row=0, column=1)
        cuplabel.grid(row=1, column=0, columnspan = 2)
        cuplabel.configure(anchor="center")

        myButton = Button(root, text="Run Race", width=20, height=2, command=myClick)
        myButton.grid(row=5, column=0, columnspan =1)

        myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
        myButton2.grid(row=5, column=1, columnspan =1)

        stg = Button(root, text="Standings", width=20, height=2, command=gui_standings)
        stg.grid(row=6, column=0 , columnspan =1)

        sceg = Button(root, text="Schedule", width=20, height=2, command=gui_schedule)
        sceg.grid(row=6, column=1, columnspan=1)
        #sceg["state"] = DISABLED

        dvrstats = Button(root, text="Driver Stats", width=20, height=2, command=driverInfo)
        dvrstats.grid(row=7, column=0 , columnspan =1)

        rtrstats = Button(root, text="Retired Driver Stats", width=20, height=2, command=retireInfo)
        rtrstats.grid(row=7, column=1, columnspan=1)

        dvrstats = Button(root, text="Hall of Champions", width=20, height=2, command=gui_champ)
        dvrstats.grid(row=8, column=0 , columnspan =1)

        dvrstats = Button(root, text="Daytona 500 Winners", width=20, height=2, command=gui_500)
        dvrstats.grid(row=8, column=1 , columnspan =1)

        dvrstats = Button(root, text="Load", width=20, height=2, command=load_game)
        dvrstats.grid(row=9, column=0, columnspan=1)

        dvrstats = Button(root, text="Save", width=20, height=2, command=save_game)
        dvrstats.grid(row=9, column=1, columnspan=1)


if __name__ == '__main__':

    root = tk.Tk()
    run = Passwordchecker(root)
    root.mainloop()

