import tkinter as tk
from tkinter import *
from nascar_sim2020 import *
from pathlib import Path
from operator import itemgetter
from owner2020 import *
import copy
global numlist
numlist = ["0", "01", "02", "09", "5", "7", "23", "25", "26", "30", "31", "33", "39", "40", "44", "45", "46", "50", "54", "59", "60", "69", "70", "72", "78", "79", "80", "81", "83", "84", "91", "93", "94", "97", "98", "99"]

global counter


week = 1
year = 2020

root = Tk()

global yearstring
yearstring = ""

global wrestlemania
wrestlemania = 36

global retired
retired = []

global finalfour
finalfour = {}

global afc
global nfc
afc = ["The New England Patriots", "The Kansas City Chiefs", "The Baltimore Ravens", "The Pittsburgh Steelers", "The Oakland Raiders", "The Indianapolis Colts", "The Cleveland Browns", "The Denver Broncos", "The San Diego Chargers", "The Buffalo Bills", "The Tenessee Titans"]
nfc = ["The Detroit Lions", "The Green Bay Packers", "The Chicago Bears", "The Minnesota Vikings", "The New York Giants", "The New Orleans Saints", "The Washington Redskins", "The St Louis Rams", "The Arizona Cardinals", "The Philadelphia Eagles", "The Seattle Seahawks"]
east = ["The New Jersey Nets", "The Detroit Pistons", "The Cleveland Caveliers", "The Boston Celtics", "The Toronto Raptors", "The Chicago Bulls", "The Milwaukee Bucks", "The Miami Heat"]
west = ["The Denver Nuggets", "The Utah Jazz", "The LA Lakers", "The LA Clippers", "The Golden State Warriors", "The San Antonio Spurs", "The Dallas Mavericks", "The Houston Rockets" ]
global mylist1

mylist1 = []

global cities
global newnames
cities = ["Detroit", "Las Vegas", "New York", "Texas", "Michigan", "San Fransico", "Moscow", "Berlin", "Boston", "Toldeo", "West Virginia", "Charlotte", "London", "Mexico City", "Quebec", "Montreal", "Birmingham", "Las Vegas", "Portland", "San Antonio", "Orlando"]

newnames = ["Firehawks", "Snakes", "Sharks", "Hammerheads", "Orange's", "Cobras", "Vipers", "Crusaiders", "Harvicks", "Bears", "Strikers", "Triangles", "Warriors", "Knights", "Cougars", "Seahawks" "Panthers", "Cubs", "Cougars", "Aztecs", "Bulls", "Bison", "Rangers", "Maniacs", "Tigers", "Thunderbolts", "Mavericks", "Lions", "SuperSonics", "Nomads", "Apollo's", "Nationals"]


global president
president = ["George Bush", "Republican"]
president_yr = 6

global schedule
schedule = [["1", "Daytona" , "N/A"],  ["2", "Las Vegas" , "N/A"], ["3", "Fontana" , "N/A"], ["4", "Phoenix" , "N/A"], ["5", "Atlanta", "N/A"],
            ["6", "Homestead", "N/A"], ["7", "Texas" , "N/A"],  ["8", "Bristol" , "N/A"], ["9", "Richmond" , "N/A"], ["10", "Talladega" , "N/A"], ["11", "Dover" , "N/A"],
            ["12", "Martinsville", "N/A"], ["13", "Charlotte", "N/A"], ["14", "Kansas" , "N/A"],  ["15", "Michigan" , "N/A"], ["16", "Sonoma" , "N/A"], ["17", "Pocono", "N/A"],
            ["18", "Pocono" , "N/A"], ["19", "Indianapolis", "N/A"], ["20", "Kentucky" , "N/A"],  ["21", "New Hampshire" , "N/A"], ["22", "Watkins Glen" , "N/A"], ["23", "Michigan", "N/A"],
            ["24", "Dover" , "N/A"], ["25", "Daytona", "N/A"], ["26", "Darlington" , "N/A"],  ["27", "Richmond" , "N/A"], ["28", "Bristol" , "N/A"], ["29", "Las Vegas", "N/A"],
            ["30", "Talladega" , "N/A"], ["31", "Charlotte ROVAL", "N/A"], ["32", "Kansas" , "N/A"],  ["33", "New Hampshire" , "N/A"], ["34", "Texas" , "N/A"], ["35", "Martinsville", "N/A"],
            ["36", "Phoenix", "N/A"]]

global cup

cup = "Nextel Cup Series"

global sponsorlist
sponsorlist = ["Arby's", "Adidas", "Amrock", "Barstool", "Burger King", "Best Buy", "Bass Pro Shops", "Coca Cola", "Coke Zero", "Champion Apparel",
               "Craftsman", "Duracell", "Energizer", "GEICO", "Grey Goose", "Great Clips", "Jet's Pizza", "Keystone Light", "Little Caesar's", "Lifelock", "Nike", "Mixwell",
               "New Amsterdam", "Monster Energy", "Quicken Loans", "Pizza Hut", "Pepsi", "Purell", "Ragu", "TJ Maxx", "Stanley Tools", "iRacing", "Steak-Umm",
               "Sportclips", "Menards", "Corona Beer", "Havoline", "Hooters", "Valvoline", "American Pavement", "Advance Auto Parts", "Trus Joist", "Benihana's",
               "White Claw", "Subway", "Visteon", "Visa", "Zaxby's", "DHgate", "Grainger", "Cornerstone", "Doritos", "Crown Royal", "Valvoline NextGen", "GoDaddy",
               "Kellogg's", "Hunt Brothers Pizza", "Snap Fitness", "Powerhouse Gym", "Mac Tools", "Charter Communications", "Cheez-It", "Cabela's", "Carraba's",
               "Crest", "John Deere", "Cheerios", "Pedigree", "Miller Lite", "Stacker2", "DEX Imaging", "Yard-Man", "Netflix", "Siemens", "Oreo",
               "Gillette", "Office Depot", "K&N", "USG", "US Army", "National Guard", "Castrol", "Chilli's", "Applebee's", "ASE", "Midas", "Exxon", "Exide Batteries",
               "Dish", "Orgin", "Steam", "Adobe", "YouTube Red", "Kraft", "Charter Communications", "Breyer's Ice Cream", "Tostitos", "Arnold Palmer", "The YMCA", "Wendy's",
               "GameFLY", "Subway", "Global Poker", "iK9", "High Point", "DriveSmart", "3M", "Wix Fuel", "Weebly", "TurboTax", "Bud Light", "Sonic", "Checker's", "Rally's",
               "Kingsford", "PVA.org", "Branson", "ReMax", "Nationwide", "Zombie Radiatiors", "LeafFilter", "Waste Management", "SinClair", "Dollar General", "Orange Cassidy's Charity for the Lazy",
               "The Inner Circle", "AEW", "Frank Gore's Anti-Aging Pills", "Hugger Oranges", "Filter Time", "Reddit", "Dogecoin", "racingreference.com", "Funai", "corvetteparts.com", "Hickory Farms",
                "Hull Kogan's Diversity Training Academy", "DC Solar II", "100% Electronica", "Reese's", "Action Replay", "Supercuts", "Whelen Engineering", "Rockwell Automation", "Shop-Vac", "Frank's Red Hot"]



global champions
champions = {}

global daytona
daytona = {}


global toptwenty
toptwenty = []

global mylist
mylist = {}
mylist = {"00", "1", "2", "3", "4", "6", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
          "22", "24", "27",
          "32", "34", "36", "37", "38", "41", "42", "43", "47", "48", "49", "51", "52", "53", "66", "77", "88", "95", "96"}

global mylist_real
mylist_real = []


global mylist_inactive
mylist_inactive = {"0", "5", "7", "26", "30", "31", "33", "39", "40", "44", "45", "46", "54", "59", "60", "69", "70", "72", "78", "79", "80", "81", "83", "84", "91", "93", "94", "97", "98", "99", "100"}


global start_year
start_year = 2020

global team_names
team_names = ["Jimmie Johnson Racing", "Total Nonstop Racing", "Alpha Motorsports", "Omega Racing", "Slide Motorsports", "Mach 1 Racing", "Craft Motorsports", "Shapiro Racing Ventures",
              "Orange County Racing", "Motor City Racing", "Browntown Motorsports", "Inner Circle Racing Team", "Reddit Fan Team", "Money Inc", "JR Motorsports", "Kaulig Racing", "Vlone Inc", "Thorsport Racing"]


def gui_order(finish, randomcar):
    if randomcar == "0":
        return Driver0.gui_displayMedium()
    elif randomcar == "00":
        return Driver00.gui_displayMedium()
    elif randomcar == "01":
        return Driver01.gui_displayMedium()
    elif randomcar == "02":
        return Driver02.gui_displayMedium()
    elif randomcar == "07":
        return Driver07.gui_displayMedium()
    elif randomcar == "08":
        return Driver08.gui_displayMedium()
    elif randomcar == "09":
        return Driver09.gui_displayMedium()
    elif randomcar == "1":
        return Driver1.gui_displayMedium()
    elif randomcar == "2":
        return Driver2.gui_displayMedium()
    elif randomcar == "3":
        return Driver3.gui_displayMedium()
    elif randomcar == "4":
        return Driver4.gui_displayMedium()
    elif randomcar == "5":
        return Driver5.gui_displayMedium()
    elif randomcar == "6":
        return Driver6.gui_displayMedium()
    elif randomcar == "7":
        return Driver7.gui_displayMedium()
    elif randomcar == "8":
        return Driver8.gui_displayMedium()
    elif randomcar == "9":
        return Driver9.gui_displayMedium()
    elif randomcar == "10":
        return Driver10.gui_displayMedium()
    elif randomcar == "11":
        return Driver11.gui_displayMedium()
    elif randomcar == "12":
        return Driver12.gui_displayMedium()
    elif randomcar == "13":
        return Driver13.gui_displayMedium()
    elif randomcar == "14":
        return Driver14.gui_displayMedium()
    elif randomcar == "15":
        return Driver15.gui_displayMedium()
    elif randomcar == "16":
        return Driver16.gui_displayMedium()
    elif randomcar == "17":
        return Driver17.gui_displayMedium()
    elif randomcar == "18":
        return Driver18.gui_displayMedium()
    elif randomcar == "19":
        return Driver19.gui_displayMedium()
    elif randomcar == "20":
        return Driver20.gui_displayMedium()
    elif randomcar == "21":
        return Driver21.gui_displayMedium()
    elif randomcar == "22":
        return Driver22.gui_displayMedium()
    elif randomcar == "23":
        return Driver23.gui_displayMedium()
    elif randomcar == "24":
        return Driver24.gui_displayMedium()
    elif randomcar == "25":
        return Driver25.gui_displayMedium()
    elif randomcar == "26":
        return Driver26.gui_displayMedium()
    elif randomcar == "27":
        return Driver27.gui_displayMedium()
    elif randomcar == "29":
        return Driver29.gui_displayMedium()
    elif randomcar == "30":
        return Driver30.gui_displayMedium()
    elif randomcar == "31":
        return Driver31.gui_displayMedium()
    elif randomcar == "32":
        return Driver32.gui_displayMedium()
    elif randomcar == "33":
        return Driver33.gui_displayMedium()
    elif randomcar == "34":
        return Driver34.gui_displayMedium()
    elif randomcar == "36":
        return Driver36.gui_displayMedium()
    elif randomcar == "37":
        return Driver37.gui_displayMedium()
    elif randomcar == "38":
        return Driver38.gui_displayMedium()
    elif randomcar == "39":
        return Driver39.gui_displayMedium()
    elif randomcar == "40":
        return Driver40.gui_displayMedium()
    elif randomcar == "41":
        return Driver41.gui_displayMedium()
    elif randomcar == "42":
        return Driver42.gui_displayMedium()
    elif randomcar == "43":
        return Driver43.gui_displayMedium()
    elif randomcar == "44":
        return Driver44.gui_displayMedium()
    elif randomcar == "45":
        return Driver45.gui_displayMedium()
    elif randomcar == "46":
        return Driver46.gui_displayMedium()
    elif randomcar == "47":
        return Driver47.gui_displayMedium()
    elif randomcar == "48":
        return Driver48.gui_displayMedium()
    elif randomcar == "49":
        return Driver49.gui_displayMedium()
    elif randomcar == "50":
        return Driver50.gui_displayMedium()
    elif randomcar == "51":
        return Driver51.gui_displayMedium()
    elif randomcar == "52":
        return Driver52.gui_displayMedium()
    elif randomcar == "53":
        return Driver53.gui_displayMedium()
    elif randomcar == "54":
        return Driver54.gui_displayMedium()
    elif randomcar == "55":
        return Driver55.gui_displayMedium()
    elif randomcar == "57":
        return Driver57.gui_displayMedium()
    elif randomcar == "59":
        return Driver59.gui_displayMedium()
    elif randomcar == "60":
        return Driver60.gui_displayMedium()
    elif randomcar == "66":
        return Driver66.gui_displayMedium()
    elif randomcar == "69":
        return Driver69.gui_displayMedium()
    elif randomcar == "70":
        return Driver70.gui_displayMedium()
    elif randomcar == "72":
        return Driver72.gui_displayMedium()
    elif randomcar == "77":
        return Driver77.gui_displayMedium()
    elif randomcar == "78":
        return Driver78.gui_displayMedium()
    elif randomcar == "79":
        return Driver79.gui_displayMedium()
    elif randomcar == "80":
        return Driver80.gui_displayMedium()
    elif randomcar == "81":
        return Driver81.gui_displayMedium()
    elif randomcar == "83":
        return Driver83.gui_displayMedium()
    elif randomcar == "84":
        return Driver84.gui_displayMedium()
    elif randomcar == "88":
        return Driver88.gui_displayMedium()
    elif randomcar == "89":
        return Driver89.gui_displayMedium()
    elif randomcar == "91":
        return Driver91.gui_displayMedium()
    elif randomcar == "93":
        return Driver93.gui_displayMedium()
    elif randomcar == "95":
        return Driver95.gui_displayMedium()
    elif randomcar == "96":
        return Driver96.gui_displayMedium()
    elif randomcar == "97":
        return Driver97.gui_displayMedium()
    elif randomcar == "98":
        return Driver98.gui_displayMedium()
    elif randomcar == "99":
        return Driver99.gui_displayMedium()
    else:
        pass


def save_game(): #ADD SAVE FREE AGENT LIST
    if Path("save.txt").is_file():
        file = open("save.txt", "r+")
        file.truncate(0)
        file.close()
    if Path("save_a.txt").is_file():
        file = open("save_a.txt", "r+")
        file.truncate(0)
        file.close()
    if Path("save_b.txt").is_file():
        file = open("save_b.txt", "r+")
        file.truncate(0)
        file.close()
    if Path("save_c.txt").is_file():
        file1 = open("save_c.txt", "r+")
        file1.truncate(0)
        file1.close()
    if Path("save_d.txt").is_file():
        file1 = open("save_d.txt", "r+")
        file1.truncate(0)
        file1.close()
    if Path("save_fa.txt").is_file():
        file1 = open("save_fa.txt", "r+")
        file1.truncate(0)
        file1.close()
    if Path("save_misc.txt").is_file():
        file1 = open("save_misc.txt", "r+")
        file1.truncate(0)
        file1.close()

    if Path("save_s.txt").is_file():
        file1 = open("save_s.txt", "r+")
        file1.truncate(0)
        file1.close()
    if Path("save_p.txt").is_file():
        file1 = open("save_p.txt", "r+")
        file1.truncate(0)
        file1.close()
    if Path("save_ot.txt").is_file():
        file1 = open("save_ot.txt", "r+")
        file1.truncate(0)
        file1.close()




    global week
    global year
    global cup
    global mylist
    global start_year
    global champions
    global mylist_inactive

    f = open("save_a.txt", "w+")
    z = 0
    for i in mylist:
        if z == 0:
            f.write(i)
        else:
            f.write("~" + i)
        z+=1
    f.close()
    f = open("save_b.txt", "w+")
    z=0
    for i in mylist_inactive:
        if z == 0:
            f.write(i)
        else:
            f.write("~" + i)
        z += 1
    f.close()
    f = open("save.txt", "w+")
    TEMP1 = []
    '''
    for i in mylist:
        car = assign(i)

        if car:
            if str(car.dvr.name) not in TEMP1 and str(car.dvr.name) != "N/A":
                TEMP1.append(str(car.dvr.name))

            else:
                fix = Driver()
                fix.name = namegenerator()
                fix.age = 32
                fix.rating = 60
                car.dvr = fix

            f.write(str(car.num1) + "~" + str(car.dvr.name) + "~" + str(car.dvr.age) + "~" + str(
                car.dvr.rating) + "~" + str(car.prestige) + "~" + str(car.dvr.t) + "~" + str(car.dvr.totalwins) +
                    "~" + str(car.dvr.totaltopfives) + "~" + str(car.dvr.totaltoptens) + "~" + str(
                car.sponsor) + "~" + str(car.team1) + "~" +
                    str(car.dvr.pts) + "~" + str(car.dvr.wins) + "~" + str(car.dvr.topfives) + "~" + str(
                car.dvr.toptens) + "~" +
                    str(car.dvr.races) + "~" + str(car.dvr.morale) + "~" + str(car.active) + "~" + "\n")
    '''
    f = open("save.txt", "a+")
    f.write(cup + "~" + str(week) + "~" + str(year) + "~" + str(start_year)+"\n")
    for i in mylist:
        car = assign(i)
        if car:
            f.write(str(car.num1) + "~" + str(car.dvr.name) + "~" + str(car.dvr.age) + "~" + str(
                        car.dvr.rating) + "~" + str(car.prestige) + "~" + str(car.dvr.t) + "~" + str(car.dvr.totalwins) +
                            "~" + str(car.dvr.totaltopfives) + "~" + str(car.dvr.totaltoptens) + "~" + str(
                        car.sponsor) + "~" + str(car.team1) + "~" +
                            str(car.dvr.pts) + "~" + str(car.dvr.wins) + "~" + str(car.dvr.topfives) + "~" + str(
                        car.dvr.toptens) + "~" +
                            str(car.dvr.races) + "~" + str(car.dvr.morale) + "~" + str(car.active) + "~" + "\n")
    f.close()

    f1 = open("save_d.txt", "a+")
    z = 0
    global daytona
    global champions
    z = 0

    for i in range(abs(len(daytona)), 0, -1):
        print("I IS", i)

        f1.write(str(2015+z) + "~" + daytona[2015 + z] + "~" + "\n")
        z += 1
    f1.close()
    f2 = open("save_c.txt", "a+")
    z=0
    for i in range(abs(len(champions)),0, -1):
        print("i is", i)
        #print("suck it", str(year - 5 + z), champions[year-5+ z])
        f2.write(str(2015+z)+"~"+champions[2015+ z]+ "~" +"\n")
        z+=1

    f2.close()
    f3 = open("save_misc.txt", "a+")
    z = 0
    global wrestlemania
    f3.write(str(wrestlemania))
    f3.write("\n")

    for r in retired:
        print(r)
        f3.write(r[0]+"~"+r[1]+"~"+r[2]+"~"+r[3]+"~"+r[4]+"~"+r[5]+"~"+"\n")
        #f3.write(str(r[0])+"~"+str(r[1])+"~"+str(r[2])+"~"+str(r[3])+"~"+str(r[4]))+"~"+str(r[5])+"\n"
        z+=1
    f3.close()
    f4 = open("save_fa.txt", "a+")
    z = 0
    global freeagentlist
    for fa in freeagentlist:
        print(fa.dvr.name)
        f4.write(str(fa.dvr.name) + "~" + str(fa.dvr.age) + "~" + str(fa.dvr.rating) + "~" + "\n")

    f4.close()

    f5 = open("save_s.txt", "a+")
    z = 0
    global schedule
    for fa in schedule:
        print(fa, "sched")
        f5.write(fa[0] + "~" + fa[1] + "~" + fa[2] + "~" + "\n")

    f5.close()

    f6 = open("save_p.txt", "a+")
    global PlayerUno
    f6.write(PlayerUno.playername + "~" + (PlayerUno.organization.orgname)+ "~" + str(PlayerUno.organization.money)+ "~" + str(PlayerUno.organization.orgprestige) + "\n")
    for i in PlayerUno.organization.orgteams:
        f6.write(str(i.num1)+ "~"+ "\n")
        print("e")
    f6.close()


def load_game2020():
    global week
    global year
    global cup
    global champions
    global daytona
    global wrestlemania
    champions = {}
    daytona = {}
    global mylist
    global mylist1
    global mylist_inactive
    mylist = set()
    mylist_inactive = set()
    global PlayerUno

    f = open("save.txt", "r")
    f1 = f.readlines()
    print(f1, "e")
    i=0
    temp = year
    for x in f1:
        if i == 0:
            print(f1[i], "!!!222!")
            x2 = f1[i].split("~")

            cup = x2[0]
            week = int(x2[1])
            year = int(x2[2])
            print("DA YEAR IS")
            print("DA YEAR IS2")
            start_year = int(x2[3])

        else:

            x2 = f1[i].split("~")

            car = assign(x2[0])
            if car:
                print("car.dv", car.dvr.name)
                car.dvr.name = x2[1]
                car.dvr.age = int(x2[2])
                car.dvr.rating = float(x2[3])
                car.prestige = float(x2[4])
                car.dvr.t = int(x2[5])
                car.dvr.totalwins = int(x2[6])
                car.dvr.totaltopfives = int(x2[7])
                car.dvr.totaltoptens = int(x2[8])
                car.sponsor = x2[9]
                car.team1 = x2[10]
                car.dvr.pts = int(x2[11])
                car.dvr.wins = int(x2[12])
                car.dvr.topfives = int(x2[13])
                car.dvr.toptens = int(x2[14])
                car.dvr.races = int(x2[15])
                car.dvr.morale = int(x2[16])
                car.active = x2[17]
            else:
                car = create(x2[0])
                print("car.dv", car.dvr.name)
                car.dvr.name = x2[1]
                car.dvr.age = int(x2[2])
                car.dvr.rating = float(x2[3])
                car.prestige = float(x2[4])
                car.dvr.t = int(x2[5])
                car.dvr.totalwins = int(x2[6])
                car.dvr.totaltopfives = int(x2[7])
                car.dvr.totaltoptens = int(x2[8])
                car.sponsor = x2[9]
                car.team1 = x2[10]
                car.dvr.pts = int(x2[11])
                car.dvr.wins = int(x2[12])
                car.dvr.topfives = int(x2[13])
                car.dvr.toptens = int(x2[14])
                car.dvr.races = int(x2[15])
                car.dvr.morale = int(x2[16])
                car.active = x2[17]
        i += 1

    f.close()
    f2 = open("save_a.txt", "r")
    f7 = f2.readlines()
    print(f7)
    i = 0
    test = f7[0].split("~")
    print(test)
    for car in test:
        if assign(car):
            print(car, "FUCKSHITBITCH")
            mylist.add(car)

    f2.close()
    f = open("save_b.txt", "r")
    f7 = f.readlines()
    print
    test = f7[0].split("~")
    print(test)
    for car in test:
        mylist_inactive.add(car)

    f.close()
    fc = open("save_c.txt", "r")
    fc1 = fc.readlines()
    i = 0
    val = year-2000
    for x in fc1:

        xc = fc1[i].split("~")
        print(xc, "poo")
        champions[int(xc[0])] = xc[1]
        i+=1

    fc.close()
    fd = open("save_d.txt", "r")
    fd1 = fd.readlines()
    i=0
    for x in fd1:
        xd = fd1[i].split("~")
        daytona[int(xd[0])] = xd[1]
        i+=1
    fd.close()

    fe = open("save_misc.txt", "r")
    fe1 = fe.readlines()
    i = 0
    global retired
    retired = []
    #retired = List()
    for x in fe1:
        if i == 0:
            xd = fe1[i].split("~")
            wrestlemania = int(xd[0])
        else:
            xd = x.split("~")
            print(xd)
            lst1 = [xd[0], xd[1], xd[2], xd[3],xd[4], xd[5]]
            retired.append(lst1)
        i+=1
    fe.close()
    global freeagentlist
    freeagentlist = []
    ff = open("save_fa.txt", "r")
    ff1 = ff.readlines()
    i = 0
    for x in ff1:
        xd = x.split("~")
        d = Driver()
        d.name = xd[0]
        print("d.name, ", d.name)
        d.age = int(xd[1])
        d.rating = float(xd[2])
        freeagentlist.append(Team(dvr=d))
    ff.close()
    global schedule
    schedule = []
    fs = open("save_s.txt", "r")
    ff1 = fs.readlines()
    i = 0
    for x in ff1:
        xd = x.split("~")
        lst = []
        lst = [xd[0], xd[1], xd[2]]

        schedule.append(lst)
    fs.close()


    p = open("save_p.txt", "r+")
    p2 = p.readlines()
    i = 0
    PlayerUno.organization.orgteams = []
    for p in p2:
        if i == 0:
            p3 = p2[i].split("~")
            PlayerUno.name = p3[0]
            for z in orglist:
                if z.orgname == p3[1]:
                    PlayerUno.organization = z
            PlayerUno.organization.money = int(p3[2])
            PlayerUno.organization.prestige = int(p3[3])

        if i > 0:
            p3 = p2[i].split("~")
            print(p3)



            DV = assign(p3[0])
            print("dev", DV, DV.num1)
            PlayerUno.organization.orgteams.append(DV)
        i += 1

    #p.close()

def calculate_progression(i, carvalue):
    if i == 1 or i == 2:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            if i == 1:
                carvalue.dvr.morale += 10
            if i == 2:
                carvalue.dvr.morale += 5
        if carvalue.dvr.rating > 90 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            if i == 1:
                carvalue.dvr.morale += 12
            if i == 2:
                carvalue.dvr.morale += 6
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 90:
            carvalue.dvr.rating += 2
            carvalue.prestige += 2
            if i == 1:
                carvalue.dvr.morale += 14
            if i == 2:
                carvalue.dvr.morale += 7
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating += 3
            carvalue.prestige += 3
            if i == 1:
                carvalue.dvr.morale += 15
            if i == 2:
                carvalue.dvr.morale += 10
        if carvalue.dvr.rating <= 70:
            carvalue.dvr.rating += 4
            carvalue.prestige += 4
            if i == 1:
                carvalue.dvr.morale += 20
            if i == 2:
                carvalue.dvr.morale += 15

    if i > 3 and i <= 5:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.rating += .5
            carvalue.prestige += .5
            carvalue.dvr.morale += 5
        if carvalue.dvr.rating > 90 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            carvalue.dvr.morale += 6
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 90:
            carvalue.dvr.rating += 2
            carvalue.prestige += 2
            carvalue.dvr.morale += 7
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating += 2.5
            carvalue.prestige += 2.5
            carvalue.dvr.morale += 8
        if carvalue.dvr.rating <= 70:
            carvalue.dvr.rating += 2.5
            carvalue.prestige += 2.5
            carvalue.dvr.morale += 10

    if i > 5 and i <= 10:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.morale += 2
        if carvalue.dvr.rating > 90 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating += .5
            carvalue.prestige += .5
            carvalue.dvr.morale += 3
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 90:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            carvalue.dvr.morale += 4
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating += 1.5
            carvalue.prestige += 1.5
            carvalue.dvr.morale += 5
        if carvalue.dvr.rating <= 70:
            carvalue.dvr.rating += 1.5
            carvalue.prestige += 1.5
            carvalue.dvr.morale += 7

    if i > 10 and i <= 20:
        if carvalue.dvr.rating > 85 and carvalue.dvr.rating <= 95:
            carvalue.dvr.morale += 1
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 85:
            carvalue.dvr.rating += .5
            carvalue.prestige += .5
            carvalue.dvr.morale += 2
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            carvalue.dvr.morale += 3
        if carvalue.dvr.rating <= 70:
            carvalue.dvr.rating += 1
            carvalue.prestige += 1
            carvalue.dvr.morale += 5

    if i > 20 and i <= 30:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.rating -= 1
            carvalue.prestige -= 1
            carvalue.dvr.morale -= 2
        if carvalue.dvr.rating > 85 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating -= .5
            carvalue.prestige -= .5
            carvalue.dvr.morale -= 1

    if i > 30 and i <= 36:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.rating -= 2
            carvalue.prestige -= 2
            carvalue.dvr.morale -= 7
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating -= 1
            carvalue.prestige -= 1
            carvalue.dvr.morale -= 5
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating -= .5
            carvalue.prestige -= .5
            carvalue.dvr.morale -= 3

    if i > 36:
        if carvalue.dvr.rating > 95:
            carvalue.dvr.rating -= 3
            carvalue.prestige -= 3
            carvalue.dvr.morale -= 10
        if carvalue.dvr.rating > 80 and carvalue.dvr.rating <= 95:
            carvalue.dvr.rating -= 2
            carvalue.prestige -= 2
            carvalue.dvr.morale -= 8
        if carvalue.dvr.rating > 70 and carvalue.dvr.rating <= 80:
            carvalue.dvr.rating -= 1
            carvalue.prestige -= 1
            carvalue.dvr.morale -= 7
        if carvalue.dvr.rating <= 70:
            carvalue.dvr.morale -= 5

    if carvalue.dvr.rating > 100:
        carvalue.dvr.rating = 100
    if carvalue.prestige > 100:
        carvalue.prestige = 100
    if carvalue.dvr.morale > 100:
        carvalue.dvr.morale = 100

    if carvalue.dvr.rating < 0:
        carvalue.dvr.rating = 0
    if carvalue.prestige < 0:
        carvalue.prestige = 0
    if carvalue.dvr.morale < 0:
        carvalue.dvr.morale = 0


def gui_race(racelistbox=None, racelistbox2=None):
    global week
    i = 0
    odds = []
    for o in range(1, 101):
        odds.append(o)

    TEMP1=[]
    global mylist
    for i in mylist:
        car = assign(i)

        if car:
            if str(car.dvr.name) not in TEMP1 and str(car.dvr.name) != "N/A":
                TEMP1.append(str(car.dvr.name))

            else:
                fix = Driver()
                fix.name = namegenerator()
                fix.age = 32
                fix.rating = 60
                car.dvr = fix

    ratings = {}
    elite = []
    upperpack = []
    midpack = []
    lowpack = []
    startandpark = []
    parttime = []
    deepparttime = []
    print(TEMP1)
    ratings_sorted = set()
    ratings_sorted = {}
    crashed = []
    crashed2 = []
    saved = 0
    print("MYLIST123142", mylist)
    global year
    if year == 2020 or year ==2021:
        if week < 15:
            if year == 2020:
                elite = ["4", "11", "12", "18", "19", "22", "88"]
                upperpack = ["1", "2", "9", "20", "24", "42", "48"]
                midpack = ["6", "10", "14", "17", "21", "41", "47", "95"]
                lowpack = ["3", "8", "13", "32", "34", "35", "37", "38", "43", "96"]
                startandpark = ["00", "15", "51", "52", "77"]
                parttime = ["16", "27", "53", "66"]
                deepparttime = ["36", "49"]
                print("someoridiarygamers")
            if year == 2021:
                elite = ["4", "11", "12", "18", "19", "22", "88"]
                upperpack = ["2", "9", "20", "24", "42", "48"]
                midpack = ["1", "6", "10", "14", "17", "21", "41", "47", "95"]
                lowpack = ["3", "8", "13", "32", "34", "35", "37", "38", "43", "96"]
                startandpark = ["00", "15", "51", "52", "77"]
                if week < 2:
                    parttime = ["16", "27", "53", "66"]
                    deepparttime = ["36", "49"]
                if week > 2:
                    parttime = ["53"]
                print("someoridiarygamers")
        else:
            print(mylist, "PAIN2020")

            #ratings_sorted = sorted(ratings, key=ratings.get, reverse=True)
            #print("RAINTS SORTED", ratings_sorted)
            #for i in range(len(ratings_sorted)):
            for i in mylist:
                car = assign(i)
                if car:
                    if car and car.parttime is False and car.deepparttime is False:
                        val = odds.pop(random.randrange(len(odds)))
                        '''
                        if val < 20:
                            saved = car.prestige
                            car.prestige = 60.69123
                        '''
                        if ((car.dvr.rating + car.prestige) / 2) > 90:
                            if len(elite) <= 6:
                                if i not in elite:
                                    elite.append(i)
                            else:
                                if i not in upperpack:
                                    upperpack.append(i)
                        if ((car.dvr.rating + car.prestige) / 2) <= 90 and ((car.dvr.rating + car.prestige) / 2) > 80:
                            if len(upperpack) <= 15:
                                if i not in upperpack:
                                    upperpack.append(i)
                            else:
                                if i not in midpack:
                                    midpack.append(i)
                        if ((car.dvr.rating + car.prestige) / 2) <= 80 and ((car.dvr.rating + car.prestige) / 2) > 76:
                            if i not in midpack:
                                midpack.append(i)

                        if ((car.dvr.rating + car.prestige) / 2) <= 75 and ((car.dvr.rating + car.prestige) / 2) > 68:
                            if i not in lowpack:
                                lowpack.append(i)
                            else:
                                if i not in startandpark:
                                    startandpark.append(i)
                        if ((car.dvr.rating + car.prestige) / 2) <= 68:
                            if i not in startandpark:
                                startandpark.append(i)

                if car and car.parttime == True and car.dvr.races < 15:
                    parttime.append(i)
                if car and car.deepparttime == True and car.dvr.races < 11:
                    deepparttime.append(i)
                if car and car.dvr.name == "N/A":
                    car.dvr.name = namegenerator()

    if year != 2020 and year != 2021:
        print(mylist, "PAIN2020")
        for i in mylist:

            car = assign(i)
            if car:
                if car and car.parttime is False and car.deepparttime is False:
                    val = odds.pop(random.randrange(len(odds)))
                    '''
                    if val < 20:
                        saved = car.prestige
                        car.prestige = 60.69123
                    '''
                    if (car.dvr.rating + car.prestige) / 2 > 90:
                        if len(elite) <= 6:
                            if i not in elite:
                                elite.append(i)
                        else:
                            if i not in upperpack:
                                upperpack.append(i)
                    if (car.dvr.rating + car.prestige) / 2 <= 90 and (car.dvr.rating + car.prestige) / 2 > 82:
                        if len(upperpack) <= 14:
                            if i not in upperpack:
                                upperpack.append(i)
                        else:
                            if i not in midpack:
                                midpack.append(i)
                    if (car.dvr.rating + car.prestige) / 2 <= 82 and (car.dvr.rating + car.prestige) / 2 > 76:
                        if i not in midpack:
                            midpack.append(i)

                    if (car.dvr.rating + car.prestige) / 2 <= 75 and (car.dvr.rating + car.prestige) / 2 > 70:
                        if i not in lowpack:
                            lowpack.append(i)
                        else:
                            if i not in startandpark:
                                startandpark.append(i)
                    if (car.dvr.rating + car.prestige) / 2 <= 70:
                        if i not in startandpark:
                            startandpark.append(i)

            if car and car.parttime == True:
                parttime.append(i)
            if car and car.deepparttime == True:
                deepparttime.append(i)
            if car and car.dvr.name == "N/A":
                car.dvr.name = namegenerator()

    print(elite, upperpack, midpack, lowpack)


    '''
    elite = ["6", "8", "12", "17", "20", "24", "29", "48", "97"]
    upperpack = ["2", "5", "9", "16", "38", "99"]
    midpack = ["01", "15", "18", "19", "25", "31", "40", "42", "88"]
    lowpack = ["07", "0", "10", "11", "21", "22", "41", "43", "77"]
    startandpark = ["4", "7", "32", "45", "49"]
    parttime = ["09", "14", "36", "37", "44", "50", "66", "91"]
    deepparttime = ["00", "08", "1", "39", "55", "89"]
    '''
    toptwelve = []
    tempsum = len(elite) + len(upperpack) + len(midpack)
    tempcount = 0
    winner = 0
    if week < 2:
        global toptwenty
        toptwenty = []
    global schedule

    for i in range(1, 39):
        print("range1", elite, upperpack, midpack, lowpack, startandpark, crashed)

        if i < 26:
            if len(elite) > 0:
                val = odds.pop(random.randrange(len(odds)))
                if val >= 35:
                    randomcar = elite.pop(random.randrange(len(elite)))
                if val >= 16 and val < 35:
                    if len(upperpack) > 0:
                        randomcar = upperpack.pop(random.randrange(len(upperpack)))
                    else:
                        randomcar = elite.pop(random.randrange(len(elite)))

                if val >= 3 and val < 16:
                    if len(midpack) > 0:
                        randomcar = midpack.pop(random.randrange(len(midpack)))
                    else:
                        if len(upperpack) > 0:
                            randomcar = upperpack.pop(random.randrange(len(upperpack)))
                        else:
                            randomcar = elite.pop(random.randrange(len(elite)))

                if val < 3:
                    if len(lowpack) > 0:
                        randomcar = lowpack.pop(random.randrange(len(lowpack)))
                    else:
                        if len(midpack) > 0:
                            randomcar = midpack.pop(random.randrange(len(midpack)))
                        else:
                            if len(upperpack) > 0:
                                randomcar = upperpack.pop(random.randrange(len(upperpack)))
                            else:
                                randomcar = elite.pop(random.randrange(len(elite)))

            else:

                if len(upperpack) > 0:
                    randomcar = upperpack.pop(random.randrange(len(upperpack)))
                else:
                    if len(midpack) > 0:
                        randomcar = midpack.pop(random.randrange(len(midpack)))
                    else:
                        if len(lowpack) > 0:
                            randomcar = lowpack.pop(random.randrange(len(lowpack)))
                        else:
                            if len(parttime) > 0:
                                randomcar = parttime.pop(random.randrange(len(parttime)))
                            else:
                                if len(deepparttime) > 0:
                                    randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                else:
                                    randomcar = None

        if i >= 26:
            if len(lowpack) > 0:
                val = odds.pop(random.randrange(len(odds)))
                if val >= 30:
                    randomcar = lowpack.pop(random.randrange(len(lowpack)))
                else:
                    if len(startandpark) > 0:
                        randomcar = startandpark.pop(random.randrange(len(startandpark)))
                    else:
                        if len(lowpack) > 0:
                            randomcar = lowpack.pop(random.randrange(len(lowpack)))
                        else:
                            if len(startandpark) > 0:
                                randomcar = startandpark.pop(random.randrange(len(startandpark)))
                            else:
                                if len(deepparttime) > 0:
                                    randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                else:
                                    randomcar = None
            else:
                if len(startandpark) > 0:
                    randomcar = startandpark.pop(random.randrange(len(startandpark)))
                else:
                    if len(upperpack) > 0:
                        randomcar = upperpack.pop(random.randrange(len(upperpack)))
                    else:
                        if len(midpack) > 0:
                            randomcar = midpack.pop(random.randrange(len(midpack)))
                        else:
                            if len(lowpack) > 0:
                                randomcar = lowpack.pop(random.randrange(len(lowpack)))
                            else:
                                if len(elite) > 0:
                                    randomcar = elite.pop(random.randrange(len(elite)))
                                else:
                                    if val > 40:
                                        if len(parttime) > 0:
                                            randomcar = parttime.pop(random.randrange(len(parttime)))
                                        else:
                                            if len(deepparttime) > 0:
                                                randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                            else:
                                                randomcar = None
                                    else:
                                        if len(deepparttime) > 0:
                                            randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                        else:
                                            if len(parttime) > 0:
                                                randomcar = parttime.pop(random.randrange(len(parttime)))
                                            else:
                                                randomcar = None


        carvalue = assign(randomcar)

        temp = ""
        #points

        if carvalue:
            if carvalue.prestige == 60.69123:
                carvalue.prestige = saved
            if i < 12:
                toptwelve.append(randomcar)
            if i == 1:
                print(randomcar, "winner is")
                schedule[week - 1][2] = "#" + str(carvalue.num1) + " " + carvalue.dvr.name
                carvalue.dvr.pts += 180
                carvalue.dvr.wins += 1
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totalwins += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1
                winner = carvalue
                print("the week is, ", week)
                global daytona
                if week == 2 and year == 2005:
                    print("true! daytoan 500")

                    temp = "#"
                    temp += str(carvalue.num1) + " " + carvalue.dvr.name + " - " + carvalue.team1
                    daytona[year] = temp
                    print(daytona)
                if week == 1 and year != 2005:
                    print("true! daytoan 500")

                    temp = "#"
                    print("str1",  str(carvalue.num1) )
                    print("str2", str(carvalue.dvr.name))
                    print("str", carvalue.team1)




                    temp += str(carvalue.num1) + " " + carvalue.dvr.name + " - " + carvalue.team1
                    daytona[year] = temp
                    print(daytona)

            if (i >= 2) and (i < 6):
                carvalue.dvr.pts += 175 - (5 * (i - 1))
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1

            if i == 6:
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1
                carvalue.dvr.pts += 175 - (5 * (i - 1))

            if i == 7:
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1
                carvalue.dvr.pts += 175 - (5 * (i - 1)) + 1

            if (i > 7) and (i < 11):
                carvalue.dvr.pts += 175 - (5 * (i - 1)) + 3
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltoptens += 1

            if (i >= 11) and (i < 21):
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))
            if i >= 21 and i < 30:
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))

            if i >= 30:
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))
                #if carvalue.prestige > 75:
                #    crashed.append(carvalue)

            if i >= 32:
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))
                if carvalue not in crashed:
                    crashed2.append(carvalue)

            carvalue.dvr.races += 1
            carvalue.dvr.totalraces += 1
            carvalue.dvr.finishes.append(i)

            total = 0
            for p in carvalue.dvr.finishes:
                total += p
            carvalue.dvr.avgfinish = total / carvalue.dvr.races

            calculate_progression(i, carvalue)

            if racelistbox:
                if i in [1, 21, 31, 41]:
                    racelistbox.insert(END, (
                        "{}st Place ---------------------------------------------------------------------------- ".format(
                            i)))
                elif i in [2, 12, 22, 32, 42]:
                    racelistbox.insert(END, (
                        "{}nd Place ---------------------------------------------------------------------------- ".format(
                            i)))
                elif i in [3, 13, 23, 33, 43]:
                    racelistbox.insert(END, (
                        "{}rd Place ---------------------------------------------------------------------------- ".format(
                            i)))
                else:
                    racelistbox.insert(END, (
                        "{}th Place ---------------------------------------------------------------------------- ".format(
                            i)))

            finish1 = gui_order(i, randomcar)
            if racelistbox:
                racelistbox.insert(END, (finish1))
        else:
            print("fail, ", randomcar)

    #eventrace
    for o in range(1, 101):
        odds.append(o)

    odds2 = []
    for o in range(2, 14):
        odds2.append(o)

    odds3 = []
    for o in range(5, 16):
        odds3.append(o)
    #test = president[0]
    choice = random.choice(odds)
    print("toptwelve", toptwelve)
    global mylist_real
    mylist_real = []
    for i in mylist:

        mylist_real.append(i)

    print(mylist_real, "e")
    if racelistbox2:
        racelistbox2.insert(END, "Today's NASCAR Cup Series race was won by #" + str(winner.num1) + " " + str(winner.dvr.name) +"." )
        rando = assign(random.choice(toptwelve))
        rando1 = assign(mylist_real.pop(random.randrange(len(mylist_real))))
        rando2 = assign(mylist_real.pop(random.randrange(len(mylist_real))))
        print(crashed)
        print(rando.num1, "wingsofredemption")
        racelistbox2.insert(END, "# " + str(rando.num1) + " " + str(rando.dvr.name) + " led the most laps.")

        choice2 = random.choice(odds2)
        choice3 = random.choice(odds3)
        racelistbox2.insert(END, str(choice3) + " different drivers led a lap today, and there were " + str(choice2) + " cautions for " + str(choice2*3) + " laps.")
        racelistbox2.insert(END, "------------------------------------------------------------------------")
        choice = random.choice(odds)
        if choice < 9:
            racelistbox2.insert(END, "#" + str(rando1.num1) + " " + str(rando1.dvr.name) +
                            " and " + "#"  + str(rando2.num1) + " " + str(rando2.dvr.name) + " got in a fight!")


        for i in crashed:
            choice = random.choice(odds)
            if i.dvr.rating > 86:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " was involved in a crash!")
            else:
                if choice < 55:
                    racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " was involved in a crash!")
                if choice < 55 and choice > 30:
                    racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to engine trouble!")
                if choice < 30 and choice > 22:
                    racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a blown tire!")
                if choice <= 22 and choice >= 10:
                    racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to overheating!")
                if choice < 10:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a piston failure!")
        for i in crashed2:
            if i not in crashed:
                choice = random.choice(odds)
                if choice > 90:
                    racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " was involved in a crash!")
                if choice > 60 and choice <= 90:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to engine trouble!")
                if choice >= 30 and choice <= 60:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a blown tire!")
                if choice < 30 and choice > 10:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to overheating!")
                if choice < 10 and choice > 5:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a blown tire!")
                if choice < 5:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a blown radiator!")

    if week ==25:
        print("roundof16")
        finalfourcars = {}
        nextbest = {}
        print(week)
        for i in mylist:
            car = assign(i)
            if car and car.dvr.wins > 0:
                finalfourcars[i] = car.dvr.wins

        finalfourcars1 = sorted(finalfourcars, key=finalfourcars.get, reverse=True)

        for i in mylist:
            if i not in finalfourcars1:
                print("TROO", i)
                car1 = assign(i)
                if car1:
                    nextbest[i] = car1.dvr.pts
        print(nextbest, "Trueoo")
        nextbest1 = sorted(nextbest, key=nextbest.get, reverse=True)
        print(nextbest1, "list69")
        print("your playoffs", finalfourcars1)
        count = 0
        print(len(finalfourcars), "LEN")
        if len(finalfourcars1) < 16:
            print("GOD ITS TRUE")
            while len(finalfourcars1) < 16:
                print(nextbest1, "AAAAA")
                add = nextbest1[count]
                nextbest1.remove(add)
                finalfourcars1.append(add)
                print(finalfourcars1, "LEVELD UP")
                print("added1123", add)
                count += 1

        print(finalfourcars1)
        for i in finalfourcars1:
            print("assigning i", i)
            v = assign(i)
            v.dvr.pts = 5000
        playoffwindow = Tk()
        playofflabel = Label(playoffwindow, text="Your " + str(year)+ " Playoff Drivers")
        playofflabel.grid(row=0, column=0)
        racelistbox = Listbox(playoffwindow, width=80)
        racelistbox.grid(row=1, column=0)
        for s in finalfourcars1:
            # print(schedule)
            car = assign(s)
            display = "#" + str(s) + " " + car.dvr.name + " | Points: " + str(car.dvr.pts) + " | Wins: " + str(car.dvr.wins) + " | Top 5's: " + str(car.dvr.topfives) + " | Top 10's: " + str(car.dvr.toptens) + " |  Races Completed: " + str(car.dvr.races) + '\n'
            racelistbox.insert(END,  display)
        playofflabel1 = Label(playoffwindow, text="Missed The Cut")
        playofflabel1.grid(row=2, column=0)
        racelistbox1 = Listbox(playoffwindow, width=80)
        racelistbox1.grid(row=4, column=0)
        for s in nextbest1:
            # print(schedule)
            car = assign(s)
            display = "#" + str(s) + " " + car.dvr.name + " | Points: " + str(car.dvr.pts) + " | Wins: " + str(car.dvr.wins) + " | Top 5's: " + str(car.dvr.topfives) + " | Top 10's: " + str(car.dvr.toptens) + " |  Races Completed: " + str(car.dvr.races) + '\n'
            racelistbox1.insert(END,  display)

    if week ==28:
        print("roundof12")
        finalfourcars = {}
        print(week)
        for i in mylist:
            car = assign(i)
            if car:
                finalfourcars[i] = car.dvr.pts
        finalfourcars1 = sorted(finalfourcars, key=finalfourcars.get, reverse=True)
        print("final four cars 1", finalfourcars1)
        for i in range(0,12):
            v = assign(finalfourcars1[i])
            v.dvr.pts = 7500
    if week ==31:
        print("roundof8")
        finalfourcars = {}
        print(week)
        for i in mylist:
            car = assign(i)
            if car:
                finalfourcars[i] = car.dvr.pts

        finalfourcars1 = sorted(finalfourcars, key=finalfourcars.get, reverse=True)
        print("final four cars 1", finalfourcars1)
        for i in range(0,8):
            v = assign(finalfourcars1[i])
            v.dvr.pts = 9000
    if week == 35:
        print("final4")
        finalfourcars = {}
        print(week)
        for i in mylist:
            car = assign(i)
            if car:
                finalfourcars[i] = car.dvr.pts

        finalfourcars1 = sorted(finalfourcars, key=finalfourcars.get, reverse=True)
        print("final four cars 1", finalfourcars1)
        for i in range(0,4):
            v = assign(finalfourcars1[i])
            v.dvr.pts = 10000




def gui_race1(racelistbox=None, racelistbox2=None):
    global week
    i = 0
    odds = []
    for o in range(1, 101):
        odds.append(o)
    print("HOLY SHI")
    TEMP1=[]
    global mylist
    for i in mylist:
        car = assign(i)

        if car:
            if str(car.dvr.name) not in TEMP1 and str(car.dvr.name) != "N/A":
                TEMP1.append(str(car.dvr.name))

            else:
                fix = Driver()
                fix.name = namegenerator()
                fix.age = 32
                fix.rating = 60
                car.dvr = fix
    global PlayerUno
    ratings = {}
    elite = []
    upperpack = []
    midpack = []
    lowpack = []
    startandpark = []
    parttime = []
    deepparttime = []
    print(TEMP1)
    ratings_sorted = set()
    ratings_sorted = {}
    crashed = []
    crashed2 = []
    yourcars = []
    saved = 0
    print("MYLIST123142", mylist)
    global year
    if year == 2020 or year ==2021:
        if week < 10:
            if year == 2020:
                elite = ["4", "11", "12", "18", "19", "22", "88"]
                upperpack = ["1", "2", "9", "20", "24", "42", "48"]
                midpack = ["6", "10", "14", "17", "21", "41", "47", "95",  "43"]
                lowpack = ["3", "8", "13", "32", "34", "35", "37", "38", "96"]
                startandpark = ["00", "15", "51", "52", "77"]
                if week < 2:
                    parttime = ["16", "27", "53", "66"]
                    deepparttime = ["36", "49"]
                if week > 2:
                    parttime = ["53"]
                for i in mylist:
                    if i not in elite and i not in upperpack and i not in midpack and i not in lowpack and i not in startandpark and i not in parttime and i not in deepparttime:
                        midpack.append(i)
                print("someoridiarygamers")
            if year == 2021:
                elite = ["4", "11", "12", "18", "19", "22", "88"]
                upperpack = ["2", "9", "20", "24", "42", "48"]
                midpack = ["1", "6", "10", "14", "17", "21", "41", "47", "95" "3", "8",  "43"]
                lowpack = ["13", "32", "34", "35", "37", "38", "96"]
                startandpark = ["00", "15", "51", "52", "77"]
                if week < 2:
                    parttime = ["16", "27", "53", "66"]
                    deepparttime = ["36", "49"]
                if week > 2:
                    parttime = ["53"]
                for i in mylist:
                    if i not in elite and i not in upperpack and i not in midpack and i not in lowpack and i not in startandpark and i not in parttime and i not in deepparttime:
                        midpack.append(i)
                print("someoridiarygamers")
        else:
            print(mylist, "PAIN2020")

            #ratings_sorted = sorted(ratings, key=ratings.get, reverse=True)
            #print("RAINTS SORTED", ratings_sorted)
            #for i in range(len(ratings_sorted)):
            for i in mylist:
                car = assign(i)
                if car:
                    if car and car.parttime is False and car.deepparttime is False:
                        val = odds.pop(random.randrange(len(odds)))
                        '''
                        if val < 20:
                            saved = car.prestige
                            car.prestige = 60.69123
                        '''
                        if ((car.dvr.rating + car.prestige) / 2) > 90:
                            if len(elite) <= 6:
                                if i not in elite:
                                    elite.append(i)
                            else:
                                if i not in upperpack:
                                    upperpack.append(i)
                        if ((car.dvr.rating + car.prestige) / 2) <= 90 and ((car.dvr.rating + car.prestige) / 2) > 80:
                            if len(upperpack) <= 15:
                                if i not in upperpack:
                                    upperpack.append(i)
                            else:
                                if i not in midpack:
                                    midpack.append(i)
                        if ((car.dvr.rating + car.prestige) / 2) <= 80 and ((car.dvr.rating + car.prestige) / 2) > 76:
                            if i not in midpack:
                                midpack.append(i)

                        if ((car.dvr.rating + car.prestige) / 2) <= 75 and ((car.dvr.rating + car.prestige) / 2) > 68:
                            if i not in lowpack:
                                lowpack.append(i)
                            else:
                                if i not in startandpark:
                                    startandpark.append(i)
                        if ((car.dvr.rating + car.prestige) / 2) <= 68:
                            if i not in startandpark:
                                startandpark.append(i)

                if car and car.parttime == True and car.dvr.races < 15:
                    parttime.append(i)
                if car and car.deepparttime == True and car.dvr.races < 11:
                    deepparttime.append(i)
                if car and car.dvr.name == "N/A":
                    car.dvr.name = namegenerator()

    if year != 2020 and year != 2021:
        print(mylist, "PAIN2020")
        for i in mylist:

            car = assign(i)
            if car:
                if car and car.parttime is False and car.deepparttime is False:
                    val = odds.pop(random.randrange(len(odds)))
                    '''
                    if val < 20:
                        saved = car.prestige
                        car.prestige = 60.69123
                    '''
                    if (car.dvr.rating + car.prestige) / 2 > 90:
                        if len(elite) <= 6:
                            if i not in elite:
                                elite.append(i)
                        else:
                            if i not in upperpack:
                                upperpack.append(i)
                    if (car.dvr.rating + car.prestige) / 2 <= 90 and (car.dvr.rating + car.prestige) / 2 > 82:
                        if len(upperpack) <= 14:
                            if i not in upperpack:
                                upperpack.append(i)
                        else:
                            if i not in midpack:
                                midpack.append(i)
                    if (car.dvr.rating + car.prestige) / 2 <= 82 and (car.dvr.rating + car.prestige) / 2 > 76:
                        if i not in midpack:
                            midpack.append(i)

                    if (car.dvr.rating + car.prestige) / 2 <= 75 and (car.dvr.rating + car.prestige) / 2 > 70:
                        if i not in lowpack:
                            lowpack.append(i)
                        else:
                            if i not in startandpark:
                                startandpark.append(i)
                    if (car.dvr.rating + car.prestige) / 2 <= 70:
                        if i not in startandpark:
                            startandpark.append(i)

            if car and car.parttime == True:
                parttime.append(i)
            if car and car.deepparttime == True:
                deepparttime.append(i)
            if car and car.dvr.name == "N/A":
                car.dvr.name = namegenerator()

    print(elite, upperpack, midpack, lowpack)


    '''
    elite = ["6", "8", "12", "17", "20", "24", "29", "48", "97"]
    upperpack = ["2", "5", "9", "16", "38", "99"]
    midpack = ["01", "15", "18", "19", "25", "31", "40", "42", "88"]
    lowpack = ["07", "0", "10", "11", "21", "22", "41", "43", "77"]
    startandpark = ["4", "7", "32", "45", "49"]
    parttime = ["09", "14", "36", "37", "44", "50", "66", "91"]
    deepparttime = ["00", "08", "1", "39", "55", "89"]
    '''
    toptwelve = []
    tempsum = len(elite) + len(upperpack) + len(midpack)
    tempcount = 0
    winner = 0
    if week < 2:
        global toptwenty
        toptwenty = []
    global schedule

    for i in range(1, 41):
        print("range1", elite, upperpack, midpack, lowpack, startandpark, crashed)

        if i < 26:
            if len(elite) > 0:
                val = odds.pop(random.randrange(len(odds)))
                if val >= 35:
                    randomcar = elite.pop(random.randrange(len(elite)))
                if val >= 16 and val < 35:
                    if len(upperpack) > 0:
                        randomcar = upperpack.pop(random.randrange(len(upperpack)))
                    else:
                        randomcar = elite.pop(random.randrange(len(elite)))

                if val >= 3 and val < 16:
                    if len(midpack) > 0:
                        randomcar = midpack.pop(random.randrange(len(midpack)))
                    else:
                        if len(upperpack) > 0:
                            randomcar = upperpack.pop(random.randrange(len(upperpack)))
                        else:
                            randomcar = elite.pop(random.randrange(len(elite)))

                if val < 3:
                    if len(lowpack) > 0:
                        randomcar = lowpack.pop(random.randrange(len(lowpack)))
                    else:
                        if len(midpack) > 0:
                            randomcar = midpack.pop(random.randrange(len(midpack)))
                        else:
                            if len(upperpack) > 0:
                                randomcar = upperpack.pop(random.randrange(len(upperpack)))
                            else:
                                randomcar = elite.pop(random.randrange(len(elite)))

            else:

                if len(upperpack) > 0:
                    randomcar = upperpack.pop(random.randrange(len(upperpack)))
                else:
                    if len(midpack) > 0:
                        randomcar = midpack.pop(random.randrange(len(midpack)))
                    else:
                        if len(lowpack) > 0:
                            randomcar = lowpack.pop(random.randrange(len(lowpack)))
                        else:
                            if len(parttime) > 0:
                                randomcar = parttime.pop(random.randrange(len(parttime)))
                            else:
                                if len(deepparttime) > 0:
                                    randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                else:
                                    randomcar = None

        if i >= 26:
            if len(lowpack) > 0:
                val = odds.pop(random.randrange(len(odds)))
                if val >= 30:
                    randomcar = lowpack.pop(random.randrange(len(lowpack)))
                else:
                    if len(startandpark) > 0:
                        randomcar = startandpark.pop(random.randrange(len(startandpark)))
                    else:
                        if len(upperpack) > 0:
                            randomcar = upperpack.pop(random.randrange(len(upperpack)))
                        else:
                            if len(startandpark) > 0:
                                randomcar = startandpark.pop(random.randrange(len(startandpark)))
                            else:
                                if len(deepparttime) > 0:
                                    randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                else:
                                    randomcar = None
            else:
                if len(upperpack) > 0:
                    randomcar = upperpack.pop(random.randrange(len(upperpack)))
                else:
                    if len(midpack) > 0:
                        randomcar = midpack.pop(random.randrange(len(midpack)))
                    else:
                        if len(elite) > 0:
                            randomcar = elite.pop(random.randrange(len(elite)))
                        else:
                            if len(startandpark) > 0:
                                randomcar = startandpark.pop(random.randrange(len(startandpark)))
                            else:

                                if val > 40:
                                    if len(parttime) > 0:
                                        randomcar = parttime.pop(random.randrange(len(parttime)))
                                    else:
                                        if len(deepparttime) > 0:
                                            randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                        else:
                                            randomcar = None
                                else:
                                    if len(deepparttime) > 0:
                                        randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                    else:
                                        if len(parttime) > 0:
                                            randomcar = parttime.pop(random.randrange(len(parttime)))
                                        else:
                                            randomcar = None


        carvalue = assign(randomcar)

        temp = ""
        #points

        if carvalue:
            if carvalue.prestige == 60.69123:
                carvalue.prestige = saved
            if i < 12:
                toptwelve.append(randomcar)
            if i == 1:
                print(randomcar, "winner is")
                if week < 36:
                    schedule[week - 1][2] = "#" + str(carvalue.num1) + " " + carvalue.dvr.name
                for x in PlayerUno.organization.orgteams:
                    if x.dvr == carvalue.dvr:
                        PlayerUno.organization.money += 10000
                carvalue.dvr.pts += 180
                carvalue.dvr.wins += 1
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totalwins += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1
                winner = carvalue
                print("the week is, ", week)
                global daytona
                if week == 2 and year == 2005:

                    print("true! daytoan 500")

                    temp = "#"
                    temp += str(carvalue.num1) + " " + carvalue.dvr.name + " - " + carvalue.team1
                    daytona[year] = temp
                    print(daytona)
                if week == 1 and year != 2005:
                    print("true! daytoan 500")

                    temp = "#"
                    print("str1",  str(carvalue.num1) )
                    print("str2", str(carvalue.dvr.name))
                    print("str", carvalue.team1)




                    temp += str(carvalue.num1) + " " + carvalue.dvr.name + " - " + carvalue.team1
                    daytona[year] = temp
                    print(daytona)

            if (i >= 2) and (i < 6):
                for x in PlayerUno.organization.orgteams:
                    if x.dvr == carvalue.dvr:
                        PlayerUno.organization.money += 7500
                carvalue.dvr.pts += 175 - (5 * (i - 1))
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1

            if i == 6:
                for x in PlayerUno.organization.orgteams:
                    if x.dvr == carvalue.dvr:
                        PlayerUno.organization.money += 5000
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1
                carvalue.dvr.pts += 175 - (5 * (i - 1))

            if i == 7:
                for x in PlayerUno.organization.orgteams:
                    if x.dvr == carvalue.dvr:
                        PlayerUno.organization.money += 4000
                carvalue.dvr.topfives += 1
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltopfives += 1
                carvalue.dvr.totaltoptens += 1
                carvalue.dvr.pts += 175 - (5 * (i - 1)) + 1

            if (i > 7) and (i < 11):
                for x in PlayerUno.organization.orgteams:
                    if x.dvr == carvalue.dvr:
                        PlayerUno.organization.money += 3500
                carvalue.dvr.pts += 175 - (5 * (i - 1)) + 3
                carvalue.dvr.toptens += 1
                carvalue.dvr.totaltoptens += 1

            if (i >= 11) and (i < 21):
                for x in PlayerUno.organization.orgteams:
                    if x.dvr == carvalue.dvr:
                        PlayerUno.organization.money += 3000
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))
            if i >= 21 and i < 30:
                for x in PlayerUno.organization.orgteams:
                    if x.dvr == carvalue.dvr:
                        PlayerUno.organization.money += 2500
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))

            if i >= 30:
                for x in PlayerUno.organization.orgteams:
                    if x.dvr == carvalue.dvr:
                        PlayerUno.organization.money += 2000
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))
                #if carvalue.prestige > 75:
                #    crashed.append(carvalue)

            if i >= 32:
                for x in PlayerUno.organization.orgteams:
                    if x.dvr == carvalue.dvr:
                        PlayerUno.organization.money += 500
                tempcount += 1
                carvalue.dvr.pts += 133 - (3 * (tempcount))
                if carvalue not in crashed:
                    crashed2.append(carvalue)

            carvalue.dvr.races += 1
            carvalue.dvr.totalraces += 1
            carvalue.dvr.finishes.append(i)

            total = 0
            for p in carvalue.dvr.finishes:
                total += p
            carvalue.dvr.avgfinish = total / carvalue.dvr.races


            if week == 1 or week % 4 == 0:
                calculate_progression(i, carvalue)

            if racelistbox:
                if i in [1, 21, 31, 41]:
                    racelistbox.insert(END, (
                        "{}st Place ---------------------------------------------------------------------------- ".format(
                            i)))
                elif i in [2, 12, 22, 32, 42]:
                    racelistbox.insert(END, (
                        "{}nd Place ---------------------------------------------------------------------------- ".format(
                            i)))
                elif i in [3, 13, 23, 33, 43]:
                    racelistbox.insert(END, (
                        "{}rd Place ---------------------------------------------------------------------------- ".format(
                            i)))
                else:
                    racelistbox.insert(END, (
                        "{}th Place ---------------------------------------------------------------------------- ".format(
                            i)))


            if carvalue in PlayerUno.organization.orgteams:
                print("true123", carvalue.num1)
                finish1 = gui_order(i, randomcar)

                if racelistbox:
                    racelistbox.insert(END, (finish1))
                    yourcars.append(i)

            else:
                if racelistbox:
                    finish1 = gui_order(i, randomcar)
                    racelistbox.insert(END, (finish1))

    print(yourcars, "YOURCARS")
    for i in yourcars:
        if (int(i * 2)-1) == 1:
            racelistbox.itemconfig(int(i * 2) - 1, {'fg': 'green'})

        if (int(i * 2)-1) < 5 and (int(i * 2)-1) != 1:
            racelistbox.itemconfig(int(i * 2)-1, {'fg': 'green'})

        if (int(i * 2)-1) < 10 and (int(i * 2)-1) >= 5:
            racelistbox.itemconfig(int(i * 2)-1, {'fg': 'blue'})

        if (int(i * 2)-1) < 20 and (int(i * 2)-1) >= 10:
            racelistbox.itemconfig(int(i * 2)-1, {'fg': 'magenta'})

        if (int(i * 2)-1) >= 20:
            racelistbox.itemconfig(int(i * 2)-1, {'fg': 'red'})
        #racelistbox.itemconfig(int(i+2), {'fg': 'blue'})

    #eventrace
    for o in range(1, 101):
        odds.append(o)

    odds2 = []
    for o in range(2, 14):
        odds2.append(o)

    odds3 = []
    for o in range(5, 16):
        odds3.append(o)
    #test = president[0]
    choice = random.choice(odds)
    print("toptwelve", toptwelve)
    global mylist_real
    mylist_real = []
    for i in mylist:

        mylist_real.append(i)

    print(mylist_real, "e")
    if racelistbox2:
        racelistbox2.insert(END, "Today's NASCAR Cup Series race was won by #" + str(winner.num1) + " " + str(winner.dvr.name) +"." )
        rando = assign(random.choice(toptwelve))
        rando1 = assign(mylist_real.pop(random.randrange(len(mylist_real))))
        rando2 = assign(mylist_real.pop(random.randrange(len(mylist_real))))
        print(crashed)
        print(rando.num1, "wingsofredemption")
        racelistbox2.insert(END, "# " + str(rando.num1) + " " + str(rando.dvr.name) + " led the most laps.")

        choice2 = random.choice(odds2)
        choice3 = random.choice(odds3)
        racelistbox2.insert(END, str(choice3) + " different drivers led a lap today, and there were " + str(choice2) + " cautions for " + str(choice2*3) + " laps.")
        racelistbox2.insert(END, "------------------------------------------------------------------------")
        if len(yourcars) == 1:
            racelistbox2.insert(END, "Your Cars Finished: " + str(yourcars[0]))
        if len(yourcars) == 2:
            racelistbox2.insert(END, "Your Cars Finished: " + str(yourcars[0]) +  " " +  str(yourcars[1]))
        if len(yourcars) == 3:
            racelistbox2.insert(END, "Your Cars Finished: " + str(yourcars[0]) +  " " + str(yourcars[1]) +  " " + str(yourcars[2]))
        if len(yourcars) == 4:
            racelistbox2.insert(END, "Your Cars Finished: " + str(yourcars[0]) + " " + str(yourcars[1]) +  " " + str(yourcars[2]) +  " " +  str(yourcars[3]))


        racelistbox2.insert(END, "------------------------------------------------------------------------")
        choice = random.choice(odds)
        if choice < 9:
            racelistbox2.insert(END, "#" + str(rando1.num1) + " " + str(rando1.dvr.name) +
                            " and " + "#"  + str(rando2.num1) + " " + str(rando2.dvr.name) + " got in a fight!")


        for i in crashed:
            choice = random.choice(odds)
            if i.dvr.rating > 86:
                racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " was involved in a crash!")
            else:
                if choice < 55:
                    racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " was involved in a crash!")
                if choice < 55 and choice > 30:
                    racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to engine trouble!")
                if choice < 30 and choice > 22:
                    racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a blown tire!")
                if choice <= 22 and choice >= 10:
                    racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to overheating!")
                if choice < 10:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a piston failure!")
        for i in crashed2:
            if i not in crashed:
                choice = random.choice(odds)
                if choice > 90:
                    racelistbox2.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " was involved in a crash!")
                if choice > 60 and choice <= 90:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to engine trouble!")
                if choice >= 30 and choice <= 60:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a blown tire!")
                if choice < 30 and choice > 10:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to overheating!")
                if choice < 10 and choice > 5:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a blown tire!")
                if choice < 5:
                    racelistbox2.insert(END,
                                        "#" + str(i.num1) + " " + str(i.dvr.name) + " retired due to a blown radiator!")

    if week ==25:
        print("roundof16")
        finalfourcars = {}
        nextbest = {}
        print(week)
        for i in mylist:
            car = assign(i)
            if car and car.dvr.wins > 0:
                finalfourcars[i] = car.dvr.wins

        finalfourcars1 = sorted(finalfourcars, key=finalfourcars.get, reverse=True)

        for i in mylist:
            if i not in finalfourcars1:
                print("TROO", i)
                car1 = assign(i)
                if car1:
                    nextbest[i] = car1.dvr.pts
        print(nextbest, "Trueoo")
        nextbest1 = sorted(nextbest, key=nextbest.get, reverse=True)
        print(nextbest1, "list69")
        print("your playoffs", finalfourcars1)
        count = 0
        print(len(finalfourcars), "LEN")
        if len(finalfourcars1) < 16:
            print("GOD ITS TRUE")
            while len(finalfourcars1) < 16:
                print(nextbest1, "AAAAA")
                add = nextbest1[count]
                nextbest1.remove(add)
                finalfourcars1.append(add)
                print(finalfourcars1, "LEVELD UP")
                print("added1123", add)
                count += 1

        print(finalfourcars1)
        for i in finalfourcars1:
            print("assigning i", i)
            v = assign(i)
            v.dvr.pts = 5000
        playoffwindow = Tk()
        playofflabel = Label(playoffwindow, text="Your " + str(year)+ " Playoff Drivers")
        playofflabel.grid(row=0, column=0)
        racelistbox = Listbox(playoffwindow, width=80)
        racelistbox.grid(row=1, column=0)
        for s in finalfourcars1:
            # print(schedule)
            car = assign(s)
            display = "#" + str(s) + " " + car.dvr.name + " | Points: " + str(car.dvr.pts) + " | Wins: " + str(car.dvr.wins) + " | Top 5's: " + str(car.dvr.topfives) + " | Top 10's: " + str(car.dvr.toptens) + " |  Races Completed: " + str(car.dvr.races) + '\n'
            racelistbox.insert(END,  display)
        playofflabel1 = Label(playoffwindow, text="Missed The Cut")
        playofflabel1.grid(row=2, column=0)
        racelistbox1 = Listbox(playoffwindow, width=80)
        racelistbox1.grid(row=4, column=0)
        for s in nextbest1:
            # print(schedule)
            car = assign(s)
            display = "#" + str(s) + " " + car.dvr.name + " | Points: " + str(car.dvr.pts) + " | Wins: " + str(car.dvr.wins) + " | Top 5's: " + str(car.dvr.topfives) + " | Top 10's: " + str(car.dvr.toptens) + " |  Races Completed: " + str(car.dvr.races) + '\n'
            racelistbox1.insert(END,  display)

    if week ==28:
        print("roundof12")
        finalfourcars = {}
        print(week)
        for i in mylist:
            car = assign(i)
            if car:
                finalfourcars[i] = car.dvr.pts
        finalfourcars1 = sorted(finalfourcars, key=finalfourcars.get, reverse=True)
        print("final four cars 1", finalfourcars1)
        for i in range(0,12):
            v = assign(finalfourcars1[i])
            v.dvr.pts = 7500
    if week ==31:
        print("roundof8")
        finalfourcars = {}
        print(week)
        for i in mylist:
            car = assign(i)
            if car:
                finalfourcars[i] = car.dvr.pts

        finalfourcars1 = sorted(finalfourcars, key=finalfourcars.get, reverse=True)
        print("final four cars 1", finalfourcars1)
        for i in range(0,8):
            v = assign(finalfourcars1[i])
            v.dvr.pts = 9000
    if week == 35:
        print("final4")
        finalfourcars = {}
        print(week)
        for i in mylist:
            car = assign(i)
            if car:
                finalfourcars[i] = car.dvr.pts

        finalfourcars1 = sorted(finalfourcars, key=finalfourcars.get, reverse=True)
        print("final four cars 1", finalfourcars1)
        for i in range(0,4):
            v = assign(finalfourcars1[i])
            v.dvr.pts = 10000







def selection():
    try:
        driverWindow = tk.Toplevel(root)
        driverWindow.geometry("400x300")
        myLabel4 = Label(driverWindow, text="Driver Statistics:")
        myLabel4.grid(row=0, column=0)
    except:
        pass

def gui_schedule():
    # standings
    global schedule
    sceWindow = tk.Toplevel(root)
    sceWindow.geometry("800x250")
    # myLabel4.grid(row=0,column=0)
    racescrollbar = Scrollbar(sceWindow)
    racescrollbar.grid(row=9, column=40)

    racelistbox = Listbox(sceWindow, width=150)
    racelistbox.grid(row=9, column=50)
    for s in schedule:
        #print(schedule)
        racelistbox.insert(END, "Race " + s[0] + " at " + s[1] + " | Winner : " + s[2])


def gui_standings():
    # standings
    global mylist
    raceWindow = tk.Toplevel(root)
    raceWindow.geometry("800x250")
    # myLabel4.grid(row=0,column=0)
    racescrollbar = Scrollbar(raceWindow)
    racescrollbar.grid(row=9, column=40)

    racelistbox = Listbox(raceWindow, width=150)
    racelistbox.grid(row=9, column=50)
    stg = standing(mylist)
    for i in stg.splitlines():
        racelistbox.insert(END, i)


def good_fit(dvr, team):
    print("check")
    print(team.prestige)
    print(team.team1, "team")
    print(dvr.name, "dvr112s2")
    if team.team1 == "Stewart-Haas Racing" and dvr.name == "Chase Briscoe":
        print("CHASE")
        return True
    if team.team1 == "Joe Gibbs Racing" and dvr.name == "Ty Gibbs":
        return True
    if team.team1 == "Petty Enterprises" and dvr.name == "Thad Moffit":
        return True
    if team.prestige > 80:
        if dvr.rating > 80:
            return True
    if team.prestige > 70:
        if dvr.rating > 70:
            return True
    if team.prestige > 70 and dvr.age > 33 and dvr.rating < 70:
        return False
    if dvr.team == team.team1:
        return True
    if dvr.dvrmanu == team.manu:
        return True

    return False


def clean(rosterlist):
    global freeagentlist
    for d in freeagentlist:
        if d.dvr.name in rosterlist:
            freeagentlist.remove(d)
        if d.dvr.name == "N/A":
            freeagentlist.remove(d)


def president_event():
    rtn = ""
    global year
    global president
    global president_yr
    if year == 2007 or year == 2008:
        running_d = ["Barack Obama", "Joe Biden", "Hillary Clinton"]
        running_r = ["John McCain", "Mitt Romney", "Ron Paul"]
        running_3 = ["Rand Paul", "Jill Stein"]
    if year == 2011 or year == 2012:
        running_d = ["Barack Obama", "Tim Kane", "Joe Biden", "Hillary Clinton"]
        running_r = ["John McCain", "Mitt Romney", "Newt Gingrich", "Paul Ryan", "Rick Perry", "Herman Cain"]
        running_3 = ["Jill Stein", "Gary Johnson"]
    if year == 2015 or year == 2016:
        running_d = ["Tim Kane", "Joe Biden", "Hillary Clinton", "Bernie Sanders"]
        running_r = ["Donald Trump", "Mitt Romney", "Ted Cruz", "Paul Ryan", "Jeb Bush", "Chris Christie", "Ben Carson"]
        running_3 = ["Jill Stein", "Gary Johnson", "Joe Exotic"]
    if year == 2019 or year == 2020:
        running_d = ["Tim Kane", "Joe Biden", "Hillary Clinton", "Bernie Sanders", "Pete Buttigeig", "Michael Bloomberg", "Andrew Yang"]
        running_r = ["Donald Trump", "Mitt Romney", "Ted Cruz", "Paul Ryan", "Jeb Bush",
                     "Chris Christie", "Ben Carson", "Hulk Hogan", "Kanye West", "Mike Pence", "Linda McMahon"]
        running_3 = ["Jill Stein", "Gary Johnson", "Gary Oldman"]
    if year == 2023 or year == 2024:
        running_d = ["Tim Kane", "Joe Biden", "Hillary Clinton", "Bernie Sanders", "Pete Buttigeig", "Michael Bloomberg", "Andrew Yang"]
        running_r = ["Donald Trump", "Mitt Romney", "Ted Cruz", "Paul Ryan", "Jeb Bush",
                     "Chris Christie", "Ben Carson", "Hulk Hogan", "Kanye West", "Mike Pence", "Vince McMahon"]
        running_3 = ["Jill Stein", "Gary Johnson", "Gary Oldman", "Vermin Surpeme", "Dan Behrman", "Christan Weston Chandler"]
    if year > 2024:
        running_d = ["Tim Kane", "Joe Biden", "Hillary Clinton", "Pete Buttigeig", "Michael Bloomberg", "Andrew Yang", "Corey Booker", "The Rock", "Kendrick Lamar"]
        running_r = ["Donald Trump", "Mitt Romney", "Ted Cruz", "Paul Ryan", "Jeb Bush", "Eric Trump",
                     "Chris Christie", "Ben Carson", "Hulk Hogan", "Kanye West", "Mike Pence", "Linda McMahon", "George Bush III"]
        running_3 = ["Jill Stein", "Gary Johnson", "Gary Oldman", "Christan Weston Chander", "Harrison Ford", "Salman Kahn"]


    odds = []
    score = []
    loserscore = []
    for o in range(1, 101):
        odds.append(o)
    #test = president[0]
    choice = random.choice(odds)
    if president_yr > 6:
        president = []
        if choice < 46 :
            president.append(random.choice(running_d))
            president.append("Democrat")
            president_yr = 1
            rtn = "American Politics: Democrat Candidate " + president[0] + " has become President!"
        if choice >= 46 and choice < 92 :
            president.append(random.choice(running_r))
            president.append("Republican")
            president_yr = 1
            rtn = "American Politics: Republican Candidate " + president[0] + " has become President!"
        if choice >= 92:
            president.append(random.choice(running_3))
            president.append("Third Party")
            president_yr = 1
            rtn = "American Politics: Third Party Candidate " + president[0] + " has become President in a massive upset!"
    else:

        if choice < 50 and president[1] == "Democrat" or president[1] == "Third Party":
            president = []
            president.append(random.choice(running_r))
            president.append("Republican")
            president_yr = 1
            rtn = "American Politics: Republican Candidate " + president[0] + " has become President!"
        if choice < 50 and president[1] == "Republican":
            president = []
            if choice < 45:
                president.append(random.choice(running_d))
                president.append("Democrat")
                president_yr = 1
                rtn = "American Politics: Democrat Candidate " + president[0] + " has become President!"
            if choice >= 45:
                president.append(random.choice(running_3))
                president.append("Third Party")
                president_yr = 1
                rtn = "American Politics: Third Party Candidate " + president[0] + " has become President in a massive upset!"
        if choice >= 50:
            rtn = "American Politics: The Incumbent President wins the election and will have a second term in office"

    print(president, "!!!!!!!!!!!!!!!!!!!!!!!")
    return rtn



def title_event():
    global sponsorlist
    global cup
    choice = sponsorlist.pop(random.randrange(len(sponsorlist)))
    cup = choice + " Cup Series"

def superbowl_event():
    global year
    global afc
    global nfc
    global cities
    global newnames
    rtn = ""
    odds = []
    for o in range(1, 101):
        odds.append(o)

    choice1 = random.choice(odds)
    if year > 2010:

        if choice1 < 25:
            afc1 = afc.pop(random.randrange(len(afc)))
            afc2 = afc1.split()
            afc2[-1] = random.choice(newnames)
            afc1 = ""
            for s in afc2:
                afc1 += s + " "
            print(afc2, "ass2")
            afc.append(afc1)
        if choice1 >= 25 and choice1 < 50:
            nfc1 = nfc.pop(random.randrange(len(nfc)))
            nfc2 = nfc1.split()
            nfc2[-1] = random.choice(newnames)
            nfc1 = ""
            for s in nfc2:
                nfc1 += s + " "
            print(nfc2, "ass2")
            afc.append(nfc1)
        if choice1 >= 50 and choice1 < 75:
            afc1 = afc.pop(random.randrange(len(afc)))
            afc2 = afc1.split()
            afc1 = "The " + random.choice(cities) + " " + afc2[-1]
            afc.append(afc1)
        if choice1 >= 75:
            nfc1 = nfc.pop(random.randrange(len(nfc)))
            nfc2 = nfc1.split()
            afc1 = "The " + random.choice(cities) + " " + nfc2[-1]
            nfc.append(nfc1)


    afcchoice = random.choice(afc)
    nfcchoice = random.choice(nfc)
    odds = []
    score = []
    loserscore = []
    for o in range(1, 101):
        odds.append(o)
    for s in range(10, 51):
        score.append(s)
    winner = random.choice(score)
    for l in range(3, winner-1):
        loserscore.append(l)
    loser = random.choice(loserscore)
    if loser == "4" or loser == "5":
        loser = "7"
    choice = random.choice(odds)
    if choice < 50:
        rtn += "Football: " + nfcchoice + " defeated " + afcchoice + " in the Super Bowl " + str(winner) + " - " + str(loser)
        return rtn
    if choice >= 50:
        rtn += "Football: " + afcchoice + " defeated " + nfcchoice + " in the Super Bowl " + str(winner) + " - " + str(loser)
        return rtn

def nba_event():
    global year
    global east
    global west
    global cities
    global newnames
    rtn = ""
    odds = []
    for o in range(1, 101):
        odds.append(o)

    choice1 = random.choice(odds)
    if year > 2010:

        if choice1 < 25:
            afc1 = east.pop(random.randrange(len(east)))
            afc2 = afc1.split()
            afc2[-1] = random.choice(newnames)
            afc1 = ""
            for s in afc2:
                afc1 += s + " "
            print(afc2, "ass2")
            east.append(afc1)
        if choice1 >= 25 and choice1 < 50:
            nfc1 = west.pop(random.randrange(len(west)))
            nfc2 = nfc1.split()
            nfc2[-1] = random.choice(newnames)
            nfc1 = ""
            for s in nfc2:
                nfc1 += s + " "
            print(nfc2, "ass2")
            west.append(nfc1)
        if choice1 >= 50 and choice1 < 75:
            afc1 = east.pop(random.randrange(len(east)))
            afc2 = afc1.split()
            afc1 = "The " + random.choice(cities) + " " + afc2[-1]
            east.append(afc1)
        if choice1 >= 75:
            nfc1 = west.pop(random.randrange(len(west)))
            nfc2 = nfc1.split()
            afc1 = "The " + random.choice(cities) + " " + nfc2[-1]
            west.append(nfc1)


    east1 = random.choice(east)
    west1 = random.choice(west)
    odds = []
    score = []
    loserscore = []
    for o in range(1, 101):
        odds.append(o)
    choice = random.choice(odds)
    if choice < 50:
        rtn += "Basketball: " + east1 + " defeated " + west1 + " in the NBA Finals"
        return rtn
    if choice >= 50:
        rtn += "Basketball: " + west1 + " defeated " + east1 + " in the NBA Finals"
        return rtn

def wrestling_event():
    global year
    global wrestlemania
    rtn = ""
    if year > 2004 and year < 2007:
        wrestlers = ["Shawn Michaels", "Edge", "Chris Benoit", "John Cena", "Batista", "Randy Orton", "Triple H", "Mark Henry", "The Undertaker",
                     "The Big Show", "Kane", "Bobby Lashley", "Umaga", "CM Punk", "Chris Jericho", "Ric Flair", "The Rock", "Rey Mysterio", "Jeff Hardy"]
    if year >= 2007 and year < 2011:
        wrestlers = ["Shawn Michaels", "Edge", "John Cena", "Batista", "Randy Orton", "Triple H", "Mark Henry",
                     "The Undertaker", "The Great Khali",
                     "The Big Show", "Kane", "John Morrison", "Bobby Lashley", "Umaga", "CM Punk", "Chris Jericho",
                     "The Miz", "The Rock", "Rey Mysterio", "Jeff Hardy"]
    if year >= 2011 and year < 2015:
        wrestlers = ["Brock Lesnar", "Ryback", "John Cena", "Wade Barrett", "Randy Orton", "Triple H", "Mark Henry",
                     "The Undertaker", "Kane",
                     "The Big Show", "John Morrison", "CM Punk", "Chris Jericho", "The Miz", "The Rock", "Rey Mysterio", "Sheamus"]
    if year >= 2015 and year < 2022:
        wrestlers = ["AJ Styles", "Adam Cole", "Brock Lesnar", "Seth Rollins", "Roman Reigns",
                     "Daniel Bryan", "Batista", 'Goldberg', "John Cena", "Randy Orton", "Triple H",
                     "The Undertaker", "Chris Jericho", "Samoa Joe", "Kevin Owens", "Shinsuke Nakamura", "Sting", "Bray Wyatt", "Braun Strowman",
                     "The Big Show", "Kofi Kingston", "CM Punk", "The Rock", "Sheamus", "Jeff Hardy", "The Undertaker"]
    if year >= 2022 and year < 2030:
        wrestlers = ["AJ Styles", "Adam Cole", "WALTER", "Pete Dunne", "Keith Lee", "Seth Rollins", "Dean Ambrose", "Roman Reigns",
                     "Daniel Bryan", "Samoa Joe", "Shinsuke Nakamura", "Bray Wyatt", "Braun Strowman",
                    "Big E", "Kofi Kingston", "Andrade", "Drew McIntyre", "Johnny Gargano", "Tomasso Ciampa", "Austin Theory", "Rob Gronkowski", "Mojo Rawley",
                     "Sheamus", "Jeff Hardy", "Kenny Omega", "MJF", "Mustafa Ali", "Cedric Alexander", "Cesaro", "Sami Zayn", "Orange Cassidy"]
    if year >= 2030:
        wrestlers = ["Braun Strowman", "Xavier Woods", "Sammy Guevara", "Darby Allin", "MJF", "Ric Flair Jr", "WALTER", "Pete Dunne", "Keith Lee", "Kyle Busch", "Michael Waltrip", "Dominic Mysterio", "The Barbarian Jr", "Junior Mahal"
                    "Big E", "Ice Cream III", "Villano 16", "Maxel Hardy", "Sami Zayn", "El Generico", "Luke Lesnar",
                     "Mustafa Ali", "Bruce Hart Jr",
                     "Cedric Alexander", "Randy Orton Jr", "Scott Speed", "Rob Gronkowski", "Grown Up Nicholas", "Andrade", "Angel Garza", "Johnny Gargano", "Tomasso Ciampa", "Austin Theory", "Orange Cassidy"]

    stip = ["Singles Match", "Singles Match", "Singles Match", "TLC Match", "Hell in a Cell Match", "Light Tubes Match", "Tournament Finale",
            "Ladder Match", "WWE vs United States Title Match", "Stairs Match", "Chairs Match", "Extreme Rules Match", "60 Minute Iron Man Match",
            "30 Minute Iron Man Match", "2/3 Falls Match", "2/3 Tables Match", "Boneyard Match", "Scaffold Match", "Loser Leaves the Brand Match",
            "2/3 Light Tubes Match", "Sledgehammer on a Pole", "Buried Alive Match", "2/3 Buried Alive Match", "Title vs Undefeated Streak"]

    winner = wrestlers.pop(random.randrange(len(wrestlers)))
    loser = wrestlers.pop(random.randrange(len(wrestlers)))
    match = stip.pop(random.randrange(len(stip)))
    rtn += "Wrestling: " + winner + " defeated " + loser + " in the Main Event of Wrestlemania " + str(wrestlemania) + " in a " + match
    wrestlemania += 1
    return rtn

def sponsor_event():
    global mylist
    global mylist_real
    global sponsorlist
    rtn = ""
    for i in mylist:
        mylist_real.append(i)
    if len(sponsorlist) > 0:
        choice = sponsorlist.pop(random.randrange(len(sponsorlist)))
        num = random.choice(mylist_real)
        car = assign(num)
        if car:
            print("sponsor!!!! ", choice)
            old = car.sponsor
            car.sponsor = choice
            sponsorlist.append(old)
            rtn += car.team1 + " #" + str(car.num1) + " - " + car.dvr.name + " has a new sponsor: " + choice
        return rtn


def add(num):
    global mylist
    global mylist_inactive
    global mylist_real
    print('MYLIST', mylist)
    print('MYLIST REAL', mylist)
    if num == "46":
        print("46suckmydix")
    for i in range (int(num), 100):
        if str(i+1) in mylist:
            print(str(i+1))
            if i in mylist_real:
                index = mylist_real.index(str(i+1))
                mylist_real.insert(index, num)
            if i not in mylist:
                mylist.add(num)
                print("added this numba", num)
            if num in mylist_inactive:
                mylist_inactive.remove(num)
            print(mylist)
            return

def retirement(sillylistbox=None, sillyWindow=None):

    global schedule
    schedule = [["1", "Daytona" , "N/A"],  ["2", "Las Vegas" , "N/A"], ["3", "Fontana" , "N/A"], ["4", "Phoenix" , "N/A"], ["5", "Atlanta", "N/A"],
            ["6", "Homestead", "N/A"], ["7", "Texas" , "N/A"],  ["8", "Bristol" , "N/A"], ["9", "Richmond" , "N/A"], ["10", "Talladega" , "N/A"], ["11", "Dover" , "N/A"],
            ["12", "Martinsville", "N/A"], ["13", "Charlotte", "N/A"], ["14", "Kansas" , "N/A"],  ["15", "Michigan" , "N/A"], ["16", "Sonoma" , "N/A"], ["17", "Pocono", "N/A"],
            ["18", "Pocono" , "N/A"], ["19", "Indianapolis", "N/A"], ["20", "Kentucky" , "N/A"],  ["21", "New Hampshire" , "N/A"], ["22", "Watkins Glen" , "N/A"], ["23", "Michigan", "N/A"],
            ["24", "Dover" , "N/A"], ["25", "Daytona", "N/A"], ["26", "Darlington" , "N/A"],  ["27", "Richmond" , "N/A"], ["28", "Bristol" , "N/A"], ["29", "Las Vegas", "N/A"],
            ["30", "Talladega" , "N/A"], ["31", "Charlotte ROVAL", "N/A"], ["32", "Kansas" , "N/A"],  ["33", "New Hampshire" , "N/A"], ["34", "Texas" , "N/A"], ["35", "Martinsville", "N/A"],
            ["36", "Phoenix", "N/A"]]

    gui_string = ""
    global year
    global freeagentlist
    global mylist
    odds = []
    for o in range(1, 101):
        odds.append(o)
    global PlayerUno
    candidates = []
    rosterlist = []
    for x in mylist:
        team = assign(x)
        if team:
            rosterlist.append(team.dvr.name)

    clean(rosterlist)



    r = sponsor_event()
    #sillylistbox.insert(END, r)
    for drive in freeagentlist:
        # print("FREE AGENT - ", drive.dvr.name)
        if drive.dvr.name not in rosterlist and drive not in candidates:
            # print("ok 1", drive.dvr.name)
            if drive.dvr.moveyear + 2 < year or drive.dvr.moveyear == 0:
                print("cachinga", drive.dvr.name)
                if drive.dvr.age > 24:
                    candidates.append(drive)
                    # sillylistbox.insert(END, drive.dvr.name + " is a candidate! " + str(year) + " their moveyear: " + str(drive.dvr.moveyear))

    open = []
    retirements = []
    swaps = []

    new_retirements = []


    global toptwenty
    mylist_copy = {}
    mylist_copy = mylist
    for x in mylist_copy:
        team = assign(x)
        if team:
            if team.dvr.age > 41 and team.dvr.age <= 44:
                chance = random.choice(odds)
                # print("CHANCE IS: ", chance)
                if chance < 15:
                    print(team.dvr.name, "name is")
                    open.append(team)
                    retirements.append(str(team.dvr.name))
                    temp = []
                    temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                            str(team.dvr.totaltopfives),
                            str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                    new_retirements.append(temp)

            if team.dvr.age > 45 and team.dvr.age <= 48:
                chance = random.choice(odds)
                # print("CHANCE IS: ", chance)
                if chance < 50:
                    print(team.dvr.name, "name is")
                    open.append(team)
                    retirements.append(str(team.dvr.name))
                    temp = []
                    temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                                str(team.dvr.totaltopfives),
                                str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                    new_retirements.append(temp)

            if team.dvr.age > 48 and team.dvr.age <= 51:
                chance = random.choice(odds)
                # print("CHANCE IS: ", chance)
                if chance < 70:
                    print(team.dvr.name, "name is")
                    open.append(team)
                    retirements.append(str(team.dvr.name))
                    temp = []
                    temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                            str(team.dvr.totaltopfives),
                            str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                    new_retirements.append(temp)

            if team.dvr.age > 51 and team.dvr.age <= 53:
                chance = random.choice(odds)
                # print("CHANCE IS: ", chance)
                if chance < 90:
                    print(team.dvr.name, "name is")
                    open.append(team)
                    retirements.append(str(team.dvr.name))
                    temp = []
                    temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                            str(team.dvr.totaltopfives),
                            str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                    new_retirements.append(temp)

            if team.dvr.age > 53:
                print(team.dvr.name, "name is")
                open.append(team)
                retirements.append(str(team.dvr.name))
                temp = []
                temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins), str(team.dvr.totaltopfives),
                        str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                new_retirements.append(temp)
    power_ranking = {}
    for team in freeagentlist:
        if team.dvr.age > 41 and team.dvr.age <= 44:
            chance = random.choice(odds)
            # print("CHANCE IS: ", chance)
            if chance < 5:
                print(team.dvr.name, "name is")
                #open.append(team)
                freeagentlist.remove(team)
                retirements.append(str(team.dvr.name))
                temp = []
                temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                        str(team.dvr.totaltopfives),
                        str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                new_retirements.append(temp)

        if team.dvr.age > 45 and team.dvr.age <= 48:
            chance = random.choice(odds)
            # print("CHANCE IS: ", chance)
            if chance < 20:
                print(team.dvr.name, "name is")
                retirements.append(str(team.dvr.name))
                freeagentlist.remove(team)
                temp = []
                temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                        str(team.dvr.totaltopfives),
                        str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                new_retirements.append(temp)

        if team.dvr.age > 48 and team.dvr.age <= 51:
            chance = random.choice(odds)
            # print("CHANCE IS: ", chance)
            if chance < 40:
                print(team.dvr.name, "name is")
                freeagentlist.remove(team)
                retirements.append(str(team.dvr.name))
                temp = []
                temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                        str(team.dvr.totaltopfives),
                        str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                new_retirements.append(temp)


        if team.dvr.age > 51 and team.dvr.age <= 53:
            chance = random.choice(odds)
            # print("CHANCE IS: ", chance)
            if chance < 70:
                print(team.dvr.name, "name is")
                freeagentlist.remove(team)
                retirements.append(str(team.dvr.name))
                temp = []
                temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins),
                        str(team.dvr.totaltopfives),
                        str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
                new_retirements.append(temp)

        if team.dvr.age > 53:
            print(team.dvr.name, "name is")
            freeagentlist.remove(team)
            retirements.append(str(team.dvr.name))
            temp = []
            temp = [str(team.dvr.name), str(team.dvr.t), str(team.dvr.totalwins), str(team.dvr.totaltopfives),
                str(team.dvr.totaltoptens), str(team.dvr.totalraces)]
            new_retirements.append(temp)

            # print("Safelist", toptwenty)
    ded = []
    team2 = None
    global counter
    counter = 0
    for x in mylist_copy:
        team = assign(x)
        if team and team.dvr not in retirements:
            if team.parttime or team.deepparttime:
                chance = random.choice(odds)
                if chance >= 20 and chance < 30:
                    #sillylistbox.insert(END,
                    #                    team.team1 + " - #" + str(team.num1) + " has moved to a full time schedule!")
                    team.parttime = False
                    team.deepparttime = False

            if str(team.num1) not in toptwenty:
                chance = random.choice(odds)
                # print("CHANCE IS: ", chance)
                if team not in open and team not in candidates and team.dvr.unsackable == False and team.dvr.moved == False:
                    if team.team1 != PlayerUno.organization.orgname:
                        if team.dvr.moveyear + 2 < year or team.dvr.moveyear == 0:
                            team.dvr.morale -= 20
                            print(chance, "chance was")
                            if chance < 15:
                                print("NOT SAFe:", team.dvr.name)
                                swaps.append(team)
                                open.append(team)
                                temp5 = copy.deepcopy(team)
                                candidates.append(temp5)
                                candidates.append(temp5)
                                team.dvr = Driver(name="N/A")
                                # sillylistbox.insert(END, team.dvr.name + " has left!")
                            else:
                                print("YES SAFe:", team.dvr.name)
                            if chance >= 20 and chance < 30:
                                if team.dvr.rating < 70:
                                    #sillylistbox.insert(END, team.team1 + " - #" + str(team.num1) + " has moved to a part time schedule!")
                                    team.parttime = True
                            global mylist1
                            if chance > 40 and chance <= 42:
                                print("DA CHANCE WAS", chance)
                                ded.append(team)

            if team.dvr not in candidates and team.dvr not in retirements:
                if drive.dvr.moveyear + 2 < year or drive.dvr.moveyear == 0:
                    if team.dvr:
                        if team.dvr.morale < 40 and team.dvr.morale > 0 and team.dvr.unsackable is False:
                            swaps.append(team)
                            open.append(team)
                            candidates.append(team)
                            # sillylistbox.insert(END, team.dvr.name + " has left!")


            if team.yrsleft <= 0:
                if team.dvr:
                    if counter < 1:
                        if team in PlayerUno.organization.orgteams:
                            for i in PlayerUno.organization.orgteams:
                                if i.dvr not in retirements:
                                    print(str(i.num1), "NUM22221")
                                    if i.num1 == team.num1:
                                        #input("Press Enter to continue...")
                                        counter += 1
                                        newtk1 = Tk()
                                        team2 = i
                                        Label(newtk1, text=i.dvr.name + " wants a 2 year contract extension!").grid(
                                            row=0, column=0, columnspan=2)

                                        def fire():
                                            global selectedCar
                                            fire1 = Tk()
                                            fire1.geometry("600x230")
                                            Label(fire1, text="Has left: " + str(i.dvr.name)).grid(row=0,
                                                                                                          column=0,
                                                                                                          columnspan=2)
                                            mylist.remove(str(i.num1))
                                            temp = copy.deepcopy(i)
                                            i.active = False
                                            i.dvr = None
                                            freeagentlist.append(temp)
                                            freelist.append(temp.dvr)
                                            candidates.remove(temp)
                                            if team in open:
                                                    open.remove(team)
                                            newtk1.destroy()
                                                # candidates.remove(temp)

                                        def accept():
                                            print(str(team2.yrsleft), "wells fargo")
                                            team2.yrsleft += 2
                                            print("accepted", str(team2.num1))
                                            newtk1.destroy()
                                            if i in open:
                                                open.remove(i)

                                        def decline():

                                            newtk1.destroy()
                                            pass


                                        button1 = Button(newtk1, text="Accept", width=20, height=2,
                                                         command=accept)
                                        button1.grid(row=1, column=0)
                                        button2 = Button(newtk1, text="Decline", width=20, height=2,
                                                         command=fire)
                                        button2.grid(row=1, column=1)

                    else:
                        print("c", team.dvr.name)
                        if team not in candidates and team.dvr not in retirements:
                            swaps.append(team)
                            open.append(team)
                            candidates.append(team)

                        for i in PlayerUno.organization.orgteams:
                            print(str(i.num1), "NUM1")
                            if i.num1 == team.num1:
                                newtk = Tk()
                                print("weight loss")
                                Label(newtk, text=i.dvr.name + " has left").grid(row=0, column=0, columnspan=2)

                                def fire():
                                    # global selectedCar
                                    # fire1 = Tk()
                                    # fire1.geometry("600x230")
                                    # Label(fire1, text="Fired: " + str(team.dvr.name)).grid(row=0, column=0,
                                    #   columnspan=2)
                                    # mylist.remove(str(team.num1))
                                    temp = copy.deepcopy(team)
                                    team.active = False
                                    team.dvr = None
                                    freeagentlist.append(temp)
                                    freelist.append(temp.dvr)
                                    if team in open:
                                        open.remove(team)
                                    # candidates.remove(temp)

                                fire()


                    '''
                    if team.dvr.age < 26 and team.dvr.age > 19:
                        if team.dvr.morale < 70 and team.dvr.morale > 0:
                            chance = random.choice(odds)
                            print("CHANCE IS: ", chance)
                            if chance < 30:
                                swaps.append(team)
                                candidates.append(team)
                                sillylistbox.insert(END, team.dvr.name + " has left!")
                                if team.prestige > 60:
                                    open.append(team)
                                    print(team.num1, "shut down")
                                else:
                                    chance = random.choice(odds)
                                    print("CHANCE IS: ", chance)
                                    if chance < 90:
                                        open.append(team)
                                    else:
                                        print(team.num1, "shut down 2")
                                        temp = team.dvr
                                        FreeAgentX = Team(9999, temp)
                                        team.active = False
                        '''

                # candidates.append(team)

            # print("Candidate #", stupid, " ", z.dvr.name)





    ss1 = Tk()
    Label(ss1, text="Silly Season").grid(row=0, column=0)
    Label(ss1, text="Retiring Drivers").grid(row=1, column=0)
    print("EEEEEEEEEE", retirements)
    lb1 = Listbox(ss1, width=70)

    if len(retirements) > 0:
        for i in retirements:
            print(i)
            lb1.insert(END, i)
    lb1.grid(row=2, column=0)
    Label(ss1, text="Free Agent Drivers").grid(row=3, column=0)
    lb2 = Listbox(ss1, width=70)
    lb2.grid(row=4, column=0)
    for i in candidates:
        if candidates.count(i) > 1:
            candidates.remove(i)
        if i.dvr:
            lb2.insert(END, i.dvr.name)
        else:
            candidates.remove(i)
    Label(ss1, text="Your Open Rides").grid(row=5, column=0)
    lb3 = Listbox(ss1, width=70)
    lb3.grid(row=6, column=0)

    for i in PlayerUno.organization.orgteams:
        if i.dvr is None:
            lb3.insert(END, str(i.num1) )




    def freeagentscouter():
        global PlayerUno
        myteamWindow1 = Tk()
        myteamWindow1.geometry("500x230")
        myteamWindow1.title("MyTeam Edit Information")
        # button2 = Button(myteamWindow1, text="Free Agent Scouter", width=20, height=2, command=freeagentscouter)
        # button2.grid(row=5, column=0, columnspan=1

        racelistbox = Listbox(myteamWindow1, width=80)
        racelistbox.grid(row=1, column=0, columnspan=2)
        free = []
        for i in freeagentlist:
            free.append(i.dvr)
        print(free)
        free1 = sorted(free, key=lambda Driver: Driver.rating, reverse=True)
        for i in free1:
            if i.age > 19:
                racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

        def sort_age():
            racelistbox.delete('0', 'end')
            free1 = sorted(free, key=lambda Driver: Driver.age, reverse=True)
            for i in free1:
                if i.age > 19:
                    racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

        def sort_rating():
            racelistbox.delete('0', 'end')
            free1 = sorted(free, key=lambda Driver: Driver.rating, reverse=True)
            for i in free1:
                if i.age > 19:
                    racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

        button1 = Button(myteamWindow1, text="Sort by Age", width=20, height=2, command=sort_age)
        button1.grid(row=3, column=0)

        button2 = Button(myteamWindow1, text="Sort by Rating", width=20, height=2, command=sort_rating)
        button2.grid(row=3, column=1)

    def new():
        global PlayerUno
        global selectedCar
        newW = Tk()
        newW.geometry("600x230")
        global numlist

        def newfulltime():
            PlayerUno.organization.money -= 200000
            button1.destroy()
            newL.destroy()
            newL2 = Label(newW, text="Select Car #")
            newL2.grid(row=0, column=0)
            # nice = Entry(newW)
            # nice.grid(row=0, column=1)
            global variable12
            variable12 = StringVar(newW)
            variable12.set(numlist[0])
            # print("USER ENTRY", user_entry)
            w = OptionMenu(newW, variable12, *numlist)
            w.grid(row=1, column=0, columnspan=2)

            def ok():
                global PlayerUno
                global variable12
                tem = variable12.get()
                print("SKIDDIDY BOP", tem)

                if tem == "0":
                    Driver0.active = True
                    Driver0.dvr = None
                    Driver0.manu = PlayerUno.organization.orgmanu
                    Driver0.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver0)
                    # mylist.add("59")
                    numlist.remove("0")
                if tem == "01":
                    Driver01.active = True
                    Driver01.dvr = None
                    Driver01.manu = PlayerUno.organization.orgmanu
                    Driver01.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver01)
                    # mylist.add("59")
                    numlist.remove("01")
                if tem == "02":
                    Driver02.active = True
                    Driver02.dvr = None
                    Driver02.manu = PlayerUno.organization.orgmanu
                    Driver02.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver02)
                    # mylist.add("59")
                    numlist.remove("02")
                if tem == "5":
                    Driver5.active = True
                    Driver5.dvr = None
                    Driver5.manu = PlayerUno.organization.orgmanu
                    Driver5.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver5)
                    # mylist.add("59")
                    numlist.remove("5")
                if tem == "7":
                    Driver7.active = True
                    Driver7.dvr = None
                    Driver7.manu = PlayerUno.organization.orgmanu
                    Driver7.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver7)
                    # mylist.add("59")
                    numlist.remove("7")
                if tem == "23":
                    Driver23.active = True
                    Driver23.dvr = None
                    Driver23.manu = PlayerUno.organization.orgmanu
                    Driver23.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver23)
                    # mylist.add("59")
                    numlist.remove("23")
                if tem == "26":
                    Driver26.active = True
                    Driver26.dvr = None
                    Driver26.manu = PlayerUno.organization.orgmanu
                    Driver26.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver26)
                    # mylist.add("59")
                    numlist.remove("26")
                if tem == "30":
                    Driver30.active = True
                    Driver30.dvr = None
                    Driver30.manu = PlayerUno.organization.orgmanu
                    Driver30.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver30)
                    # mylist.add("59")
                    numlist.remove("30")
                if tem == "31":
                    Driver31.active = True
                    Driver31.dvr = None
                    Driver31.manu = PlayerUno.organization.orgmanu
                    Driver31.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver31)
                    # mylist.add("59")
                    numlist.remove("31")
                if tem == "33":
                    Driver33.active = True
                    Driver33.dvr = None
                    Driver33.manu = PlayerUno.organization.orgmanu
                    Driver33.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver33)
                    # mylist.add("59")
                    numlist.remove("33")
                if tem == "40":
                    Driver40.active = True
                    Driver40.dvr = None
                    Driver40.manu = PlayerUno.organization.orgmanu
                    Driver40.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver40)
                    # mylist.add("59")
                    numlist.remove("40")
                if tem == "44":
                    Driver44.active = True
                    Driver44.dvr = None
                    Driver44.manu = PlayerUno.organization.orgmanu
                    Driver44.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver44)
                    # mylist.add("59")
                    numlist.remove("44")
                if tem == "45":
                    Driver45.active = True
                    Driver45.dvr = None
                    Driver45.manu = PlayerUno.organization.orgmanu
                    Driver45.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver45)
                    # mylist.add("59")
                    numlist.remove("45")
                if tem == "46":
                    Driver46.active = True
                    Driver46.dvr = None
                    Driver46.manu = PlayerUno.organization.orgmanu
                    Driver46.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver45)
                    # mylist.add("59")
                    numlist.remove("46")
                if tem == "50":
                    Driver50.active = True
                    Driver50.dvr = None
                    Driver50.manu = PlayerUno.organization.orgmanu
                    Driver50.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver50)
                    # mylist.add("59")
                    numlist.remove("50")
                if tem == "52":
                    Driver52.active = True
                    Driver52.dvr = None
                    Driver52.manu = PlayerUno.organization.orgmanu
                    Driver52.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver52)
                    # mylist.add("59")
                    numlist.remove("52")
                if tem == "57":
                    Driver57.active = True
                    Driver57.dvr = None
                    Driver57.manu = PlayerUno.organization.orgmanu
                    Driver57.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver57)
                    # mylist.add("59")
                    numlist.remove("57")
                if tem == "59":
                    Driver59.active = True
                    Driver59.dvr = None
                    Driver59.manu = PlayerUno.organization.orgmanu
                    Driver59.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver59)
                    # mylist.add("59")
                    numlist.remove("59")
                if tem == "60":
                    Driver60.active = True
                    Driver60.dvr = None
                    Driver60.sponsor = None
                    Driver60.manu = PlayerUno.organization.orgmanu
                    Driver60.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver60)
                    # mylist.add("59")
                    numlist.remove("59")
                if tem == "69":
                    Driver69.active = True
                    Driver69.dvr = None
                    Driver69.sponsor = None
                    Driver69.manu = PlayerUno.organization.orgmanu
                    Driver69.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver69)
                    # mylist.add("59")
                    numlist.remove("69")
                if tem == "70":
                    Driver70.active = True
                    Driver70.dvr = None
                    Driver70.sponsor = None
                    Driver70.manu = PlayerUno.organization.orgmanu
                    Driver70.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver70)
                    # mylist.add("59")
                    numlist.remove("70")
                if tem == "72":
                    Driver72.active = True
                    Driver72.dvr = None
                    Driver72.sponsor = None
                    Driver72.manu = PlayerUno.organization.orgmanu
                    Driver72.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver72)
                    # mylist.add("59")
                    numlist.remove("72")
                if tem == "78":
                    Driver78.active = True
                    Driver78.dvr = None
                    Driver78.sponsor = None
                    Driver78.manu = PlayerUno.organization.orgmanu
                    Driver78.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver78)
                    # mylist.add("59")
                    numlist.remove("78")
                if tem == "79":
                    Driver79.active = True
                    Driver79.dvr = None
                    Driver79.sponsor = None
                    Driver79.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver79)
                    Driver79.manu = PlayerUno.organization.orgmanu
                    # mylist.add("93")
                    numlist.remove("93")
                if tem == "80":
                    Driver80.active = True
                    Driver80.dvr = None
                    Driver80.sponsor = None
                    Driver80.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver80)
                    Driver80.manu = PlayerUno.organization.orgmanu
                    # mylist.add("93")
                    numlist.remove("80")
                if tem == "81":
                    Driver81.active = True
                    Driver81.dvr = None
                    Driver81.sponsor = None
                    Driver81.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver81)
                    Driver81.manu = PlayerUno.organization.orgmanu
                    # mylist.add("93")
                    numlist.remove("81")
                if tem == "83":
                    Driver83.active = True
                    Driver83.dvr = None
                    Driver83.sponsor = None
                    Driver83.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver83)
                    Driver83.manu = PlayerUno.organization.orgmanu
                    # mylist.add("93")
                    numlist.remove("83")
                if tem == "84":
                    Driver84.active = True
                    Driver84.dvr = None
                    Driver84.sponsor = None
                    Driver84.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver84)
                    Driver84.manu = PlayerUno.organization.orgmanu
                    # mylist.add("93")
                    numlist.remove("84")
                if tem == "91":
                    Driver91.active = True
                    Driver91.dvr = None
                    Driver91.sponsor = None
                    Driver91.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver91)
                    Driver91.manu = PlayerUno.organization.orgmanu
                    # mylist.add("93")
                    numlist.remove("91")
                if tem == "93":
                    Driver93.active = True
                    Driver93.dvr = None
                    Driver93.sponsor = None
                    Driver93.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver93)
                    Driver93.manu = PlayerUno.organization.orgmanu
                    # mylist.add("93")
                    numlist.remove("93")
                if tem == "94":
                    Driver94.active = True
                    Driver94.dvr = None
                    Driver94.team1 = PlayerUno.organization.orgname
                    Driver94.manu = PlayerUno.organization.orgmanu
                    PlayerUno.organization.orgteams.append(Driver94)
                    # mylist.add("94")
                    numlist.remove("94")
                if tem == "97":
                    Driver97.active = True
                    Driver97.dvr = None
                    Driver97.team1 = PlayerUno.organization.orgname
                    Driver97.manu = PlayerUno.organization.orgmanu
                    PlayerUno.organization.orgteams.append(Driver97)
                    # mylist.add("97")
                    numlist.remove("97")
                if tem == "98":
                    Driver98.active = True
                    Driver98.dvr = None
                    Driver98.sponsor = None
                    Driver98.manu = PlayerUno.organization.orgmanu
                    Driver98.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver98)
                    # mylist.add("98")
                    numlist.remove("98")
                if tem == "99":
                    Driver99.active = True
                    Driver99.dvr = None
                    Driver99.sponsor = None
                    Driver99.manu = PlayerUno.organization.orgmanu
                    Driver99.team1 = PlayerUno.organization.orgname
                    PlayerUno.organization.orgteams.append(Driver99)
                    # mylist.add("99")
                    numlist.remove("99")



            button = Button(newW, text="Submit", command=ok)
            button.grid(row=3, column=0)

        button1 = Button(newW, text="New Full Time Car", width=20, height=2, command=newfulltime)
        button1.grid(row=1, column=0)
        newL = Label(newW, text="Costs 200,000 thousand dollars")
        newL.grid(row=1, column=1)

        button2 = Button(newW, text="New Part Time Car2", width=20, height=2, command=newparttime)
        button2.grid(row=2, column=0)
        if PlayerUno.organization.money < 125000:
            button1["state"] = DISABLED
        if PlayerUno.organization.money > 125000:
            button1["state"] = ACTIVE
        newL = Label(newW, text="Costs 125,000 thousand dollars")
        newL.grid(row=2, column=1)


    def newtalent():  # NEWTALENT
        global PlayerUno
        myteamWindow1 = Tk()
        myteamWindow1.geometry("500x230")
        myteamWindow1.title("MyTeam Edit Information")
        # button2 = Button(myteamWindow1, text="Free Agent Scouter", width=20, height=2, command=freeagentscouter)
        # button2.grid(row=5, column=0, columnspan=1
        racelistbox = Listbox(myteamWindow1, width=80)
        racelistbox.grid(row=1, column=0, columnspan=2)
        free = []
        for i in freeagentlist:
            free.append(i.dvr)
        print(free)
        free1 = sorted(free, key=lambda Driver: Driver.rating, reverse=True)
        for i in free1:
            if i.age >= 16 and i.age <= 19:
                racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

        def sort_age():
            racelistbox.delete('0', 'end')
            free1 = sorted(free, key=lambda Driver: Driver.age, reverse=True)
            for i in free1:
                if i.age >= 16 and i.age < 19:
                    racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

        def sort_rating():
            racelistbox.delete('0', 'end')
            free1 = sorted(free, key=lambda Driver: Driver.rating, reverse=True)
            for i in free1:
                if i.age >= 16 and i.age <= 19:
                    racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

        button1 = Button(myteamWindow1, text="Sort by Age", width=20, height=2, command=sort_age)
        button1.grid(row=3, column=0)

        button2 = Button(myteamWindow1, text="Sort by Rating", width=20, height=2, command=sort_rating)
        button2 = Button(myteamWindow1, text="Sort by Rating", width=20, height=2, command=sort_rating)
        button2.grid(row=3, column=1)

    def firehire():
        mode = "Rating"
        global selectedCar
        firehire1 = Tk()
        firehire1.geometry("600x230")
        if selectedCar.dvr:
            Label(firehire1, text="Team: " + str(selectedCar.num1) + " Driver : " + selectedCar.dvr.name + " | Years Left on Contract: " + str(selectedCar.yrsleft)).grid(
                row=0, column=0, columnspan=2)

        else:
            Label(firehire1, text="Team: " + str(selectedCar.num1) + " Driver : None").grid(row=0, column=0,
                                                                                            columnspan=2)

        def fire():
            global selectedCar
            fire1 = Tk()
            fire1.geometry("600x230")
            Label(fire1, text="Fired: " + str(selectedCar.dvr.name)).grid(row=0, column=0, columnspan=2)
            mylist.remove(str(selectedCar.num1))
            temp = copy.deepcopy(selectedCar)
            selectedCar.active = False
            selectedCar.dvr = None
            freeagentlist.append(temp)
            freelist.append(temp.dvr)
            candidates.remove(temp)
            def ok():
                fire1.destroy()
                firehire1.destroy()

            button = Button(fire1, text="Ok", command=ok)
            button.grid(row=3, column=0)

        def hire():
            hire1 = Tk()
            hire1.geometry("500x230")
            hire1.title("Hire Driver")
            # button2 = Button(myteamWindow1, text="Free Agent Scouter", width=20, height=2, command=freeagentscouter)
            # button2.grid(row=5, column=0, columnspan=1

            racelistbox = Listbox(hire1, width=80)
            racelistbox.grid(row=1, column=0, columnspan=2)
            print("MAC6", candidates)
            free1 = []
            for i in candidates:
                if i:
                    if i.dvr:
                        free1.append(i.dvr)
                        print(i.dvr.name)
                else:
                    candidates.remove(i)
            #free1 = sorted(candidates, key=lambda Driver: Driver.rating, reverse=True)

            print(free1)
            for i in free1:
                if i.age > 19:
                    racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))
            Label(hire1, text="Double Click a Driver to Make an Offer").grid(row=3, column=0)
            '''
            def sort_age():
                racelistbox.delete('0', 'end')
                free1 = sorted(free, key=lambda Driver: Driver.age, reverse=True)
                for i in free1:
                    if i.age > 19:
                        racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

                mode = "Age"

            def sort_rating():
                racelistbox.delete('0', 'end')
                free1 = sorted(free, key=lambda Driver: Driver.rating, reverse=True)
                for i in free1:
                    if i.age > 19:
                        racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))
                mode = "Rating"

            button1 = Button(hire1, text="Sort by Age", width=20, height=2, command=sort_age)
            button1.grid(row=3, column=0)

            button2 = Button(hire1, text="Sort by Rating", width=20, height=2, command=sort_rating)
            button2.grid(row=3, column=1)

            '''

            def selectfa(event):
                global driver0
                widget = event.widget
                selection = widget.curselection()
                fa = widget.get(selection[0])
                # fa1 = (freeagentlist[(selection[0])]).dvr
                # if mode=
                # free1 = sorted(free, key=lambda Driver: Driver.rating, reverse=True)
                free2 = []
                for i in free1:
                    if i.age > 19:
                        free2.append(i)
                fa1 = (free2[(selection[0])])
                print(fa, fa1)
                neg = Tk()
                Label(neg, text="Negotiations with: " + str(fa1.name)).grid(row=0, column=0, columnspan=2)
                global amt
                great = []
                good = []
                ok = []
                bad = []
                years_young = [1, 2, 3, 4, 5]
                years_old = [1, 2]
                yr = 0
                def yes():
                    global driver0
                    print(driver0.name, "H3H3")
                    selectedCar.dvr = driver0
                    selectedCar.active = True
                    selectedCar.yrsleft = yr
                    print(selectedCar.yrsleft)
                    mylist.add(str(selectedCar.num1))
                    for i in freeagentlist:
                        if i.dvr.name == driver0.name:
                            freeagentlist.remove(i)
                    for i in freelist:
                        if i.name == driver0.name:
                            freelist.remove(i)
                    for i in candidates:
                        if i.dvr.name == driver0.name:
                            candidates.remove(i)


                    neg.destroy()
                    hire1.destroy()
                    firehire1.destroy()

                for i in range(1000, 2500):
                    if i % 10 == 0:
                        great.append(i)
                for i in range(750, 1500):
                    if i % 10 == 0:
                        good.append(i)
                for i in range(450, 800):
                    if i % 10 == 0:
                        ok.append(i)
                for i in range(250, 500):
                    if i % 10 == 0:
                        bad.append(i)

                driver0 = fa1

                if driver0.rating > selectedCar.prestige + 5:
                    Label(neg, text=str(fa1.name) + " is not interested in driving this car").grid(row=0, column=0, columnspan=2)
                else:
                    if driver0.age >= 40:
                        if driver0.rating >= 85:
                            val = random.choice(great)
                            val = val * 5
                            yr = random.choice(years_old)
                            Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                                val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                        if driver0.rating < 85 and driver0.rating >= 73:
                            val = random.choice(good)
                            val = val * 1.25
                            yr = random.choice(years_old)
                            Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                                val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                        if driver0.rating < 73 and driver0.rating >= 63:
                            val = random.choice(ok)
                            yr = random.choice(years_old)
                            Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                                val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                        if driver0.rating < 63:
                            val = random.choice(bad)
                            yr = random.choice(years_old)
                            Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                                val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)

                        button4 = Button(neg, text="Yes", width=20, height=2, command=yes)
                        button4.grid(row=2, column=0)

                    if driver0.age < 40:
                        if driver0.rating >= 85:
                            val = random.choice(great)
                            yr = random.choice(years_young)
                            Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                                val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                        if driver0.rating < 85 and driver0.rating >= 73:
                            val = random.choice(good)
                            yr = random.choice(years_young)
                            Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                                val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                        if driver0.rating < 73 and driver0.rating >= 63:
                            val = random.choice(ok)
                            yr = random.choice(years_young)
                            Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                                val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                        if driver0.rating < 63:
                            val = random.choice(bad)
                            yr = random.choice(years_young)
                            Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                                val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)

                        button4 = Button(neg, text="Yes", width=20, height=2, command=yes)
                        button4.grid(row=2, column=0)

            racelistbox.bind("<Double-Button-1>", selectfa)


        button2 = Button(firehire1, text="Fire Driver", width=20, height=2, command=fire)
        button2.grid(row=1, column=0)
        Label(firehire1,
              text="Warning: If you fire a driver and do not hire a replacement, your car will not be able to participate in any races! ").grid(
            row=2, column=0, columnspan=2)

        button3 = Button(firehire1, text="Hire Driver", width=20, height=2, command=hire)
        button3.grid(row=1, column=1)

        def upgrade_EQ():
            global PlayerUno
            print("spawn")
            selectedCar.prestige += 2
            if selectedCar.prestige > 100:
                selectedCar.prestige = 100

            PlayerUno.organization.money = PlayerUno.organization.money - 50000
            print("spawn")
            firehire1.destroy()

        button4 = Button(firehire1, text="Upgrade Equipment", width=20, height=2, command=upgrade_EQ)
        button4.grid(row=4, column=0)
        Label(firehire1,
              text="Pay $50,000 and upgrade car prestige by 2 ").grid(
            row=4, column=1, columnspan=2)
        if PlayerUno.organization.money < 50000:

            button4["state"] = DISABLED
        else:
            button4["state"] = ACTIVE

        if selectedCar.dvr:
            button2["state"] = ACTIVE
            button3["state"] = DISABLED
        else:
            button2["state"] = DISABLED
            button3["state"] = ACTIVE

        def sponsor():
            # for i in sponsorlist:
            a = random.choice(sponsorlist)
            b = random.choice(sponsorlist)
            c = random.choice(sponsorlist)

            print(a, b, c)
            sw = Tk()
            if selectedCar.prestige > 70:
                Label(sw,
                      text="Three sponsors have expressed interest in sponsoring your car, pick which one you would like").grid(
                    row=0, column=0, columnspan=3)
            if selectedCar.prestige <= 70 and selectedCar.prestige > 60:
                Label(sw,
                      text="Two sponsors have expressed interest in sponsoring your car, pick which one you would like").grid(
                    row=0, column=0, columnspan=3)
            if selectedCar.prestige <= 60:
                Label(sw,
                      text="No Sponsors have expressed interest in sponsoring your car, check again next week. Hint: the higher your car and team prestige, the more likely you are to attract sponsors.").grid(
                    row=0, column=0, columnspan=3)
            payout = []
            if PlayerUno.organization.orgprestige >= 90:
                payout = [20000, 19000, 18000, 17000, 16000, 15000, 14000, 13000]
            if PlayerUno.organization.orgprestige >= 80 and PlayerUno.organization.orgprestige < 90:
                payout = [15000, 14000, 13000, 12000, 11000, 10000, 9000, 8000]
            if PlayerUno.organization.orgprestige < 80:
                payout = [10000, 9000, 8000, 7000, 6000]

            payouta = random.choice(payout)
            payoutb = random.choice(payout)
            payoutc = random.choice(payout)

            def sa():
                selectedCar.sponsor = a
                PlayerUno.organization.money += payouta
                sw.destroy()

            def sb():
                selectedCar.sponsor = b
                PlayerUno.organization.money += payoutb
                sw.destroy()

            def sc():
                selectedCar.sponsor = c
                PlayerUno.organization.money += payoutc
                sw.destroy()

            if selectedCar.prestige > 60:
                buttona = Button(sw, text=a, width=20, height=2, command=sa)
                buttona.grid(row=1, column=0)
                Label(sw, text="Will Pay: " + str(payouta)).grid(row=2, column=0)
                buttonb = Button(sw, text=b, width=20, height=2, command=sb)
                buttonb.grid(row=1, column=1)
                Label(sw, text="Will Pay: " + str(payoutb)).grid(row=2, column=1)
                if selectedCar.prestige >= 70:
                    buttonc = Button(sw, text=c, width=20, height=2, command=sc)
                    buttonc.grid(row=1, column=2)
                    Label(sw, text="Will Pay: " + str(payoutc)).grid(row=2, column=2)

        button5 = Button(firehire1, text="Find Sponsors", width=20, height=2, command=sponsor)
        button5.grid(row=6, column=0, columnspan=1)
        if selectedCar.sponsor:
            print("herry", selectedCar.sponsor)
            if selectedCar.sponsor == "Unsponsored":
                button5["state"] = ACTIVE
            else:
                button5["state"] = DISABLED
        else:
            button5["state"] = ACTIVE
        print("jet fuel")
    def edit():
        global PlayerUno
        global selectedCar
        temp = []
        for i in PlayerUno.organization.orgteams:
            temp.append(str(i.num1))
        print("temp")
        myteamWindowedit = Tk()
        myteamWindowedit.geometry("500x230")
        Label(myteamWindowedit, text="Team Funds (In Thousands): " + str(PlayerUno.organization.money)).grid(row=0,
                                                                                                              column=0,
                                                                                                              columnspan=2)
        Label(myteamWindowedit, text="Select a Team: ").grid(row=1, column=0)

        variable = StringVar(myteamWindowedit)
        variable.set(temp[0])
        w = OptionMenu(myteamWindowedit, variable, *temp)
        # e1.focus_set()
        # def ok():
        #   print("chose, variale.get", variable.get)

        w.grid(row=2, column=1)

        def ok():

            tem = variable.get()
            print("TEM", tem)

            for i in PlayerUno.organization.orgteams:
                if str(i.num1) == tem:
                    print("true")
                    global selectedCar
                    selectedCar = i
                    print("AC", selectedCar)
                    myteamWindowedit.destroy()
                    firehire()

        button = Button(myteamWindowedit, text="Submit", command=ok)
        button.grid(row=3, column=1)

    def myteamedit_offseason():
        global PlayerUno
        root.withdraw()
        myteamWindow = Tk()
        myteamWindow.geometry("500x230")
        myteamWindow.title("MyTeam Edit Information")
        Label(myteamWindow, text="Team Funds (In Thousands): " + str(PlayerUno.organization.money)).grid(row=1,
                                                                                                         column=0)
        button1 = Button(myteamWindow, text="Free Agent List", width=20, height=2, command=freeagentscouter)
        button1.grid(row=2, column=0, columnspan=1)
        button2 = Button(myteamWindow, text="Scout For Talent", width=20, height=2, command=newtalent)
        button2.grid(row=3, column=0, columnspan=1)
        button2 = Button(myteamWindow, text="Edit Team", width=20, height=2, command=edit)
        button2.grid(row=4, column=0, columnspan=1)

        button3 = Button(myteamWindow, text="Create New Team", width=20, height=2, command=new)
        button3.grid(row=5, column=0, columnspan=1)

        if len(PlayerUno.organization.orgteams) >= 4:
            button3["state"] = DISABLED

        def retirement2():
            #sillyLabel = Label(sillyWindow, text="Changes: ")
            #sillyLabel.grid(row=0, column=0)
            #sillylistbox = Listbox(sillyWindow, width=150)
            #sillylistbox.grid(row=1, column=0)
            gui_string = ""
            window3 = Tk()
            root.update()
            root.deiconify()

            Label(window3, text="Changes").grid(row=0, column=0)
            sillylistbox = Listbox(window3, width=100)
            sillylistbox.grid(row=1,column=0)
            myteamWindow.destroy()

            for team in ded:
                sillylistbox.insert(END, team.team1 + " - #" + str(
                    team.num1) + " has shut down!")

                power_ranking[Team(dvr=team.dvr)] = team.dvr.rating
                team.active = False
                if str(team.num1) in mylist:
                    mylist.remove(str(team.num1))
                if str(team.num1) in mylist_real:
                    mylist_real.remove(str(team.num1))
                if str(team.num1) not in mylist_inactive:
                    mylist_inactive.add(str(team.num1))

            global mylist1
            if year >= 2020:
                chance = random.choice(odds)
                if chance >= 60:
                    if Driver44.active == False and Driver43.rating > 70:
                        Driver44.active = True
                        Driver44.sponsor = "WWT"
                        open.append(Driver24)
                        add("44")
                        sillylistbox.insert(END,
                                            "#" + str(
                                                Driver44.num1) + " " + Driver44.team1 + " will be joining the " + str(
                                                year) + " Cup Series!")
                if chance >= 20 and chance < 70:
                    if Driver54.active == False:
                        Driver54.active = True
                        print("54")
                        add("54")
                        # Driver46.dvr = Driver(name = "N/A")
                        open.append(Driver54)
                        Driver54.active = True
                        sillylistbox.insert(END,
                                            "#" + str(
                                                Driver54.num1) + " " + Driver54.team1 + " will be joining the " + str(
                                                year) + " Cup Series!")

                if chance >= 40 and chance < 80:
                    if Driver99.active == False:
                        if chance > 70:
                            Driver99.manu = "Ford"
                            Driver99.sponsor = "Northern Tools"
                            Driver99.team1 = "Roush Racing"
                        Driver99.active = True
                        print("99")
                        add("99")
                        # Driver46.dvr = Driver(name = "N/A")
                        open.append(Driver99)
                        Driver99.active = True
                        sillylistbox.insert(END,
                                            "#" + str(
                                                Driver99.num1) + " " + Driver99.team1 + " will be joining the " + str(
                                                year) + " Cup Series!")

            global team_names
            if year >= 2023:
                if chance > 40:
                    print("09 is coming")
                    if Driver09.active == False:
                        Driver09.active = True
                        Driver09.sponsor = sponsorlist.pop(random.randrange(len(sponsorlist)))
                        x1 = team_names.pop(random.randrange(len(team_names)))
                        print("HELP", x1)
                        Driver09.team1 = x1
                        mylist.add("09")
                        add("09")
                        # Driver46.dvr = Driver(name = "N/A")
                        open.append(Driver09)
                        sillylistbox.insert(END,
                                            "#" + str(
                                                Driver09.num1) + " " + Driver09.team1 + " will be joining the " + str(
                                                year) + " Cup Series!")
                if chance > 70:
                    if Driver7.active == False:
                        Driver7.active = True
                        Driver7.sponsor = sponsorlist.pop(random.randrange(len(sponsorlist)))
                        x1 = team_names.pop(random.randrange(len(team_names)))
                        print("HELP", x1)
                        Driver7.team1 = x1
                        add("7")
                        # Driver46.dvr = Driver(name = "N/A")
                        open.append(Driver7)
                        sillylistbox.insert(END,
                                            "#" + str(
                                                Driver7.num1) + " " + Driver7.team1 + " will be joining the " + str(
                                                year) + " Cup Series!")
                if chance > 30:
                    print("98 is coming")
                    if Driver98.active == False:
                        Driver98.active = True
                        if chance > 90:
                            Driver98.sponsor = sponsor_event()
                            Driver98.team1 = team_names.pop(random.randrange(len(team_names)))
                        print("asperchu4646")
                        mylist.add("98")
                        add("98")
                        # Driver46.dvr = Driver(name = "N/A")
                        open.append(Driver98)
                        sillylistbox.insert(END,
                                            "#" + str(
                                                Driver98.num1) + " " + Driver98.team1 + " will be joining the " + str(
                                                year) + " Cup Series!")
                if chance < 20:
                    print("46 is coming")
                    if Driver46.active == False:
                        Driver46.active = True
                        print("asperchu4646")
                        mylist.add("46")
                        add("46")
                        # Driver46.dvr = Driver(name = "N/A")
                        open.append(Driver46)
                        sillylistbox.insert(END,
                                            "#" + str(
                                                Driver46.num1) + " " + Driver46.team1 + " will be joining the " + str(
                                                year) + " Cup Series!")

                    if Driver24.active == False:
                        Driver24.active = True
                        Driver24.manu = "Chevy"
                        Driver24.team1 = "Jeff Gordon Inc"
                        Driver24.sponsor = "Alaxta"
                        Driver24.prestige = 84
                        print("yes")
                        Driver24.dvr = Temp2
                        open.append(Driver24)
                        add("24")
                        sillylistbox.insert(END,
                                            "#" + str(
                                                Driver24.num1) + " " + Driver24.team1 + " will be joining the " + str(
                                                year) + " Cup Series!")

                if chance >= 94:
                    if Driver91.active == False:
                        Driver91.active = True
                        Driver91.sponsor = sponsorlist.pop(random.randrange(len(sponsorlist)))
                        print("asperchu")
                        add("91")
                        # Driver46.dvr = Driver(name = "N/A")
                        open.append(Driver91)
                        Driver91.active = True
                        sillylistbox.insert(END,
                                            "#" + str(
                                                Driver91.num1) + " " + Driver91.team1 + " will be joining the " + str(
                                                year) + " Cup Series!")
                '''
                for x in mylist_inactive:
                    if x == "83":
                        car = assign_inauctive(x)
                        open.append(car)
                        sillylistbox.insert(END, "#" + str(car.num1) + " " + car.team1 + " will be joining the " + str(year) + " Cup Series!")
                        car.active = True
                        index = mylist.index("88")
                        mylist.insert(index, "83")
                    if x == "84":
                        car = assign_inactive(x)
                        open.append(car)
                        sillylistbox.insert(END, "#" + str(car.num1) + " " + car.team1 + " will be joining the " + str(year) + " Cup Series!")
                        car.active = True
                        index = mylist.index("88")
                        mylist.insert(index, "84")
                '''

            prestige_ranking = {}
            for ride in open:
                prestige_ranking[ride] = ride.prestige
            prestige_ranking_sorted = sorted(prestige_ranking, key=prestige_ranking.get, reverse=True)
            for x in prestige_ranking_sorted:
                print("prestigeranking", str(x.num1), " ", str(x.prestige))

            for team in candidates:
                if team.dvr.name not in retirements:
                    if team.dvr.name != "N/A":
                        power_ranking[team] = team.dvr.rating
            power_ranking_sorted = sorted(power_ranking, key=power_ranking.get, reverse=True)
            for x in power_ranking_sorted:
                print("powerranking", x.dvr.name, " ", str(x.dvr.rating))

            for x in retirements:
                print("RETIRING", x)

            FreeAgentX = Team(dvr=Temp)

            for new_team in prestige_ranking_sorted:
                '''
                rosterlist1 = []
                teamlist1 = []
                for x in mylist:
                    team = assign(x)
                    rosterlist1.append(team.dvr.name)
                    teamlist1.append(team)
                for drivr in rosterlist1:
                    if rosterlist1.count(drivr) < 2:
                '''

                flag = False
                if len(power_ranking_sorted) > 0:
                    print("CAR:", new_team.num1)
                    print(new_team.team1, "SUCK IT")
                    for replacement in power_ranking_sorted:
                        if replacement.dvr.name != "N/A":
                            print("replacement candidate: ", replacement.dvr.name)
                            if new_team.dvr != replacement.dvr and new_team not in replacement.dvr.oldrides:
                                # print("driver drive moveyar ", replacement.dvr.name, " ", str(replacement.dvr.moveyear + 2) )
                                if replacement.dvr.moveyear + 2 < year or replacement.dvr.moveyear == 0:
                                    if good_fit(replacement.dvr, team):
                                        flag = True
                                        # print("true again")
                                        print("MOVER IS C ", replacement.dvr.name)
                                        oldteam = new_team
                                        #old = new_team.dvr
                                        replacement.dvr.oldrides.append(oldteam)
                                        new_team.dvr = replacement.dvr
                                        replacement.dvr.moved = True
                                        replacement.dvr.moveyear = year
                                        replacement.dvr.morale += 60
                                        '''
                                        print("OLD DRIVER IS:", old.name)
                                        if old.name not in retirements:
                                            print("THIS DRIVER IS NOT RETIRING:", old.name)
                                            print(old.name)
                                            power_ranking_sorted.append(Team(dvr=old))
                                            for driver in freeagentlist:
                                                if driver.dvr.age > 40:
                                                    driver.dvr = old
                                                    break
                                        '''
                                        print("SILLYLISTBOX", year)
                                        print("new_team.team1", new_team.team1)
                                        print("str(new_team.num1)", str(
                                            new_team.num1))
                                        #print("old.name", old.name)
                                        print("new_team.dvr.name", new_team.dvr.name)
                                        gui_string += new_team.team1 + " #" + str(
                                            new_team.num1) + " - " + " has a new driver: " + new_team.dvr.name + '|'

                                        # sillylistbox.insert(END, new_team.team1 + " #" + str(
                                        #    new_team.num1) + " - " + old.name + " replaced by " + new_team.dvr.name)

                                        break
                    if flag == False:
                        while len(power_ranking_sorted) > 0:
                            replacement = power_ranking_sorted.pop(random.randrange(len(power_ranking_sorted)))
                            print("replacement candidate b: ", replacement.dvr.name)
                            if new_team.dvr != replacement.dvr and replacement.dvr.moved == False and replacement.dvr.name != "N/A":
                                if replacement.dvr.moveyear + 2 < year or replacement.dvr.moveyear == 0:
                                    print("true againDDDDDD")
                                    print("MOVER IS D ", replacement.dvr.name)
                                    replacement.dvr.moved = True
                                    replacement.dvr.moveyear = year
                                    replacement.dvr.morale += 60
                                    oldteam = new_team
                                    #old = new_team.dvr
                                    replacement.dvr.oldrides.append(oldteam)
                                    new_team.dvr = replacement.dvr
                                    if replacement.dvr in freelist:
                                        freelist.remove(replacement.dvr)
                                    for i in freeagentlist:
                                        if i.dvr.name == replacement.dvr.name:
                                            freeagentlist.remove(i)
                                    '''
                                    print("OLD DRIVERDDD IS:", old.name)
                                    if old.name not in retirements:
                                        print("THIS DRIVER IS NOT RETIRING:", old.name)
                                        FreeAgentX.dvr = old
                                        FreeAgentX.dvr.oldrides.append(new_team)
                                        power_ranking_sorted.append(FreeAgentX)
                                    '''
                                    # print("e", power_ranking_sorted[0].dvr.name)

                                    # print("SILLYLISTBOX1", year)
                                    gui_string += new_team.team1 + " #" + str(
                                        new_team.num1) + " - " + " has a new driver: " + new_team.dvr.name + '|'

                                    # sillylistbox.insert(END, new_team.team1 + " #" + str(
                                    #    new_team.num1) + " - " + old.name + " replaced by " + new_team.dvr.name)

                                    break

            for d in candidates:
                flag2 = True
                print(d.dvr.name, "fa")

                for f in freeagentlist:
                    # print("f dvr name", f.dvr.name)
                    if d.dvr.name == f.dvr.name or d.dvr.name == "N/A":
                        # freeagentlist.remove(f)
                        flag2 = False
                if flag2 == True:
                    # print("approved", d.dvr.name)
                    freeagentlist.append(Team(dvr=d.dvr))
                    freelist.append(d.dvr)
                    flag2 = False

            validlist = []
            rosterlist2 = []
            for x in mylist:
                team = assign(x)
                for f in freeagentlist:

                    if team:
                        if team.dvr == f.dvr:
                            freeagentlist.remove(f)
                            if f.dvr in freelist:
                                freelist.remove(f.dvr)
                if team:
                    validlist.append(team)
                    rosterlist2.append(team.dvr.name)
            '''
            for dvivr in rosterlist2:
                i = 0
                stupidlist = []
                counter = 0
                print("DVVIIVIV", dvivr)
                if rosterlist2.count(dvivr) > 1:
                    print("break in case of emergency ", dvivr, )
                    for team in validlist:

                        if team.dvr.name == dvivr and team.active == True:
                            i += 1

                            print("Team", team.num1)
                            if i > 1:
                                print("god dammit")
                                team.active = False
                                gui_string += team.team1 + " #" + str(team.num1) + " has shut down!" + '|'
                                mylist_inactive.append(str(team.num1))
                                if str(team.num1) in mylist:
                                    mylist.remove(str(team.num1))


            '''
            for team in rosterlist2:
                print(team, "another test")
                if team == "N/A":
                    team = namegenerator()
            for dvr in mylist:
                car = assign(mylist)
                if car and car.dvr.name == "N/A":
                    naem = namegenerator()
                    car.dvr = Driver(name=naem, age=22, rating=50)

            '''
                    if len(freeagentlist) > 0:
                        print("break in case of emergency")
                        for i in range(len(freeagentlist)):
                            mover = freeagentlist.pop(random.randrange(len(freeagentlist)))
                            if mover.dvr.age > 21:
                                for team in validlist:
                                    if team.dvr.name == dvivr:
                                        team.dvr = mover.dvr
                                        gui_string += team.team1 + " #" + str(
                                        new_team.num1) + " - " + dvivr + " replaced by " + team.dvr.name + '|'
                                        break
                            else:
                                freeagentlist.append(mover)

                        break
            '''
            # for d in retirements:

            for i in range(len(new_retirements)):
                if new_retirements[i][0] not in rosterlist2:

                    sillylistbox.insert(END, new_retirements[i][0] + " has retired!")
                    sillylistbox.insert(END, new_retirements[i][0] + " final stats: " + new_retirements[i][1] +
                                        " titles, " + new_retirements[i][2] + " wins, " +
                                        new_retirements[i][3] + " top fives, " + new_retirements[i][4] + " top tens, "
                                        + new_retirements[i][5] + " total races")
                    for f in freeagentlist:
                        if f.dvr.name == new_retirements[i][0]:
                            freeagentlist.remove(f)

            for move in gui_string.split('|'):
                sillylistbox.insert(END, move)

            for f in new_retirements:
                retired.append(f)

            print("omg", retired)
            for f in freeagentlist:
                print(f.dvr.name, "!")

            rosterlist = []


        button = Button(myteamWindow, text="Jump To Next Season", command=retirement2)
        button.grid(row=1, column=2)
        '''
        z = 0
        z = 0
        for i in PlayerUno.organization.orgteams:

            Button(myteamWindow, text="Car #"+str(i.num1), width=20, height=2, command=newtalent).grid(row=z, column=1, columnspan=1)
            z+=1
        '''

    myteamedit_offseason()



def sillySeasonExport():
    global mylist
    global yearstring
    print("sillyseasonexport")
    if Path("standings" + str(year-1) + ".txt").is_file():
        file = open("standings" + str(year-1) + ".txt", "r+")
        file.truncate(0)
        file.close()

    f = open("standings" + str(year-1) + ".txt", "a+")
    #stg=standing(mylist)
    for i in yearstring.splitlines():
        f.write(i + "\n")

def sillySeason():
    print("test")
    #sillyWindow = tk.Toplevel(root)
    #sillyWindow.geometry("800x250")
    # driverlist = [KennyWallace, JoeNemechek, DaveBlaney, ShaneHmiel, JohnnySauter, MartinTruex,
    #              RustyWallace, MikeWallace, KyleBusch, MarkMartin, RobbyGordon, DaleEarnhardtJr, KaseyKahne,
    #              ReedSorenson, BillElliott]

    myButton = Button(root, text="Run Race", width=20, height=2, command=myClick)
    myButton.grid(row=5, column=0, columnspan=1)
    #sillyLabel = Label(sillyWindow, text="Changes: ")
    #sillyLabel.grid(row=0, column=0)
    #sillylistbox = Listbox(sillyWindow, width=150)
    #sillylistbox.grid(row=1, column=0)
    retirement()
    #retirement(sillylistbox, sillyWindow)

def event_year():
    global year
    global president
    global president_yr
    president_yr += 1
    eventWindow = tk.Toplevel(root)
    eventWindow.geometry("680x220")
    eventlabel = Label(eventWindow, text=str(year-1) + " in review")
    superbowl = superbowl_event()
    wrestle = wrestling_event()
    nba = nba_event()

    eventlabel.grid(row=0, column=0)
    racescrollbar = Scrollbar(eventWindow)
    racescrollbar.grid(row=1, column=0, columnspan=1)

    racelistbox = Listbox(eventWindow, width=120)
    racelistbox.grid(row=1, column=0)
    racelistbox.insert(END, superbowl)
    racelistbox.insert(END, nba)
    racelistbox.insert(END, wrestle)
    if year % 4 == 0:
        president = president_event()
        racelistbox.insert(END, president)
    myButton = Button(root, text="Silly Season", width=20, height=2, command=sillySeason)
    myButton.grid(row=5, column=0, columnspan=1)


def champion(year):
    global yearstring
    yearstring = ""
    global mylist
    standings = {}
    for i in mylist:
        car = assign(i)
        if car:
            standings[i] = car.dvr.pts

    standings_sorted = sorted(standings, key=standings.get, reverse=True)
    print(standings_sorted)
    global champions
    global toptwenty
    for i in range(0, 21):
        toptwenty.append(standings_sorted[i])
    champ = assign(standings_sorted[0])
    if champ:
        champ.dvr.t += 1
        temp = "#" + str(champ.num1) + " " + str(champ.dvr.name) + " - " + str(champ.team1)
        champions[year] = temp

    finalWindow = tk.Toplevel(root)
    finalWindow.geometry("580x220")
    finallabel = Label(finalWindow, text="Your " + str(year) + " Champion : #" + str(champ.num1) + " " + champ.dvr.name)
    finallabel.grid(row=0, column=0)
    racescrollbar = Scrollbar(finalWindow)
    racescrollbar.grid(row=1, column=0,columnspan=2)

    racelistbox = Listbox(finalWindow, width=120)
    racelistbox.grid(row=1, column=0)
    stg = standing(mylist)
    yearstring = standing(mylist)
    myButton = Button(finalWindow, text="Export Standings", width=20, height=2, command=sillySeasonExport)
    myButton.grid(row=5, column=0, columnspan=1)


    for i in stg.splitlines():
        racelistbox.insert(END, i)
        #yearstring += "#" + str(champ.num1) + " " + str(champ.dvr.name) + " - " + str(champ.team1) + "\n"

    for x in mylist:
        print("drake", x)
        driver = assign(x)
        if driver:
            driver.dvr.age += 1
            driver.yrsleft -= 1
            print("YEARS", driver.dvr.name, str(driver.yrsleft))


    for s in range(len(standings_sorted)):
        driver = assign(standings_sorted[s]).dvr
        if driver:
            driver.wins = 0
            driver.topfives = 0
            driver.toptens = 0
            driver.avgfinish = 0
            driver.races = 0
            driver.pts = 0
            driver.finishes = []
            if driver.moved == True:
                print("f")
            driver.moved = False
            if driver.age > 20 and driver.age <= 26:
                driver.rating += 3
            if driver.age > 27 and driver.age <= 32:
                driver.rating += 2
            if driver.age > 40 and driver.age <= 45:
                driver.rating -= 4
            if driver.age > 45:
                driver.rating -= 6

            if driver.rating > 100:
                driver.rating = 100
            if driver.morale > 100:
                driver.morale = 100

            if driver.rating < 0:
                driver.rating = 0
            if driver.morale < 0:
                driver.morale = 0

    for fa in freeagentlist:
        fa.dvr.age += 1
        print("fa is", fa.dvr.name, fa.dvr.age)
        for i in standings_sorted[s]:
            i1 = assign(i)
            if fa:
                if i1:
                    if fa.dvr == i1.dvr:
                        freeagentlist.remove(fa)
            else:
                freeagentlist.remove(fa)
        if fa.dvr.age < 26:
            fa.dvr.rating += 4
        if fa.dvr.rating > 100:
            fa.dvr.rating = 90

    myButton = Button(root, text="The Year in Review", width=20, height=2, command=event_year)
    myButton.grid(row=5, column=0, columnspan=1)




def gui_champ():
    global champions
    champWindow = tk.Toplevel(root)
    champWindow.geometry("400x170")
    champWindow.title("Hall of Champions")
    racelistbox = Listbox(champWindow, width=450)
    racelistbox.grid(row=0, column=0)
    racescrollbar = Scrollbar(champWindow)
    racescrollbar.grid(row=1, column=0)

    for k in champions:
        racelistbox.insert(END, str(k) + " | " + champions[k])


def gui_500():
    global daytona


    daytonaWindow = tk.Toplevel(root)
    daytonaWindow.geometry("400x170")
    daytonaWindow.title("Daytona 500 Winners")

    #dw = Label(daytonaWindow, text="Daytona 500 Winners")
    #dw.grid(row=0, column=0, column)
    racelistbox = Listbox(daytonaWindow, width=450)
    racelistbox.grid(row=0, column=0)
    racescrollbar = Scrollbar(daytonaWindow)
    racescrollbar.grid(row=1, column=0)

    for k in daytona:
        racelistbox.insert(END, str(k) + " | " + daytona[k])


def time_add():
    global week
    week += 1
    global year
    global schedule
    if year == 2005:
        if week >= 37:
            print("EJ")
            myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
            myButton2.grid(row=5, column=1, columnspan=1)
            myButton2["state"] = DISABLED
            champion(year)
            week = 1
            year += 1

        else:
            if week != 2:
                myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
                myButton2.grid(row=5, column=1, columnspan=1)
                myButton2["state"] = NORMAL
    if year != 2005:
        if week >= 37:
            print("EJ HERE")
            myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
            myButton2.grid(row=5, column=1, columnspan=1)
            myButton2["state"] = DISABLED
            champion(year)
            week = 1
            year += 1


        else:
            if week != 1:
                myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
                myButton2.grid(row=5, column=1, columnspan=1)
                myButton2["state"] = NORMAL


def update(myButton2=None):
    # raceWindow = tk.Toplevel(root)
    # raceWindow.geometry("300x100")
    global week
    global year
    #cuplabel = Label(root, text=cup)
    if year == 2005:
        weeklabel = Label(root, text="Week:" + str(week - 1))
    else:
        weeklabel = Label(root, text="Week:" + str(week))
    yearlabel = Label(root, text="Year:" + str(year))
    weeklabel.grid(row=0, column=0)
    yearlabel.grid(row=0, column=1, columnspan =3)


def myClick2(myButton2=None):
    # running race
    global year
    for i in range(0, 10):
        if year == 2005:
            if week >= 36:
                break
        if year != 2005:
            if week == 36:
                break
        gui_race1()
        update()
        time_add()


def myClick(myButton2=None):
    # running race
    raceWindow = tk.Toplevel(root)
    raceWindow.geometry("700x400")
    myLabel4 = Label(raceWindow, text="Race Results")
    myLabel4.grid(row=0, column=0)
    racescrollbar = Scrollbar(raceWindow)
    racescrollbar.grid(row=1, column=1)
    racelistbox = Listbox(raceWindow, width=120)
    racelistbox.grid(row=1, column=0)
    myLabel4 = Label(raceWindow, text="Race Notes")
    myLabel4.grid(row=2, column=0)
    racelistbox2 = Listbox(raceWindow, width=120)
    racelistbox2.grid(row=3, column=0)
    gui_race1(racelistbox, racelistbox2)
    update(myButton2)
    time_add()


def click(event):
    global mylist
    global mylist1
    widget = event.widget
    selection = widget.curselection()
    value = widget.get(selection[0])
    driverWindow = tk.Toplevel(root)
    driverWindow.geometry("200x150")
    driverWindow.title("Driver Window")
    car = assign(mylist1[(selection[0])])
    if car:
        myLabel4 = Label(driverWindow, text="Driver Statistics: " + car.dvr.name)
        myLabel4.grid(row=2, column=7, columnspan = 2)
        myLabel5 = Label(driverWindow, text="Career Wins: " + str(car.dvr.totalwins))
        myLabel5.grid(row=5, column=7,  columnspan = 1)
        myLabel6 = Label(driverWindow, text="Career Top Fives: " + str(car.dvr.totaltopfives))
        myLabel6.grid(row=6, column=7,  columnspan = 1)
        myLabel7 = Label(driverWindow, text="Career Top Tens: " + str(car.dvr.totaltoptens))
        myLabel7.grid(row=7, column=7,  columnspan = 1)
        myLabel7 = Label(driverWindow, text="Championships: " + str(car.dvr.t))
        myLabel7.grid(row=8, column=7,  columnspan = 1)

def retireInfo():
    # listbox.get(listbox.curselection())
    driverWindow = tk.Toplevel(root)
    driverWindow.geometry("500x300")
    myLabel4 = Label(driverWindow, text="Retired Driver Statistics:")
    myLabel4.grid(row=0, column=0)
    scrollbar = Scrollbar(driverWindow)
    scrollbar.grid(row=0, column=1)

    listbox = Listbox(driverWindow, width=90)
    listbox.grid(row=1, column=0)
    print(retired)
    for i in retired:
        listbox.insert(END, "Driver: " + i[0] + " | Titles: " + str(i[1]) + " | Wins: " + str(i[2]) + " | Top Fives: " + str(i[3]) + " | Top Tens: " + str(i[4]) + " | Races: " + str(i[5]))
        # listbox.insert(END, "#" + str(i) + " - " + car.dvr.name)

        # standings[i] = car.dvr.pts

    listbox.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=listbox.yview)
    #listbox.bind("<Double-Button-1>", click)
    # listbox.grid(row=4,column=1)

def driverInfo():
    # listbox.get(listbox.curselection())
    driverWindow = tk.Toplevel(root)
    driverWindow.geometry("900x300")
    myLabel4 = Label(driverWindow, text="Driver Statistics:")
    myLabel4.grid(row=0, column=0)
    scrollbar = Scrollbar(driverWindow)
    scrollbar.grid(row=3, column=0)

    listbox = Listbox(driverWindow, width=120)
    listbox.grid(row=5, column=1)
    add = []
    for i in mylist:
        car = assign(i)
        if car and str(car.num1) >= str(1):
            add.append(car.num1)
            print("ADDED", add)
    add.sort()
    global mylist1
    mylist1 = []
    mylist1  = list()
    for i in add:
        if i not in mylist1:
            mylist1.append(str(i))
            print("ADDEDjr", i)
    print(mylist1)
    if "0" in mylist_real and assign("0"):
        mylist1.insert(0, "0")
    if "09" in mylist_real and assign("09"):
        mylist1.insert(0, "09")
    if "08" in mylist_real and assign("08"):
        mylist1.insert(0, "08")
    if "07" in mylist_real and assign("07"):
        mylist1.insert(0, "07")
    if "02" in mylist_real and assign("02"):
        mylist1.insert(0, "02")
    if "01" in mylist_real and assign("01"):
        mylist1.insert(0, "01")
    if "00" in mylist_real and assign("00"):
        mylist1.insert(0, "00")
    for i in mylist1:
        car = assign(i)
        if car:
            listbox.insert(END, car.displayMedium1())
        # listbox.insert(END, "#" + str(i) + " - " + car.dvr.name)

        # standings[i] = car.dvr.pts

    listbox.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=listbox.yview)
    listbox.bind("<Double-Button-1>", click)
    # listbox.grid(row=4,column=1)


def init2020():
    global mylist
    #game_gui.destroy()
    # self.parent.maxsize(750, 550)
    #root = tk.Tk()
    global wrestlemania
    wrestlemania =36
    root.minsize(300, 120)
    root.title("AutoSim BETA")
    global champions
    global daytona
    champions[2015] = "#18 Kyle Busch - Joe Gibbs Racing"
    champions[2016] = "#48 Jimmie Johnson - Hendrick Motorsports"
    champions[2017] = "#78 Martin Truex Jr - Furniture Row Racing"
    champions[2018] = "#22 Joey Logano - Team Penske"
    champions[2019] = "#18 Kyle Busch - Joe Gibbs Racing"
    daytona[2015] = "#22 Joey Logano - Team Penske"
    daytona[2016] = "#11 Denny Hamlin - Joe Gibbs Racing"
    daytona[2017] = "#41 Kurt Busch - Stewart-Haas Racing"
    daytona[2018] = "#3 Austin Dillon - Richard Childress Racing"
    daytona[2019] = "#11 Denny Hamlin - Joe Gibbs Racing"

    # myButton1 = Button(root, text = "Time", command = update)
    # myButton1.grid(row=0, column=0)

    global week
    global year
    global cup
    global start_year
    week=1
    year = 2020
    start_year = 2020
    cup = "Nascar Cup Series"
    if year == 2005:
        weeklabel = Label(root, text="Week:" + str(week-1))
        weeklabel = Label(root, text="Week:" + str(week-1))
    else:
        weeklabel = Label(root, text="Week:" + str(week))
    yearlabel = Label(root, text="Year:" + str(year))
    cuplabel = Label(root, text=cup)
    weeklabel.grid(row=0, column=0)
    yearlabel.grid(row=0, column=1)
    cuplabel.grid(row=1, column=0, columnspan = 2)
    cuplabel.configure(anchor="center")

    myButton = Button(root, text="Run Race", width=20, height=2, command=myClick)
    myButton.grid(row=5, column=0, columnspan =1)

    myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
    myButton2.grid(row=5, column=1, columnspan =1)

    stg = Button(root, text="Standings", width=20, height=2, command=gui_standings)
    stg.grid(row=6, column=0 , columnspan =1)

    sceg = Button(root, text="Schedule", width=20, height=2, command=gui_schedule)
    sceg.grid(row=6, column=1, columnspan=1)
    #sceg["state"] = DISABLED

    dvrstats = Button(root, text="Driver Stats", width=20, height=2, command=driverInfo)
    dvrstats.grid(row=7, column=0 , columnspan =1)

    rtrstats = Button(root, text="Retired Driver Stats", width=20, height=2, command=retireInfo)
    rtrstats.grid(row=7, column=1, columnspan=1)

    dvrstats = Button(root, text="Hall of Champions", width=20, height=2, command=gui_champ)
    dvrstats.grid(row=8, column=0 , columnspan =1)

    dvrstats = Button(root, text="Daytona 500 Winners", width=20, height=2, command=gui_500)
    dvrstats.grid(row=8, column=1 , columnspan =1)

    dvrstats = Button(root, text="Load", width=20, height=2, command=load_game2020)
    dvrstats.grid(row=9, column=0, columnspan=1)

    dvrstats = Button(root, text="Save", width=20, height=2, command=save_game)
    dvrstats.grid(row=9, column=1, columnspan=1)

class Passwordchecker(tk.Frame):
    def __init__(self, parent):
        tk.Frame.__init__(self, parent)
        self.parent = parent
        self.initialize_user_interface()
        # year = 2005
        # week = 1

    def OnDouble(self, event):
        global mylist
        widget = event.widget
        selection = widget.curselection()
        value = widget.get(selection[0])
        driverWindow = tk.Toplevel(root)
        driverWindow.geometry("400x300")
        driverWindow.title("Driver Window")
        car = assign(mylist[(selection[0])])
        myLabel4 = Label(driverWindow, text="Driver Statistics: " + str(car.dvr.name))
        myLabel4.grid(row=4, column=0)
        myLabel5 = Label(driverWindow, text="Wins: " + str(car.dvr.wins))
        myLabel5.grid(row=5, column=0)
        myLabel6 = Label(driverWindow, text="Top Fives: " + str(car.dvr.topfives))
        myLabel6.grid(row=6, column=0)
        myLabel7 = Label(driverWindow, text="Top Tens: " + str(car.dvr.toptens))
        myLabel7.grid(row=7, column=0)
        myLabel7 = Label(driverWindow, text="Championships: " + str(car.dvr.titles))
        myLabel7.grid(row=8, column=0)

    def initialize_user_interface(self):
        global mylist

        # self.parent.maxsize(750, 550)
        self.parent.minsize(300, 120)
        self.parent.title("AutoSim BETA")

        # myButton1 = Button(root, text = "Time", command = update)
        # myButton1.grid(row=0, column=0)

        global week
        global year
        global cup
        if year == 2005:
            weeklabel = Label(root, text="Week:" + str(week-1))
        else:
            weeklabel = Label(root, text="Week:" + str(week))
        yearlabel = Label(root, text="Year:" + str(year))
        cuplabel = Label(root, text=cup)
        weeklabel.grid(row=0, column=0)
        yearlabel.grid(row=0, column=1)
        cuplabel.grid(row=1, column=0, columnspan = 2)
        cuplabel.configure(anchor="center")

        myButton = Button(root, text="Run Race", width=20, height=2, command=myClick)
        myButton.grid(row=5, column=0, columnspan =1)

        myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
        myButton2.grid(row=5, column=1, columnspan =1)

        stg = Button(root, text="Standings", width=20, height=2, command=gui_standings)
        stg.grid(row=6, column=0 , columnspan =1)

        sceg = Button(root, text="Schedule", width=20, height=2, command=gui_schedule)
        sceg.grid(row=6, column=1, columnspan=1)
        #sceg["state"] = DISABLED

        dvrstats = Button(root, text="Driver Stats", width=20, height=2, command=driverInfo)
        dvrstats.grid(row=7, column=0 , columnspan =1)

        rtrstats = Button(root, text="Retired Driver Stats", width=20, height=2, command=retireInfo)
        rtrstats.grid(row=7, column=1, columnspan=1)

        dvrstats = Button(root, text="Hall of Champions", width=20, height=2, command=gui_champ)
        dvrstats.grid(row=8, column=0 , columnspan =1)

        dvrstats = Button(root, text="Daytona 500 Winners", width=20, height=2, command=gui_500)
        dvrstats.grid(row=8, column=1 , columnspan =1)

        dvrstats = Button(root, text="Load", width=20, height=2, command=load_game2020)
        dvrstats.grid(row=9, column=0, columnspan=1)

        dvrstats = Button(root, text="Save", width=20, height=2, command=save_game)
        dvrstats.grid(row=9, column=1, columnspan=1)


if __name__ == '__main__':

    root = tk.Tk()
    run = Passwordchecker(root)
    root.mainloop()

