import tkinter as tk
from tkinter import *
from nascar_sim2020 import *
from owner_gui2020 import *
from pathlib import Path
from operator import itemgetter
from operator import attrgetter
import copy


global orglist
global orglist_names
global selected
global selectedCar
global amt
global driver0



def myClick2(myButton2=None):
    # running race
    global year
    for i in range(0, 10):
        if year == 2005:
            if week == 36:
                break
        if year != 2005:
            if week == 36:
                break
        gui_race1()
        update()
        time_add()


def myClick(myButton2=None):
    # running race
    raceWindow = tk.Toplevel(root)
    raceWindow.geometry("700x400")
    myLabel4 = Label(raceWindow, text="Race Results")
    myLabel4.grid(row=0, column=0)
    racescrollbar = Scrollbar(raceWindow)
    racescrollbar.grid(row=1, column=1)
    racelistbox = Listbox(raceWindow, width=120)
    racelistbox.grid(row=1, column=0)
    myLabel4 = Label(raceWindow, text="Race Notes")
    myLabel4.grid(row=2, column=0)
    racelistbox2 = Listbox(raceWindow, width=120)
    racelistbox2.grid(row=3, column=0)
    print("AHHHHH MY EYES")
    gui_race1(racelistbox, racelistbox2)
    update(myButton2)
    time_add()



def click(event):
    global mylist
    global mylist1
    widget = event.widget
    selection = widget.curselection()
    value = widget.get(selection[0])
    driverWindow = tk.Toplevel(root)
    driverWindow.geometry("200x150")
    driverWindow.title("Driver Window")
    car = assign(mylist1[(selection[0])])
    if car:
        myLabel4 = Label(driverWindow, text="Driver Statistics: " + car.dvr.name)
        myLabel4.grid(row=2, column=7, columnspan = 2)
        myLabel5 = Label(driverWindow, text="Career Wins: " + str(car.dvr.totalwins))
        myLabel5.grid(row=5, column=7,  columnspan = 1)
        myLabel6 = Label(driverWindow, text="Career Top Fives: " + str(car.dvr.totaltopfives))
        myLabel6.grid(row=6, column=7,  columnspan = 1)
        myLabel7 = Label(driverWindow, text="Career Top Tens: " + str(car.dvr.totaltoptens))
        myLabel7.grid(row=7, column=7,  columnspan = 1)
        myLabel7 = Label(driverWindow, text="Championships: " + str(car.dvr.t))
        myLabel7.grid(row=8, column=7,  columnspan = 1)

def talk():
    global week
    global selected
    driverWindow2 = tk.Toplevel(root)
    #driverWindow2.geometry("200x150")
    driverWindow2.title("Driver Window")
    def done():
        driverWindow2.destroy()
    if selected.dvr.rating > 87:
        if selected.dvr.wins > 1:
            myLabel4 = Label(driverWindow2,
                             text=selected.dvr.name + """ " Wow, multiple wins! Thanks for providing me with such great equipment! " """)
        if selected.dvr.wins == 1:
            myLabel4 = Label(driverWindow2, text=selected.dvr.name + """ " I'm really glad we got a win this season! " """)
        if selected.dvr.wins == 0:
            myLabel4 = Label(driverWindow2, text=selected.dvr.name + """ " What's Up? " """)

    else:
        if selected.dvr.wins == 0 and week > 20:
            myLabel4 = Label(driverWindow2, text=selected.dvr.name + """ "This equipment is getting hard to work with. I'm really hoping to get a good finish soon" """)
        else:
            if selected.dvr.rating < 80 and selected.dvr.toptens > 1:
                myLabel4 = Label(driverWindow2, text=selected.dvr.name + """ " We've been getting good finishes lately. I think our luck is about to change. """)
            else:
                myLabel4 = Label(driverWindow2, text=selected.dvr.name + """ "'Sup, boss?" """)
    myLabel4.grid(row=0, column=0, columnspan=2)
    myButton1 = Button(driverWindow2, text="Ok", command=done)
    myButton1.grid(row=1)

def myteamclick(event):
    global mylist
    global mylist1
    widget = event.widget
    selection = widget.curselection()
    value = widget.get(selection[0])
    driverWindow = tk.Toplevel(root)
    driverWindow.geometry("220x170")
    driverWindow.title("Driver Window")
    global PlayerUno
    global selected
    car = PlayerUno.organization.orgteams[selection[0]]
    print("CAR IS", str(car))
    selected = car
    if car:
        myLabel4 = Label(driverWindow, text="Driver Statistics: " + car.dvr.name)
        myLabel4.grid(row=0, column=0, columnspan = 2)
        myLabel5 = Label(driverWindow, text="Career Wins: " + str(car.dvr.totalwins))
        myLabel5.grid(row=1, column=0,  columnspan = 1)
        myLabel6 = Label(driverWindow, text="Career Top Fives: " + str(car.dvr.totaltopfives))
        myLabel6.grid(row=2, column=0,  columnspan = 1)
        myLabel7 = Label(driverWindow, text="Career Top Tens: " + str(car.dvr.totaltoptens))
        myLabel7.grid(row=3, column=0,  columnspan = 1)
        myLabel7 = Label(driverWindow, text="Championships: " + str(car.dvr.t))
        myLabel7.grid(row=4, column=0,  columnspan = 1)
        myLabel7 = Label(driverWindow, text="Morale: " + str(car.dvr.morale))
        myLabel7.grid(row=5, column=0, columnspan=1)
        myButton1 = Button(driverWindow, text = "Talk to " + str(car.dvr.name), command = talk)
        myButton1.grid(row=6)


def teamsort():
    global PlayerUno
    #for i in PlayerUno.organization.orgteams:
    t = sorted(PlayerUno.organization.orgteams, key=lambda Driver: str(Driver.num1))
    PlayerUno.organization.orgteams = t

def myteam():
    global PlayerUno
    #myteamWindow =
    teamsort()
    myteamWindow = Tk()
    myteamWindow.geometry("500x230")
    myteamWindow.title("MyTeam Information")
    alabel = Label(myteamWindow, text=str(PlayerUno.organization.orgname) + " Information")
    alabel.grid(row=0, column=0)
    alabel2 = Label(myteamWindow, text=str("Yearly Funding: " + str(PlayerUno.organization.money)))
    alabel2.grid(row=1, column=0)
    racelistbox = Listbox(myteamWindow, width=90)
    racelistbox.grid(row=3, column=0)
    for i in PlayerUno.organization.orgteams:
        if i.dvr:
            racelistbox.insert(END, "#" + str(i.num1) + " " + str(i.dvr.name) + " (" + str(i.dvr.age) + " years old) - " + str(i.sponsor) + " | " + "Driver Rating: " + str(i.dvr.rating) + " | Car Prestige: " + str(i.prestige))
        else:
            racelistbox.insert(END, "#" + str(i.num1) + " None - " + str(i.sponsor))

    racelistbox.bind("<Double-Button-1>", myteamclick)

def retireInfo():
    # listbox.get(listbox.curselection())
    driverWindow = tk.Toplevel(root)
    driverWindow.geometry("500x300")
    myLabel4 = Label(driverWindow, text="Retired Driver Statistics:")
    myLabel4.grid(row=0, column=0)
    scrollbar = Scrollbar(driverWindow)
    scrollbar.grid(row=0, column=1)

    listbox = Listbox(driverWindow, width=90)
    listbox.grid(row=1, column=0)
    print(retired)
    for i in retired:
        listbox.insert(END, "Driver: " + i[0] + " | Titles: " + str(i[1]) + " | Wins: " + str(i[2]) + " | Top Fives: " + str(i[3]) + " | Top Tens: " + str(i[4]) + " | Races: " + str(i[5]))
        # listbox.insert(END, "#" + str(i) + " - " + car.dvr.name)

        # standings[i] = car.dvr.pts

    listbox.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=listbox.yview)
    #listbox.bind("<Double-Button-1>", click)
    # listbox.grid(row=4,column=1)

def driverInfo():
    # listbox.get(listbox.curselection())
    driverWindow = tk.Toplevel(root)
    driverWindow.geometry("900x300")
    myLabel4 = Label(driverWindow, text="Driver Statistics:")
    myLabel4.grid(row=0, column=0)
    scrollbar = Scrollbar(driverWindow)
    scrollbar.grid(row=3, column=0)

    listbox = Listbox(driverWindow, width=120)
    listbox.grid(row=5, column=1)
    add = []
    for i in mylist:
        car = assign(i)
        if car and str(car.num1) >= str(1):
            add.append(car.num1)
            print("ADDED", add)
    add.sort()
    global mylist1
    mylist1 = []
    mylist1  = list()
    for i in add:
        if i not in mylist1:
            mylist1.append(str(i))
            print("ADDEDjr", i)
    print(mylist1)
    if "0" in mylist_real and assign("0"):
        mylist1.insert(0, "0")
    if "09" in mylist_real and assign("09"):
        mylist1.insert(0, "09")
    if "08" in mylist_real and assign("08"):
        mylist1.insert(0, "08")
    if "07" in mylist_real and assign("07"):
        mylist1.insert(0, "07")
    if "02" in mylist_real and assign("02"):
        mylist1.insert(0, "02")
    if "01" in mylist_real and assign("01"):
        mylist1.insert(0, "01")
    if "00" in mylist_real and assign("00"):
        mylist1.insert(0, "00")
    for i in mylist1:
        car = assign(i)
        if car:
            listbox.insert(END, car.displayMedium1())
        # listbox.insert(END, "#" + str(i) + " - " + car.dvr.name)

        # standings[i] = car.dvr.pts

    listbox.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=listbox.yview)
    listbox.bind("<Double-Button-1>", click)
    # listbox.grid(row=4,column=1)


def freeagentscouter():
    global PlayerUno
    myteamWindow1 = Tk()
    myteamWindow1.geometry("500x230")
    myteamWindow1.title("MyTeam Edit Information")
    # button2 = Button(myteamWindow1, text="Free Agent Scouter", width=20, height=2, command=freeagentscouter)
    # button2.grid(row=5, column=0, columnspan=1

    racelistbox = Listbox(myteamWindow1, width=80)
    racelistbox.grid(row=1, column=0, columnspan=2)
    free = []
    for i in freeagentlist:
        free.append(i.dvr)
    print(free)
    free1= sorted(free, key=lambda Driver: Driver.rating, reverse=True)
    for i in free1:
        if i.age > 19:
            racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

    def sort_age():
        racelistbox.delete('0', 'end')
        free1 = sorted(free, key=lambda Driver: Driver.age, reverse=True)
        for i in free1:
            if i.age > 19:
                racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

    def sort_rating():
        racelistbox.delete('0', 'end')
        free1 = sorted(free, key=lambda Driver: Driver.rating, reverse=True)
        for i in free1:
            if i.age > 19:
                racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

    button1 = Button(myteamWindow1, text="Sort by Age", width=20, height=2, command=sort_age)
    button1.grid(row=3, column=0)

    button2 = Button(myteamWindow1, text="Sort by Rating", width=20, height=2, command=sort_rating)
    button2.grid(row=3, column=1)


def newtalent(): #NEWTALENT
    global PlayerUno
    myteamWindow1 = Tk()
    myteamWindow1.geometry("500x230")
    myteamWindow1.title("MyTeam Edit Information")
    # button2 = Button(myteamWindow1, text="Free Agent Scouter", width=20, height=2, command=freeagentscouter)
    # button2.grid(row=5, column=0, columnspan=1
    racelistbox = Listbox(myteamWindow1, width=80)
    racelistbox.grid(row=1, column=0, columnspan=2)
    free = []
    for i in freeagentlist:
        free.append(i.dvr)
    print(free)
    free1 = sorted(free, key=lambda Driver: Driver.rating, reverse=True)
    for i in free1:
        if i.age >= 16 and i.age <= 19:
            racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

    def sort_age():
        racelistbox.delete('0', 'end')
        free1 = sorted(free, key=lambda Driver: Driver.age, reverse=True)
        for i in free1:
            if i.age >= 16 and i.age < 19:
                racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

    def sort_rating():
        racelistbox.delete('0', 'end')
        free1 = sorted(free, key=lambda Driver: Driver.rating, reverse=True)
        for i in free1:
            if i.age >= 16 and i.age <= 19:
                racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

    button1 = Button(myteamWindow1, text="Sort by Age", width=20, height=2, command=sort_age)
    button1.grid(row=3, column=0)

    button2 = Button(myteamWindow1, text="Sort by Rating", width=20, height=2, command=sort_rating)
    button2.grid(row=3, column=1)



def new():
    global PlayerUno
    global selectedCar
    newW = Tk()
    newW.geometry("600x230")

    global numlist


    def newfulltime():
        PlayerUno.organization.money -= 200000
        button1.destroy()
        button2.destroy()
        newL.destroy()
        newL2.destroy()
        newL3 = Label(newW, text="Select Car #")
        newL3.grid(row=0, column=0)
        #nice = Entry(newW)
        #nice.grid(row=0, column=1)
        global variable12
        variable12 = StringVar(newW)
        variable12.set(numlist[0])
                # print("USER ENTRY", user_entry)
        w = OptionMenu(newW, variable12, *numlist)
        w.grid(row=1,column=0,columnspan=2)


        def ok():
            global PlayerUno
            global variable12
            tem = variable12.get()
            print("TEM", tem)
            if tem == "0":
                Driver0.active = True
                Driver0.dvr = None
                Driver0.manu = PlayerUno.organization.orgmanu
                Driver0.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver0)
                #mylist.add("59")
                numlist.remove("0")
            if tem == "01":
                Driver01.active = True
                Driver01.dvr = None
                Driver01.manu = PlayerUno.organization.orgmanu
                Driver01.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver01)
                # mylist.add("59")
                numlist.remove("01")
            if tem == "02":
                Driver02.active = True
                Driver02.dvr = None
                Driver02.manu = PlayerUno.organization.orgmanu
                Driver02.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver02)
                # mylist.add("59")
                numlist.remove("02")
            if tem == "09":
                Driver09.active = True
                Driver09.dvr = None
                Driver09.manu = PlayerUno.organization.orgmanu
                Driver09.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver02)
                # mylist.add("59")
                numlist.remove("09")
            if tem == "5":
                Driver5.active = True
                Driver5.dvr = None
                Driver5.manu = PlayerUno.organization.orgmanu
                Driver5.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver5)
                #mylist.add("59")
                numlist.remove("5")
            if tem == "7":
                Driver7.active = True
                Driver7.dvr = None
                Driver7.manu = PlayerUno.organization.orgmanu
                Driver7.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver7)
                #mylist.add("59")
                numlist.remove("7")
            if tem == "23":
                Driver23.active = True
                Driver23.dvr = None
                Driver23.manu = PlayerUno.organization.orgmanu
                Driver23.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver23)
                # mylist.add("59")
                numlist.remove("23")
            if tem == "25":
                Driver25.active = True
                Driver25.dvr = None
                Driver25.manu = PlayerUno.organization.orgmanu
                Driver25.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver25)
                # mylist.add("59")
                numlist.remove("25")
            if tem == "26":
                Driver26.active = True
                Driver26.dvr = None
                Driver26.manu = PlayerUno.organization.orgmanu
                Driver26.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver26)
                # mylist.add("59")
                numlist.remove("26")
            if tem == "30":
                Driver30.active = True
                Driver30.dvr = None
                Driver30.manu = PlayerUno.organization.orgmanu
                Driver30.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver30)
                # mylist.add("59")
                numlist.remove("30")
            if tem == "31":
                Driver31.active = True
                Driver31.dvr = None
                Driver31.manu = PlayerUno.organization.orgmanu
                Driver31.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver31)
                # mylist.add("59")
                numlist.remove("31")
            if tem == "33":
                Driver33.active = True
                Driver33.dvr = None
                Driver33.manu = PlayerUno.organization.orgmanu
                Driver33.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver33)
                # mylist.add("59")
                numlist.remove("33")
            if tem == "40":
                Driver40.active = True
                Driver40.dvr = None
                Driver40.manu = PlayerUno.organization.orgmanu
                Driver40.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver40)
                # mylist.add("59")
                numlist.remove("40")
            if tem == "44":
                Driver44.active = True
                Driver44.dvr = None
                Driver44.manu = PlayerUno.organization.orgmanu
                Driver44.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver44)
                # mylist.add("59")
                numlist.remove("44")
            if tem == "45":
                Driver45.active = True
                Driver45.dvr = None
                Driver45.manu = PlayerUno.organization.orgmanu
                Driver45.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver45)
                # mylist.add("59")
                numlist.remove("45")
            if tem == "46":
                Driver46.active = True
                Driver46.dvr = None
                Driver46.manu = PlayerUno.organization.orgmanu
                Driver46.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver45)
                # mylist.add("59")
                numlist.remove("46")
            if tem == "50":
                Driver50.active = True
                Driver50.dvr = None
                Driver50.manu = PlayerUno.organization.orgmanu
                Driver50.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver50)
                #mylist.add("59")
                numlist.remove("50")
            if tem == "52":
                Driver52.active = True
                Driver52.dvr = None
                Driver52.manu = PlayerUno.organization.orgmanu
                Driver52.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver52)
                #mylist.add("59")
                numlist.remove("52")
            if tem == "57":
                Driver57.active = True
                Driver57.dvr = None
                Driver57.manu = PlayerUno.organization.orgmanu
                Driver57.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver57)
                #mylist.add("59")
                numlist.remove("57")
            if tem == "59":
                Driver59.active = True
                Driver59.dvr = None
                Driver59.manu = PlayerUno.organization.orgmanu
                Driver59.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver59)
                #mylist.add("59")
                numlist.remove("59")
            if tem == "60":
                Driver60.active = True
                Driver60.dvr = None
                Driver60.sponsor = None
                Driver60.manu = PlayerUno.organization.orgmanu
                Driver60.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver60)
                #mylist.add("59")
                numlist.remove("59")
            if tem == "69":
                Driver69.active = True
                Driver69.dvr = None
                Driver69.sponsor = None
                Driver69.manu = PlayerUno.organization.orgmanu
                Driver69.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver69)
                #mylist.add("59")
                numlist.remove("69")
            if tem == "70":
                Driver70.active = True
                Driver70.dvr = None
                Driver70.sponsor = None
                Driver70.manu = PlayerUno.organization.orgmanu
                Driver70.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver70)
                # mylist.add("59")
                numlist.remove("70")
            if tem == "72":
                Driver72.active = True
                Driver72.dvr = None
                Driver72.sponsor = None
                Driver72.manu = PlayerUno.organization.orgmanu
                Driver72.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver72)
                # mylist.add("59")
                numlist.remove("72")
            if tem == "78":
                Driver78.active = True
                Driver78.dvr = None
                Driver78.sponsor = None
                Driver78.manu = PlayerUno.organization.orgmanu
                Driver78.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver78)
                #mylist.add("59")
                numlist.remove("78")
            if tem == "79":
                Driver79.active = True
                Driver79.dvr = None
                Driver79.sponsor = None
                Driver79.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver79)
                Driver79.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("93")
            if tem == "80":
                Driver80.active = True
                Driver80.dvr = None
                Driver80.sponsor = None
                Driver80.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver80)
                Driver80.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("80")
            if tem == "81":
                Driver81.active = True
                Driver81.dvr = None
                Driver81.sponsor = None
                Driver81.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver81)
                Driver81.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("81")
            if tem == "83":
                Driver83.active = True
                Driver83.dvr = None
                Driver83.sponsor = None
                Driver83.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver83)
                Driver83.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("83")
            if tem == "84":
                Driver84.active = True
                Driver84.dvr = None
                Driver84.sponsor = None
                Driver84.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver84)
                Driver84.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("84")
            if tem == "90":
                Driver90.active = True
                Driver90.dvr = None
                Driver90.sponsor = None
                Driver90.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver90)
                Driver90.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("90")
            if tem == "91":
                Driver91.active = True
                Driver91.dvr = None
                Driver91.sponsor = None
                Driver91.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver91)
                Driver91.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("91")
            if tem == "93":
                Driver93.active = True
                Driver93.dvr = None
                Driver93.sponsor = None
                Driver93.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver93)
                Driver93.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("93")
            if tem == "94":
                Driver94.active = True
                Driver94.dvr = None
                Driver94.team1 = PlayerUno.organization.orgname
                Driver94.manu = PlayerUno.organization.orgmanu
                PlayerUno.organization.orgteams.append(Driver94)
                #mylist.add("94")
                numlist.remove("94")
            if tem == "97":
                Driver97.active = True
                Driver97.dvr = None
                Driver97.team1 = PlayerUno.organization.orgname
                Driver97.manu = PlayerUno.organization.orgmanu
                PlayerUno.organization.orgteams.append(Driver97)
                #mylist.add("97")
                numlist.remove("97")
            if tem == "98":
                Driver98.active = True
                Driver98.dvr = None
                Driver98.sponsor = None
                Driver98.manu = PlayerUno.organization.orgmanu
                Driver98.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver98)
                #mylist.add("98")
                numlist.remove("98")
            if tem == "99":
                Driver99.active = True
                Driver99.dvr = None
                Driver99.sponsor = None
                Driver99.manu = PlayerUno.organization.orgmanu
                Driver99.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver99)
                #mylist.add("99")
                numlist.remove("99")


        button = Button(newW, text="Submit", command=ok)
        button.grid(row=3, column=0)

    def newparttime():
        PlayerUno.organization.money -= 200000
        button1.destroy()
        button2.destroy()
        newL.destroy()
        newL2.destroy()
        newL3 = Label(newW, text="Select Car #")
        newL3.grid(row=0, column=0)
        #nice = Entry(newW)
        #nice.grid(row=0, column=1)
        global variable12
        variable12 = StringVar(newW)
        variable12.set(numlist[0])
                # print("USER ENTRY", user_entry)
        w = OptionMenu(newW, variable12, *numlist)
        w.grid(row=1,column=0,columnspan=2)


        def ok():
            global PlayerUno
            global variable12
            tem = variable12.get()
            print("TEM", tem)
            if tem == "0":
                Driver0.active = True
                Driver0.dvr = None
                Driver0.parttime = True
                Driver0.manu = PlayerUno.organization.orgmanu
                Driver0.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver0)
                #mylist.add("59")
                numlist.remove("0")
            if tem == "01":
                Driver01.active = True
                Driver01.dvr = None
                Driver01.parttime = True
                Driver01.manu = PlayerUno.organization.orgmanu
                Driver01.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver01)
                # mylist.add("59")
                numlist.remove("01")
            if tem == "02":
                Driver02.active = True
                Driver02.dvr = None
                Driver02.parttime = True
                Driver02.manu = PlayerUno.organization.orgmanu
                Driver02.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver02)
                # mylist.add("59")
                numlist.remove("02")
            if tem == "09":
                Driver09.active = True
                Driver09.dvr = None
                Driver09.parttime = True
                Driver09.manu = PlayerUno.organization.orgmanu
                Driver09.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver02)
                # mylist.add("59")
                numlist.remove("09")
            if tem == "5":
                Driver5.active = True
                Driver5.dvr = None
                Driver5.parttime = True
                Driver5.manu = PlayerUno.organization.orgmanu
                Driver5.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver5)
                #mylist.add("59")
                numlist.remove("5")
            if tem == "7":
                Driver7.active = True
                Driver7.dvr = None
                Driver7.parttime = True
                Driver7.manu = PlayerUno.organization.orgmanu
                Driver7.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver7)
                #mylist.add("59")
                numlist.remove("7")
            if tem == "23":
                Driver23.active = True
                Driver23.dvr = None
                Driver23.parttime = True
                Driver23.manu = PlayerUno.organization.orgmanu
                Driver23.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver23)
                # mylist.add("59")
                numlist.remove("23")
            if tem == "25":
                Driver25.active = True
                Driver25.dvr = None
                Driver25.parttime = True
                Driver25.manu = PlayerUno.organization.orgmanu
                Driver25.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver25)
                # mylist.add("59")
                numlist.remove("25")
            if tem == "26":
                Driver26.active = True
                Driver26.dvr = None
                Driver26.parttime = True
                Driver26.manu = PlayerUno.organization.orgmanu
                Driver26.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver26)
                # mylist.add("59")
                numlist.remove("26")
            if tem == "30":
                Driver30.active = True
                Driver30.dvr = None
                Driver30.parttime = True
                Driver30.manu = PlayerUno.organization.orgmanu
                Driver30.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver30)
                # mylist.add("59")
                numlist.remove("30")
            if tem == "31":
                Driver31.active = True
                Driver31.dvr = None
                Driver31.parttime = True
                Driver31.manu = PlayerUno.organization.orgmanu
                Driver31.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver31)
                # mylist.add("59")
                numlist.remove("31")
            if tem == "33":
                Driver33.active = True
                Driver33.dvr = None
                Driver33.parttime = True
                Driver33.manu = PlayerUno.organization.orgmanu
                Driver33.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver33)
                # mylist.add("59")
                numlist.remove("33")
            if tem == "39":
                Driver39.active = True
                Driver39.dvr = None
                Driver39.parttime = True
                Driver39.manu = PlayerUno.organization.orgmanu
                Driver39.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver39)
                # mylist.add("59")
                numlist.remove("40")
            if tem == "40":
                Driver40.active = True
                Driver40.dvr = None
                Driver40.parttime = True
                Driver40.manu = PlayerUno.organization.orgmanu
                Driver40.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver40)
                # mylist.add("59")
                numlist.remove("40")
            if tem == "44":
                Driver44.active = True
                Driver44.dvr = None
                Driver44.parttime = True
                Driver44.manu = PlayerUno.organization.orgmanu
                Driver44.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver44)
                # mylist.add("59")
                numlist.remove("44")
            if tem == "45":
                Driver45.active = True
                Driver45.dvr = None
                Driver45.parttime = True
                Driver45.manu = PlayerUno.organization.orgmanu
                Driver45.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver45)
                # mylist.add("59")
                numlist.remove("45")
            if tem == "46":
                Driver46.active = True
                Driver46.dvr = None
                Driver46.parttime = True
                Driver46.manu = PlayerUno.organization.orgmanu
                Driver46.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver45)
                # mylist.add("59")
                numlist.remove("46")
            if tem == "50":
                Driver50.active = True
                Driver50.dvr = None
                Driver50.parttime = True
                Driver50.manu = PlayerUno.organization.orgmanu
                Driver50.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver50)
                #mylist.add("59")
                numlist.remove("50")
            if tem == "52":
                Driver52.active = True
                Driver52.dvr = None
                Driver52.parttime = True
                Driver52.manu = PlayerUno.organization.orgmanu
                Driver52.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver52)
                #mylist.add("59")
                numlist.remove("52")
            if tem == "57":
                Driver57.active = True
                Driver57.dvr = None
                Driver57.parttime = True
                Driver57.manu = PlayerUno.organization.orgmanu
                Driver57.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver57)
                #mylist.add("59")
                numlist.remove("57")
            if tem == "59":
                Driver59.active = True
                Driver59.dvr = None
                Driver59.parttime = True
                Driver59.manu = PlayerUno.organization.orgmanu
                Driver59.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver59)
                #mylist.add("59")
                numlist.remove("59")
            if tem == "60":
                Driver60.active = True
                Driver60.dvr = None
                Driver60.parttime = True
                Driver60.sponsor = None
                Driver60.manu = PlayerUno.organization.orgmanu
                Driver60.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver60)
                #mylist.add("59")
                numlist.remove("59")
            if tem == "69":
                Driver69.active = True
                Driver69.dvr = None
                Driver69.sponsor = None
                Driver69.parttime = True
                Driver69.manu = PlayerUno.organization.orgmanu
                Driver69.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver69)
                #mylist.add("59")
                numlist.remove("69")
            if tem == "70":
                Driver70.active = True
                Driver70.dvr = None
                Driver70.sponsor = None
                Driver70.parttime = True
                Driver70.manu = PlayerUno.organization.orgmanu
                Driver70.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver70)
                # mylist.add("59")
                numlist.remove("70")
            if tem == "72":
                Driver72.active = True
                Driver72.dvr = None
                Driver72.sponsor = None
                Driver72.parttime = True
                Driver72.manu = PlayerUno.organization.orgmanu
                Driver72.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver72)
                # mylist.add("59")
                numlist.remove("72")
            if tem == "78":
                Driver78.active = True
                Driver78.dvr = None
                Driver78.sponsor = None
                Driver78.parttime = True
                Driver78.manu = PlayerUno.organization.orgmanu
                Driver78.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver78)
                #mylist.add("59")
                numlist.remove("78")
            if tem == "79":
                Driver79.active = True
                Driver79.dvr = None
                Driver79.sponsor = None
                Driver79.parttime = True
                Driver79.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver79)
                Driver79.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("93")
            if tem == "80":
                Driver80.active = True
                Driver80.dvr = None
                Driver80.sponsor = None
                Driver80.parttime = True
                Driver80.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver80)
                Driver80.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("80")
            if tem == "81":
                Driver81.active = True
                Driver81.dvr = None
                Driver81.sponsor = None
                Driver81.parttime = True
                Driver81.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver81)
                Driver81.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("81")
            if tem == "83":
                Driver83.active = True
                Driver83.dvr = None
                Driver83.sponsor = None
                Driver83.parttime = True
                Driver83.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver83)
                Driver83.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("83")
            if tem == "84":
                Driver84.active = True
                Driver84.dvr = None
                Driver84.sponsor = None
                Driver84.parttime = True
                Driver84.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver84)
                Driver84.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("84")
            if tem == "90":
                Driver90.active = True
                Driver90.dvr = None
                Driver90.sponsor = None
                Driver90.parttime = True
                Driver90.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver91)
                Driver90.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("90")
            if tem == "91":
                Driver91.active = True
                Driver91.dvr = None
                Driver91.sponsor = None
                Driver91.parttime = True
                Driver91.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver91)
                Driver91.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("91")
            if tem == "93":
                Driver93.active = True
                Driver93.dvr = None
                Driver93.sponsor = None
                Driver93.parttime = True
                Driver93.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver93)
                Driver93.manu = PlayerUno.organization.orgmanu
                #mylist.add("93")
                numlist.remove("93")
            if tem == "94":
                Driver94.active = True
                Driver94.dvr = None
                Driver94.parttime = True
                Driver94.team1 = PlayerUno.organization.orgname
                Driver94.manu = PlayerUno.organization.orgmanu
                PlayerUno.organization.orgteams.append(Driver94)
                #mylist.add("94")
                numlist.remove("94")
            if tem == "97":
                Driver97.active = True
                Driver97.dvr = None
                Driver97.parttime = True
                Driver97.team1 = PlayerUno.organization.orgname
                Driver97.manu = PlayerUno.organization.orgmanu
                PlayerUno.organization.orgteams.append(Driver97)
                #mylist.add("97")
                numlist.remove("97")
            if tem == "98":
                Driver98.active = True
                Driver98.dvr = None
                Driver98.sponsor = None
                Driver98.parttime = True
                Driver98.manu = PlayerUno.organization.orgmanu
                Driver98.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver98)
                #mylist.add("98")
                numlist.remove("98")
            if tem == "99":
                Driver99.active = True
                Driver99.dvr = None
                Driver99.sponsor = None
                Driver99.parttime = True
                Driver99.manu = PlayerUno.organization.orgmanu
                Driver99.team1 = PlayerUno.organization.orgname
                PlayerUno.organization.orgteams.append(Driver99)
                #mylist.add("99")
                numlist.remove("99")


        button = Button(newW, text="Submit", command=ok)
        button.grid(row=3, column=0)

    button1 = Button(newW, text="New Full Time Car", width=20, height=2, command=newfulltime)
    button1.grid(row=1, column=0)
    if PlayerUno.organization.money < 200000:
        button1["state"] = DISABLED
    if PlayerUno.organization.money > 200000:
        button1["state"] = ACTIVE
    newL = Label(newW, text="Costs 200,000 thousand dollars")
    newL.grid(row=1, column=1)

    button2 = Button(newW, text="New Part Time Car", width=20, height=2, command=newparttime)
    button2.grid(row=2, column=0)
    if PlayerUno.organization.money < 125000:
        button1["state"] = DISABLED
    if PlayerUno.organization.money > 125000:
        button1["state"] = ACTIVE
    newL2 = Label(newW, text="Costs 125,000 thousand dollars")
    newL2.grid(row=2, column=1)








def firehire():
    mode = "Rating"
    global selectedCar
    firehire1 = Tk()
    firehire1.geometry("600x230")
    if selectedCar.dvr:
        if selectedCar.dvr:
            Label(firehire1, text="Team: " + str(
                selectedCar.num1) + " Driver : " + selectedCar.dvr.name + " | Years Left on Contract: " + str(
                selectedCar.yrsleft)).grid(
                row=0, column=0, columnspan=2)

    else:
        Label(firehire1, text="Team: " + str(selectedCar.num1) + " Driver : None").grid(row=0, column=0, columnspan=2)


    def fire():
        global selectedCar
        fire1 = Tk()
        fire1.geometry("600x230")
        Label(fire1, text="Fired: " + str(selectedCar.dvr.name)).grid(row=0, column=0, columnspan=2)
        mylist.remove(str(selectedCar.num1))
        temp = copy.deepcopy(selectedCar)
        selectedCar.active = False
        selectedCar.dvr = None
        freeagentlist.append(temp)
        freelist.append(temp.dvr)

        def ok():
            fire1.destroy()
            firehire1.destroy()
        button = Button(fire1, text="Ok", command=ok)
        button.grid(row=3, column=0)

    def hire():
        hire1 = Tk()
        hire1.geometry("500x230")
        hire1.title("Hire Driver Screen")
        # button2 = Button(myteamWindow1, text="Free Agent Scouter", width=20, height=2, command=freeagentscouter)
        # button2.grid(row=5, column=0, columnspan=1

        racelistbox = Listbox(hire1, width=80)
        racelistbox.grid(row=1, column=0, columnspan=2)
        global freelist
        print("MAC6", freelist)
        for i in freelist:
            print(i.name)
        free1 = sorted(freelist, key=lambda Driver: Driver.rating, reverse=True)
        print(free1)
        for i in free1:
            if i.age > 19:
                racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))

        Label(hire1,text="Double Click a Driver to Make an Offer").grid(row=3, column=0)
        '''
        def sort_age():
            racelistbox.delete('0', 'end')
            free1 = sorted(free, key=lambda Driver: Driver.age, reverse=True)
            for i in free1:
                if i.age > 19:
                    racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))
        
            mode = "Age"

        def sort_rating():
            racelistbox.delete('0', 'end')
            free1 = sorted(free, key=lambda Driver: Driver.rating, reverse=True)
            for i in free1:
                if i.age > 19:
                    racelistbox.insert(END, "Name: " + i.name + " Age: " + str(i.age) + " Rating: " + str(i.rating))
            mode = "Rating"

        button1 = Button(hire1, text="Sort by Age", width=20, height=2, command=sort_age)
        button1.grid(row=3, column=0)

        button2 = Button(hire1, text="Sort by Rating", width=20, height=2, command=sort_rating)
        button2.grid(row=3, column=1)

        '''


        def selectfa(event):
            global driver0
            widget = event.widget
            selection = widget.curselection()
            fa = widget.get(selection[0])
            #fa1 = (freeagentlist[(selection[0])]).dvr
            #if mode=
            #free1 = sorted(free, key=lambda Driver: Driver.rating, reverse=True)
            free2 = []
            for i in free1:
                if i.age > 19:
                    free2.append(i)
            fa1 = (free2[(selection[0])])
            print(fa, fa1)
            neg = Tk()
            Label(neg, text="Negotiations with: " + str(fa1.name)).grid(row=0, column=0, columnspan=2)
            global amt
            great = []
            good = []
            ok = []
            bad = []
            years_young = [1,2,3,4,5]
            years_old = [1,2]

            def yes():
                global driver0
                print(driver0.name, "H3H3")
                selectedCar.dvr = driver0
                selectedCar.active = True
                mylist.add(str(selectedCar.num1))
                for i in freeagentlist:
                    if i.dvr.name == driver0.name:
                        freeagentlist.remove(i)
                for i in freelist:
                    if i.name == driver0.name:
                        freelist.remove(i)

                neg.destroy()
                hire1.destroy()
                firehire1.destroy()


            for i in range(1000, 2500):
                if i % 10 == 0:
                    great.append(i)
            for i in range(750, 1500):
                if i % 10 == 0:
                    good.append(i)
            for i in range(450, 800):
                if i % 10 == 0:
                    ok.append(i)
            for i in range(250, 500):
                if i % 10 == 0:
                    bad.append(i)

            driver0 = fa1

            if driver0.age >= 40:
                if driver0.rating >= 85:
                    val = random.choice(great)
                    val = val*5
                    yr = random.choice(years_old)
                    Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                        val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                if driver0.rating < 85 and driver0.rating >= 73:
                    val = random.choice(good)
                    val = val*1.25
                    yr = random.choice(years_old)
                    Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                        val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                if driver0.rating < 73 and driver0.rating >= 63:
                    val = random.choice(ok)
                    yr = random.choice(years_old)
                    Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                        val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                if driver0.rating < 63:
                    val = random.choice(bad)
                    yr = random.choice(years_old)
                    Label(neg, text=str(fa1.name) + " wants a " + str(yr) + " year deal worth " + str(
                        val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)

                button4 = Button(neg, text="Yes", width=20, height=2, command=yes)
                button4.grid(row=2, column=0)

            if driver0.age < 40:
                if driver0.rating >= 85:
                    val = random.choice(great)
                    yr = random.choice(years_young)
                    Label(neg, text=str(fa1.name) + "wants a " +  str(yr) + " year deal worth " + str(val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                if driver0.rating < 85 and driver0.rating >= 73:
                    val = random.choice(good)
                    yr = random.choice(years_young)
                    Label(neg, text=str(fa1.name) + "wants a " +  str(yr) + " year deal worth " + str(val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                if driver0.rating < 73 and driver0.rating >= 63:
                    val = random.choice(ok)
                    yr = random.choice(years_young)
                    Label(neg, text=str(fa1.name) + "wants a " +  str(yr) + " year deal worth " + str(val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)
                if driver0.rating < 63:
                    val = random.choice(bad)
                    yr = random.choice(years_young)
                    Label(neg, text=str(fa1.name) + "wants a " + str(yr) + " year deal worth " + str(val) + " thousand dollars. Accept?").grid(row=0, column=0, columnspan=2)


                button4 = Button(neg, text="Yes", width=20, height=2, command=yes)
                button4.grid(row=2,column=0)

        racelistbox.bind("<Double-Button-1>", selectfa)





    button2 = Button(firehire1, text="Fire Driver", width=20, height=2, command=fire)
    button2.grid(row=1, column=0)
    Label(firehire1,
          text="Warning: If you fire a driver and do not hire a replacement, your car will not be able to participate in any races! ").grid(
        row=2, column=0, columnspan=2)


    button3= Button(firehire1, text="Hire Driver", width=20, height=2, command=hire)
    button3.grid(row=1, column=1)


    def upgrade_EQ():
        global PlayerUno
        print("spawn")
        selectedCar.prestige += 2
        if selectedCar.prestige > 100:
            selectedCar.prestige = 100

        PlayerUno.organization.money = PlayerUno.organization.money - 50000
        print("spawn")
        firehire1.destroy()

    button4 = Button(firehire1, text="Upgrade Equipment", width=20, height=2, command=upgrade_EQ)
    button4.grid(row=4, column=0, columnspan=1)

    Label(firehire1,
          text="Pay $50,000 and upgrade car prestige by 2 ").grid(
        row=4, column=1, columnspan=2)
    if PlayerUno.organization.money < 50000:

        button4["state"] = DISABLED
    else:
        button4["state"] = ACTIVE

    if selectedCar.dvr:
        button2["state"] = ACTIVE
        button3["state"] = DISABLED
    else:
        button2["state"] = DISABLED
        button3["state"] = ACTIVE

    def sponsor():
        #for i in sponsorlist:
        a = random.choice(sponsorlist)
        b = random.choice(sponsorlist)
        c = random.choice(sponsorlist)



        print(a,b,c)
        sw = Tk()
        if selectedCar.prestige > 70:
            Label(sw, text="Three sponsors have expressed interest in sponsoring your car, pick which one you would like").grid(row=0, column=0,columnspan=3)
        if selectedCar.prestige <= 70 and selectedCar.prestige > 60:
            Label(sw,
                  text="Two sponsors have expressed interest in sponsoring your car, pick which one you would like").grid(
                row=0, column=0, columnspan=3)
        if selectedCar.prestige <= 60:
            Label(sw,
                  text="No Sponsors have expressed interest in sponsoring your car, check again next week. Hint: the higher your car and team prestige, the more likely you are to attract sponsors.").grid(
                row=0, column=0, columnspan=3)
        payout = []
        if PlayerUno.organization.orgprestige >= 90:
            payout = [20000, 19000, 18000, 17000, 16000, 15000, 14000, 13000]
        if PlayerUno.organization.orgprestige >= 80 and PlayerUno.organization.orgprestige < 90:
            payout = [15000, 14000, 13000, 12000, 11000, 10000, 9000, 8000]
        if PlayerUno.organization.orgprestige < 80:
            payout = [10000, 9000, 8000, 7000, 6000]

        payouta = random.choice(payout)
        payoutb = random.choice(payout)
        payoutc = random.choice(payout)
        def sa():
            selectedCar.sponsor = a
            PlayerUno.organization.money += payouta
            sw.destroy()
        def sb():
            selectedCar.sponsor = b
            PlayerUno.organization.money += payoutb
            sw.destroy()
        def sc():
            selectedCar.sponsor = c
            PlayerUno.organization.money += payoutc
            sw.destroy()



        if selectedCar.prestige > 60:
            buttona = Button(sw, text=a, width=20, height=2, command=sa)
            buttona.grid(row=1, column=0)
            Label(sw, text="Will Pay: " + str(payouta)).grid(row=2, column=0)
            buttonb = Button(sw, text=b, width=20, height=2, command=sb)
            buttonb.grid(row=1, column=1)
            Label(sw, text="Will Pay: " + str(payoutb)).grid(row=2, column=1)
            if selectedCar.prestige >= 70:
                buttonc = Button(sw, text=c, width=20, height=2, command=sc)
                buttonc.grid(row=1, column=2)
                Label(sw, text="Will Pay: " + str(payoutc)).grid(row=2, column=2)


    button5 = Button(firehire1, text="Find Sponsors", width=20, height=2, command=sponsor)
    button5.grid(row=5, column=0, columnspan=1)
    if selectedCar.sponsor:
        print("herry", selectedCar.sponsor)
        if selectedCar.sponsor == "Unsponsored":
            button5["state"] = ACTIVE
        else:
            button5["state"] = DISABLED
    else:
        button5["state"] = ACTIVE
    print("jet fuel")

    def upgrade():
        selectedCar.parttime = False
        PlayerUno.organization.money -= 100000

    if selectedCar.parttime:
        button6 = Button(firehire1, text="Upgrade From Part-Time to Full-Time", width=30, height=2, command=upgrade)
        button6.grid(row=6, column=0, columnspan=1)
        Label(firehire1,
              text="Pay $100,000 and upgrade your car from part-time to full-time ").grid(
            row=4, column=1, columnspan=2)


def edit():
    global PlayerUno
    global selectedCar
    temp = []
    for i in PlayerUno.organization.orgteams:
        temp.append(str(i.num1))
    print("temp")
    myteamWindowedit = Tk()
    myteamWindowedit.geometry("500x230")
    Label(myteamWindowedit, text="Team Funds (In Thousands): " + str(PlayerUno.organization.money)).grid(row=0, column=0, columnspan=2)
    Label(myteamWindowedit, text="Select a Team: ").grid(row=1, column=0)

    variable = StringVar(myteamWindowedit)
    variable.set(temp[0])
    w = OptionMenu(myteamWindowedit, variable, *temp)
    # e1.focus_set()
    # def ok():
    #   print("chose, variale.get", variable.get)

    w.grid(row=2, column=1)

    def ok():


        tem = variable.get()
        print("TEM", tem)

        for i in PlayerUno.organization.orgteams:
            if str(i.num1) == tem:
                print("true")
                global selectedCar
                selectedCar = i
                print("AC", selectedCar)
                myteamWindowedit.destroy()
                firehire()


    button = Button(myteamWindowedit, text="Submit", command=ok)
    button.grid(row=3, column=1)



def myteamedit():
    global PlayerUno
    myteamWindow = Tk()
    myteamWindow.geometry("500x230")
    myteamWindow.title("MyTeam Edit Information")
    Label(myteamWindow,text="Team Funds (In Thousands): " + str(PlayerUno.organization.money)).grid(row=1, column=0)
    button1 = Button(myteamWindow, text="Free Agent List", width=20, height=2, command=freeagentscouter)
    button1.grid(row=2, column=0, columnspan =1)
    button2 = Button(myteamWindow, text="Scout For Talent", width=20, height=2, command=newtalent)
    button2.grid(row=3, column=0, columnspan=1)
    button2 = Button(myteamWindow, text="Edit Team", width=20, height=2, command=edit)
    button2.grid(row=4, column=0, columnspan=1)

    button3 = Button(myteamWindow, text="Create New Team", width=20, height=2, command=new)
    button3.grid(row=5, column=0, columnspan=1)



    if len(PlayerUno.organization.orgteams) >= 4:
        button3["state"] = DISABLED
    '''
    z = 0
    z = 0
    for i in PlayerUno.organization.orgteams:

        Button(myteamWindow, text="Car #"+str(i.num1), width=20, height=2, command=newtalent).grid(row=z, column=1, columnspan=1)
        z+=1
    '''

def initorg2020():
    global mylist
    #game_gui.destroy()
    # self.parent.maxsize(750, 550)
    #root = tk.Tk()
    global wrestlemania
    wrestlemania =36
    #root.minsize(400, 120)
    root.geometry("457x230")
    root.title("AutoSim BETA")
    global champions
    global daytona
    champions[2015] = "#18 Kyle Busch - Joe Gibbs Racing"
    champions[2016] = "#48 Jimmie Johnson - Hendrick Motorsports"
    champions[2017] = "#78 Martin Truex Jr - Furniture Row Racing"
    champions[2018] = "#22 Joey Logano - Team Penske"
    champions[2019] = "#18 Kyle Busch - Joe Gibbs Racing"
    daytona[2015] = "#22 Joey Logano - Team Penske"
    daytona[2016] = "#11 Denny Hamlin - Joe Gibbs Racing"
    daytona[2017] = "#41 Kurt Busch - Stewart-Haas Racing"
    daytona[2018] = "#3 Austin Dillon - Richard Childress Racing"
    daytona[2019] = "#11 Denny Hamlin - Joe Gibbs Racing"

    # myButton1 = Button(root, text = "Time", command = update)
    # myButton1.grid(row=0, column=0)

    global week
    global year
    global cup
    global start_year
    global PlayerUno
    week=1
    year = 2020
    start_year = 2020
    cup = "Nascar Cup Series"
    if year == 2005:
        weeklabel = Label(root, text="Week:" + str(week-1))
    else:
        weeklabel = Label(root, text="Week:" + str(week))
    #yearlabel = Label(root, text="Year:" + str(year))
    cuplabel = Label(root, text=cup)
    weeklabel.grid(row=0, column=0)
    #yearlabel.grid(row=0, column=1, columnspan = 3)
    cuplabel.grid(row=1, column=0, columnspan = 3)
    cuplabel.configure(anchor="center")
    playerlabel = Label(root, text="Name: " + PlayerUno.playername)
    teamlabel = Label(root, text="Team: " + PlayerUno.organization.orgname)
    playerlabel.grid (row=2)
    teamlabel.grid(row=2, column=1)
    myButton = Button(root, text="Run Race", width=20, height=2, command=myClick)
    myButton.grid(row=5, column=0, columnspan =1)

    myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
    myButton2.grid(row=5, column=1, columnspan =1)

    stg = Button(root, text="Standings", width=20, height=2, command=gui_standings)
    stg.grid(row=6, column=0 , columnspan =1)

    sceg = Button(root, text="Schedule", width=20, height=2, command=gui_schedule)
    sceg.grid(row=6, column=1, columnspan=1)
    #sceg["state"] = DISABLED

    dvrstats = Button(root, text="Driver Stats", width=20, height=2, command=driverInfo)
    dvrstats.grid(row=7, column=0 , columnspan =1)

    rtrstats = Button(root, text="Retired Driver Stats", width=20, height=2, command=retireInfo)
    rtrstats.grid(row=7, column=1, columnspan=1)

    dvrstats = Button(root, text="Hall of Champions", width=20, height=2, command=gui_champ)
    dvrstats.grid(row=8, column=0 , columnspan =1)

    dvrstats = Button(root, text="Daytona 500 Winners", width=20, height=2, command=gui_500)
    dvrstats.grid(row=8, column=1 , columnspan =1)

    dvrstats = Button(root, text="Team Overview", width=20, height=2, command=myteam)
    dvrstats.grid(row=5, column=2, columnspan=1)

    dvrstats = Button(root, text="Team Editor & Upgrades", width=20, height=2, command=myteamedit)
    dvrstats.grid(row=6, column=2, columnspan=1)

    load1 = Button(root, text="Load", width=20, height=2, command=load_game2020)
    load1.grid(row=7, column=2, columnspan=1)
    #load1["state"] = DISABLED

    save1 = Button(root, text="Save", width=20, height=2, command=save_game)
    save1.grid(row=8, column=2, columnspan=1)

class Passwordchecker(tk.Frame):
    def __init__(self, parent):
        tk.Frame.__init__(self, parent)
        self.parent = parent
        self.initialize_user_interface()
        # year = 2005
        # week = 1

    def OnDouble(self, event):
        global mylist
        widget = event.widget
        selection = widget.curselection()
        value = widget.get(selection[0])
        driverWindow = tk.Toplevel(root)
        driverWindow.geometry("400x300")
        driverWindow.title("Driver Window")
        car = assign(mylist[(selection[0])])
        myLabel4 = Label(driverWindow, text="Driver Statistics: " + str(car.dvr.name))
        myLabel4.grid(row=4, column=0)
        myLabel5 = Label(driverWindow, text="Wins: " + str(car.dvr.wins))
        myLabel5.grid(row=5, column=0)
        myLabel6 = Label(driverWindow, text="Top Fives: " + str(car.dvr.topfives))
        myLabel6.grid(row=6, column=0)
        myLabel7 = Label(driverWindow, text="Top Tens: " + str(car.dvr.toptens))
        myLabel7.grid(row=7, column=0)
        myLabel7 = Label(driverWindow, text="Championships: " + str(car.dvr.titles))
        myLabel7.grid(row=8, column=0)

    def initialize_user_interface(self):
        global mylist

        # self.parent.maxsize(750, 550)
        self.parent.minsize(300, 120)
        self.parent.title("AutoSim BETA")

        # myButton1 = Button(root, text = "Time", command = update)
        # myButton1.grid(row=0, column=0)


        weeklabel = Label(root, text="Week:" + str(week))
        yearlabel = Label(root, text="Year:" + str(year))
        cuplabel = Label(root, text=cup)
        weeklabel.grid(row=0, column=0)
        yearlabel.grid(row=0, column=1)
        cuplabel.grid(row=1, column=0, columnspan = 2)
        cuplabel.configure(anchor="center")
        '''
        myButton = Button(root, text="Run Race", width=20, height=2, command=myClick)
        myButton.grid(row=5, column=0, columnspan =1)

        myButton2 = Button(root, text="Fast Sim", width=20, height=2, command=myClick2)
        myButton2.grid(row=5, column=1, columnspan =1)

        stg = Button(root, text="Standings", width=20, height=2, command=gui_standings)
        stg.grid(row=6, column=0 , columnspan =1)

        sceg = Button(root, text="Schedule", width=20, height=2, command=gui_schedule)
        sceg.grid(row=6, column=1, columnspan=1)
        #sceg["state"] = DISABLED

        dvrstats = Button(root, text="Driver Stats", width=20, height=2, command=driverInfo)
        dvrstats.grid(row=7, column=0 , columnspan =1)

        rtrstats = Button(root, text="Retired Driver Stats", width=20, height=2, command=retireInfo)
        rtrstats.grid(row=7, column=1, columnspan=1)

        dvrstats = Button(root, text="Hall of Champions", width=20, height=2, command=gui_champ)
        dvrstats.grid(row=8, column=0 , columnspan =1)

        dvrstats = Button(root, text="Daytona 500 Winners", width=20, height=2, command=gui_500)
        dvrstats.grid(row=8, column=1 , columnspan =1)

        dvrstats = Button(root, text="Load", width=20, height=2, command=load_game2020)
        dvrstats.grid(row=9, column=0, columnspan=1)

        dvrstats = Button(root, text="Save", width=20, height=2, command=save_game)
        dvrstats.grid(row=9, column=1, columnspan=1)
        '''

global e1



def start_game():
    root.title("Owner Mode Selection Window")
    for i in orglist_names:
        print(i)
    root.geometry("400x300")
    ab = Label(root, text="Name")
    ab.grid(row=0)
    lb = Label(root, text="Team")
    lb.grid(row=1)

    variable = StringVar(root)
    variable.set(orglist_names[0])
    nice = Entry(root)
    nice.grid(row=0, column=1)

   #print("USER ENTRY", user_entry)
    w = OptionMenu(root, variable, *orglist_names)
    #e1.focus_set()
    #def ok():
     #   print("chose, variale.get", variable.get)



    w.grid(row=1, column=1)

    def ok():
        global PlayerUno
        string = nice.get()
        PlayerUno.playername = string
        tem = variable.get()
        print("TEM", tem)

        for i in orglist:
            if i.orgname == tem:
                PlayerUno.organization = i

        nice.destroy()
        ab.destroy()
        lb.destroy()
        button.destroy()
        w.destroy()
        print("PLAYER STATS:", PlayerUno.playername, PlayerUno.organization.orgname)
        initorg2020()
        # string = nice.get()




    button = Button(root, text="Submit", command=ok)
    button.grid(row=3, column=1)


'''
if __name__ == '__main__':

    root = tk.Tk()
    run = Passwordchecker(root)
    root.mainloop()
'''
