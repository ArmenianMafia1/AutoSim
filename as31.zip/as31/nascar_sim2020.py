#This is a game based off my first ever video game - NASCAR 06 for PS2
# I am a big NASCAR fan and I just learned coding classes in my CSE231 class so I thought this would be a fun project

import random
from random import randint

randomcar = ""
finish = 0


class Driver:
    def __init__(self, num = None, name = None, team = None, dvrmanu = None, age = 0, morale = 100, rating=0, pts=0, wins=0, topfives = 0, toptens=0, titles = list(), races=0, totalwins = 0, totaltopfives = 0, totaltoptens = 0, totalraces = 0, avgfinish=0, oldrides = list(), finishes = list(), moved = False, moveyear = 0, unsackable = False, t=0):

        self.num = num
        self.name = name
        self.team = team
        self.dvrmanu = dvrmanu
        self.rating = rating
        self.pts = pts
        self.age = age
        self.morale = morale
        self.wins = wins
        self.topfives = topfives
        self.toptens = toptens
        self.totalwins = totalwins
        self.totaltopfives = totaltopfives
        self.totaltoptens = totaltoptens
        self.titles = titles
        self.races = races
        self.totalraces = totalraces
        self.avgfinish = avgfinish
        self.finishes = finishes
        self.oldrides = oldrides
        self.moved = moved
        self.moveyear = moveyear
        self.unsackable = unsackable
        self.t = t

    def displaySmall(self):
        print("| Number: {} | Driver: {} |".format(self.num, self.name))
    pass

class Team:
    def __init__(self, num1="x", dvr = None, manu = None, sponsor = None, team1 = None, prestige = 0, active = True, parttime = False, deepparttime = False, yrsleft = 10):

        self.num1 = num1
        self.dvr = Driver()
        self.dvr.name = dvr.name
        self.dvr.age = dvr.age
        self.dvr.dvrmanu = dvr.dvrmanu
        self.dvr.morale = dvr.morale
        self.dvr.rating = dvr.rating
        self.dvr.pts = dvr.pts
        self.dvr.topfives = dvr.topfives
        self.dvr.toptens = dvr.toptens
        self.dvr.titles = dvr.titles
        self.dvr.races = dvr.races
        self.dvr.totalraces = dvr.totalraces
        self.dvr.avgfinish = dvr.avgfinish
        self.dvr.totalwins = dvr.totalwins
        self.dvr.totaltopfives = dvr.totaltopfives
        self.dvr.totaltoptens = dvr.totaltoptens
        self.manu = manu
        self.sponsor = sponsor
        self.team1 = team1
        self.prestige = prestige
        self.dvr.oldrides = dvr.oldrides
        self.active = active
        self.dvr.moved = dvr.moved
        self.dvr.moveyear = dvr.moveyear
        self.dvr.unsackable = dvr.unsackable
        self.parttime = parttime
        self.deepparttime = deepparttime
        self.dvr.t = dvr.t
        self.yrsleft = yrsleft


    def gui_displaySmall(self):
        return("| Number: {} | Driver: {} |".format(self.num1, self.dvr.name))
    def displaySmall(self):
        print("| Number: {} | Driver: {} |".format(self.num1, self.dvr.name))

    def displayMedium1(self):
        return("| Number: {} | Driver: {} | Manufacture: {} | Sponsor: {} | Team: {} |".format(self.num1,
                                                                                                  self.dvr.name,
                                                                                                  self.manu,
                                                                                                  self.sponsor,
                                                                                                  self.team1))

    def gui_displayMedium(self):
        return (
            "| Number: {} | Driver: {} | Manufacture: {} | Sponsor: {} | Team: {} |".format(self.num1, self.dvr.name,
                                                                                            self.manu, self.sponsor,
                                                                                            self.team1))

    def displayMedium(self):
        print("| Number: {} | Driver: {} | Manufacture: {} | Sponsor: {} | Team: {} |".format(self.num1, self.dvr.name, self.manu, self.sponsor, self.team1))

    def gui_displayMediumb(self):
        return("| Number: {} | Driver: {} | Manufacture: {} | Sponsor: {} | Team: {} |".format(self.num1, self.dvr.name, self.manu, self.sponsor, self.team1))
    pass


def namegenerator():
    first = ["Adam", "AJ", "Alex", "CJ", "Kenny", "Shane", "Cory", "Aaron", "Ara", "Austin", "Brad", "Braxton", "Brayden", "Bobby", "Brody", "Carl", "Carson", "Chris", "Christopher", "Caden", "Chaz", "Corey", "Chase", "Chance", "Cole", "Cody", "Carlos", "Wade", "Randy", "Pierce", "Dax", "Daxton", "Dustin", "Dallas", "Derrick", "Devin", "Damien", "George", "Gavin", "Jake", "Jaden", "Jeff", "John", "Johnny", "Luke", "Lucas", "Kai", "Kurt", "Kyle", "Kyler", "Ian", "Hunter", "Joey", "Levi", "Mark", "Milo", "Mo", "Mike", "Mitch", "Nate", "Nathan", "Oliver", "Rusty", "Patrick", "Pat", "Kelly", "Alex", "Joel", "TJ", "August", "Jay", "Seth", "Steve", "Scott", "Tony", "Timmy", "Timothy", "Zeke", "Elias", "Christian", "Christiano", "Mac", "Marty", "Travis", "Armando", "Diego", "Russell"]
    last = ["Ambrose", "Anderson", "Alexander", "Busch", "Busch Jr", "Brown", "Barrett", "Barrett Jr", "Bryan", "Ball", "Clanton", "Jericho", "Curry", "Carey", "Carter", "Cade", "Campell", "Dwyer", "Davidson", "Davis", "Davis Jr", "Lewis", "Larson", "Brooks", "Brooke", "Burke", "DiCaprio", "O'Neil", "McGregor", "Green", "Green Jr ", "Gold", "Garrett", "Hager", "Houston", "Harrison", "Hardy", "Harvey", "Fuller", "Fish", "Gordon", "Jarrett", "Jones", "Jones Jr", "Johnson", "Jackson", "Jackson Jr", "Jacobson", "Kane", "Knight", "King", "Lopez", "Lee", "Murray", "Morris", "Moore", "McCoy", "Miller", "Malone", "Nixon", "Dixon", "Malone Jr", "Michaels", "Martinez", "Nelson", "Reynolds", "Robinson", "Rockwell", "Preston", "Pfeiffer", "Rhodes",
            "Stevenson", "Smith", "Smith Jr", "Stark", "Smith Jr", "Stewart", "Tate", "Wang","Ryker", "Patterson", "Clover", "Gibson", "Heard", "Stokley", "Holt", "Rutger", "Wallace", "Wilson", "West", "French", "Shaw", "", "Rodgers", "Richardson", "Richards", "Graham", " ""Williams", "Wilson Jr", "Woods", "Zimmerman", "Collins", "Rogers", "Cook", "White", "Reed", "Bell", "Gomez", "Howard", "Hamilton", "Watts", "Ward", "Wood", "Garcia", "Jenkins"]
    f = random.choice(first)
    l = last.pop(random.randrange(len(last)))
    rtn = f + " " + l
    return rtn

QuinnHouff = Driver("02", "Quinn Hoff", age=26, rating=64)
KurtBusch = Driver(1, "Kurt Busch", age=41, rating=85, morale=50, t=1, totalwins=33, totaltopfives=144, totaltoptens=300, totalraces=688)
BradKeselowski = Driver(2, "Brad Keselowski", age=35, rating=92, morale=50, t=1, totalwins=30, totaltopfives=114, totaltoptens=188, totalraces=390)
AustinDillon = Driver(3, "Austin Dillon", age=30, rating=77, morale=100, totalwins=2, totaltopfives=12, totaltoptens=41, totalraces=233, unsackable=True)
KevinHarvick = Driver(4, "Kevin Harvick", age=44, rating=92, morale=70, t=1, totalwins=49, totaltopfives=208, totaltoptens=366, totalraces=686)
RyanNewman = Driver(6, "Ryan Newman", age=42, rating=83, morale=50, t=0, totalwins=18, totaltopfives=115, totaltoptens=262, totalraces=656)
TylerReddick = Driver(8, "Tyler Reddick", age=24, rating=79, morale=60, totalraces=2)
ChaseElliott = Driver(9, "Chase Elliott", age=25, rating=86, morale=50, totalwins=3, totaltopfives=16, totaltoptens=30, totalraces=72)
AricAlmirola = Driver(10, "Aric Almirola", age=36, rating=83, morale=50, totalwins=2, totaltopfives=18, totaltoptens=63, totalraces=316)
DennyHamlin = Driver(11, "Denny Hamlin", age=39, rating=88, morale=60, t=0, totalwins=37, totaltopfives=161, totaltoptens=260, totalraces=508)
RyanBlaney = Driver(12, "Ryan Blaney", age=26, rating=89, morale=60, t=0, totalwins=3, totaltopfives=27, totaltoptens=59, totalraces=164)
TyDillon = Driver(13, "Ty Dillon", age=28, rating=70, totaltopfives=1, totaltoptens=4, totalraces=130)
ClintBowyer = Driver(14, "Clint Bowyer", age=41, rating=81, totalwins=10, totaltopfives=81, totaltoptens=216, totalraces=509)
BrennanPoole = Driver(15, "Brennan Poole", age=29, rating=65, totalraces=0)
JustinHaley = Driver(16, "Justin Haley", age=21, rating=69, totalwins=1, totaltopfives=1, totaltoptens=1, totalraces=4)
ChrisBuescher = Driver(17, "Chris Buescher", age=27, rating=81, totalwins=1, totaltopfives=4, totaltoptens=12, totalraces=154)
KyleBusch = Driver(18, "Kyle Busch", age=34, rating=98, morale=70, t=2, totalwins=56, totaltopfives=202, totaltoptens=298, totalraces=534)
MartinTruexJr = Driver(19, "Martin Truex Jr", age=40, rating=93, morale=70, t=1, totalwins=26, totaltopfives=105, totaltoptens=202, totalraces=517)
ErikJones = Driver(20, "Erik Jones", age=24, rating=83, morale=65, totalwins=2, totaltopfives=24, totaltoptens=50, totalraces=115)
MattDiBenedetto = Driver(21, "Matt DiBenedetto", age=28, rating=80, morale=70, totaltopfives=4, totaltoptens=12, totalraces=180)
JoeyLogano = Driver(22, "Joey Logano", age=29, rating=90, morale=50, t=1 , totalwins=30, totaltopfives=100, totaltoptens=180,totalraces=300)
WilliamByron = Driver(24, "William Byron", age=22, rating=82, morale=50, totaltopfives=4, totaltoptens=17, totalraces=74)
CaseyMears = Driver(27, "Casey Mears", age=41, rating=64, totalwins=1, totaltopfives=13, totaltoptens=51, totalraces=400)
CoreyLaJoie = Driver(32, "Corey LaJoie", age=28, rating=76, morale=50, totaltoptens=3, totalraces=93)
MichaelMcDowell = Driver(34, "Michael McDowell", age=35, rating=76, morale=50, totaltopfives=3, totaltoptens=8, totalraces=325)
DavidRagan = Driver(36, "David Ragan", age=50, rating=73, morale=50, totalwins=2, totaltopfives=16, totaltoptens=33, totalraces=470)
RyanPreece = Driver(37, "Ryan Preece", age=29, rating=74, totaltopfives=4, totaltoptens=3, totalraces=40)
JohnHunterNemechek = Driver(38, "John Hunter Nemechek", age=22, rating=73)
ColeCuster = Driver(41, "Cole Custer", age=22, rating=74, totalraces=3)
KyleLarson = Driver(42, "Kyle Larson", age=27, rating=87, totalwins=6, totaltopfives=56, totaltoptens=101, totalraces=233)
BubbaWallace = Driver(43, "Bubba Wallace", age=26, rating=81, morale=70, t=0, totaltopfives=2, totaltoptens=4, totalraces=76)
RickyStenhouseJr = Driver(47, "Ricky Stenhouse Jr", age=32, totalwins=2, totaltopfives=16, totaltoptens=32, totalraces=260, rating=79)
JimmieJohnson = Driver(48, "Jimmie Johnson", age=44, rating=84, morale=100, t=7, totalwins=83, totaltopfives=228, totaltoptens=334, totalraces=655)
ChadFinchum = Driver(49, "Chad Finchum", age=27, rating=64)
GarrettSmithley = Driver(51, "Garrett Smithley", age=28, totalraces=20, rating=65)
JJYeley = Driver(52, "JJ Yeley", age=43, totaltopfives=2, totaltoptens=8, rating=67, totalraces=294)
CodyWare = Driver(53, "Cody Ware", age=23, totalraces=30, rating=61, unsackable=True)
TimmyHill = Driver(66, "Timmy Hill", age=27, totalraces=60, rating=70)
ReedSorenson = Driver(77, "Reed Sorenson", age=34, rating=69, morale=50, totaltopfives=5, totaltoptens=15, totalraces=333)
AlexBowman = Driver(88, "Alex Bowman", age=27, rating=87, morale=60, totalwins=1, totaltopfives=10, totaltoptens=25, totalraces=157)
ChristopherBell = Driver(95, "Christopher Bell", age=23, rating=79)
DanielSuarez = Driver(96, "Daniel Suarez", age=28, totaltopfives=8, totaltoptens=32, totalraces=108, rating=79)


Temp = Driver(9999, "N/A", rating=-100)

Temp2 = Driver(9999, "N/A", rating=-100)

Driver0 = Team("0", Temp, prestige=70, active=False)
Driver00 = Team("00", QuinnHouff, "Chevy", "Ashurst", "StarCom Racing", prestige=67, yrsleft=1)
Driver01 = Team("01", Temp, prestige=70, active=False)
Driver02 = Team("02", Temp, prestige=70, active=False)
Driver09 = Team("09", Temp, "Ford", prestige=70, active=False)
Driver1 = Team(1, KurtBusch, "Chevy", "Monster Energy", "Chip Ganassi Racing", prestige=84, yrsleft=1)
Driver2 = Team(2, BradKeselowski, "Ford", "Discount Tire", "Team Penske", prestige=89, yrsleft=1)
Driver3 = Team(3, AustinDillon, "Chevy", "Bass Pro Shops", "Richard Childress Racing", prestige=78)
Driver4 = Team(4, KevinHarvick, "Ford", "Busch", "Stewart-Haas Racing", prestige=95, yrsleft=2)
Driver5 = Team(5, Temp, prestige=75, active=False)
Driver6 = Team(6, RyanNewman, "Ford", "Koch Industries", "Roush Racing", prestige=78, yrsleft=2)
Driver7 = Team(7, Temp, "Ford", prestige=75, active=False)
Driver8 = Team(8, TylerReddick, "Chevy", "Caterpillar", "Richard Childress Racing", prestige=78)
Driver9 = Team(9, ChaseElliott, "Chevy", "NAPA", "Hendrick Motorsports", prestige=92, yrsleft=5)
Driver10 = Team(10, AricAlmirola, "Ford", "Smithfield", "Stewart Haas Racing", prestige=83)
Driver11 = Team(11, DennyHamlin, "Toyota", "FedEx", "Joe Gibbs Racing", prestige=90, yrsleft=3)
Driver12 = Team(12, RyanBlaney, "Ford", "Menard's", "Team Penske", prestige=88, yrsleft=4)
Driver13 = Team(13, TyDillon, "Chevy", "GEICO", "Germain Racing", prestige=74)
Driver14 = Team(14, ClintBowyer, "Ford", "Rush Truck Centers", "Stewart-Haas Racing", prestige=83, yrsleft=1)
Driver15 = Team(15, BrennanPoole, "Chevy", "Unsponsored", "Premium Motorsports", prestige=58)
Driver16 = Team(16, JustinHaley, "Chevy", "FOE", "Kaulig Motorsports", prestige=63, parttime=True)
Driver17 = Team(17, ChrisBuescher, "Ford", "Fastenal", "Roush Racing", prestige=79)
Driver18 = Team(18, KyleBusch, "Toyota", "M&M's", "Joe Gibbs Racing", prestige=96)
Driver19 = Team(19, MartinTruexJr, "Toyota", "Bass Pro Shops", "Joe Gibbs Racing", prestige=89)
Driver20 = Team(20, ErikJones, "Toyota", "DeWalt Tools", "Joe Gibbs Racing", prestige=85, yrsleft=3)
Driver21 = Team(21, MattDiBenedetto, "Ford", "Quicklane", "Wood Brothers Racing", prestige=76)
Driver22 = Team(22, JoeyLogano, "Ford", "Pennzoil", "Team Penske", prestige=88, yrsleft=3)
Driver23 = Team(23, Temp, prestige=70, active=False)
Driver24 = Team(24, WilliamByron, "Chevy", "Alaxta", "Hendrick Motorsports", prestige=85, yrsleft=4)
Driver25 = Team(25, Temp, prestige=75, active=False)
Driver26 = Team(26, Temp, prestige=70, active=False)
Driver27 = Team(27, CaseyMears, "Chevy", "Unsponsored", "Premium Motorsports", prestige=55)
Driver30 = Team(30, Temp, "Chevy", prestige=70, active=False)
Driver31 = Team(31, Temp, "Chevy", prestige=75, active=False)
Driver32 = Team(32, CoreyLaJoie, "Ford", "Raging Bull", "Go FAS Racing", prestige=74, yrsleft=1)
Driver33 = Team(33, Temp, "Chevy", prestige=75, active=False)
Driver34 = Team(34, MichaelMcDowell, "Ford", "Love's", "Front Row Motorsports", prestige=75)
Driver36 = Team(36, DavidRagan, "Ford", "Select Blinders", "Rick Ware Racing w/ Front Row Motorsports", deepparttime=True)
Driver37 = Team(37, RyanPreece, "Chevy", "Natty Light Seltzer", "JTG-Daughtery Racing", prestige=75, yrsleft=1)
Driver38 = Team(38, JohnHunterNemechek, "Ford", "1000Bulbs Lighting", "Front Row Motorsports", prestige=75, yrsleft=2)
Driver40 = Team(40, Temp, "Chevy", "CreditOne Bank", "Chip Ganassi Racing", prestige=80)
Driver41 = Team(41, ColeCuster, "Ford", "Haas", "Stewart-Haas Racing", prestige=79)
Driver42 = Team(42, KyleLarson, "Chevy", "McDonalds", "Chip Ganassi Racing", prestige=85, yrsleft=1)
Driver43 = Team(43, BubbaWallace, "Chevy", "US Air Force", "Petty Enterprises", prestige=76, yrsleft=1)
Driver44 = Team(44, Temp, "Chevy", None, "Petty Enterprises", prestige=72)
Driver45 = Team(45, Temp, "Chevy", prestige=70, active=False)
Driver46 = Team(46, Temp, "Chevy", "Alaxta", "Jeff Gordon Inc", prestige=75,active=False)
Driver47 = Team(47, RickyStenhouseJr, "Chevy", "Kroger", "JTG-Daughtery Racing", prestige=78, yrsleft=3)
Driver48 = Team(48, JimmieJohnson, "Chevy", "Ally Financial", "Hendrick Motorsports", prestige=85,yrsleft=1)
Driver49 = Team(49, ChadFinchum, "Chevy", "Garrison Homes", "Carl Long Motorsports", prestige=55, deepparttime=True)
Driver51 = Team(51, GarrettSmithley, "Chevy", "Jacob Companies", "Rick Ware Racing", prestige=60, yrsleft=1)
Driver52 = Team(52, JJYeley, "Chevy", "Window World", "Rick Ware Racing", prestige=62, yrsleft=1)
Driver53 = Team(53, CodyWare, "Chevy", "Unsponsored", "Rick Ware Racing", prestige=57)
Driver54 = Team(54, Temp, "Chevy", "Unsponsored", "Rick Ware Racing", prestige=59, active=False)
Driver57 = Team(57, Temp, "Chevy", "Unsponsored", "Rick Ware Racing", prestige=64, active=False)
Driver59 = Team(59, Temp, "Toyota", prestige=70, active=False)
Driver60 = Team(60, Temp, "Ford", prestige=60, active=False)
Driver66 = Team(66, TimmyHill, "Chevy", "RoofClaim.com", "Carl Long Motorsports", prestige=59, parttime=True, yrsleft=1)
Driver69 = Team(69, Temp, "Chevy", prestige=70, active=False)
Driver70 = Team(70, Temp, "Chevy", prestige=70, active=False)
Driver72 = Team(72, Temp, "Chevy", prestige=70, active=False)
Driver77 = Team(77, ReedSorenson, "Chevy", "Go Parts", "Spire Motorsports", prestige=65, yrsleft=1)
Driver78 = Team(78, Temp, "Chevy", prestige=70, active=False)
Driver79 = Team(79, Temp, "Chevy", prestige=70, active=False)
Driver80 = Team(80, Temp, "Chevy", prestige=70, active=False)
Driver81 = Team(80, Temp, "Chevy", prestige=70, active=False)
Driver83 = Team(83, Temp, "Chevy", prestige=70, active=False)
Driver84 = Team(84, Temp, "Chevy", prestige=70, active=False)
Driver88 = Team(88, AlexBowman, "Chevy", "Cincinatti Inc", "Hendrick Motorsports", prestige=84, yrsleft=1)
Driver91 = Team(91, Temp, "Chevy", "HendrickCars.com", "Evernham Motorsports", prestige=75, active=False)
Driver93 = Team(93, Temp, "Chevy", prestige=70, active=False)
Driver94 = Team(94, Temp, "Chevy", prestige=70, active=False)
Driver95 = Team(95, ChristopherBell, "Toyota", "Procore", "Levine Family Racing", prestige=76)
Driver96 = Team(96, DanielSuarez, "Toyota", "Aris", "Guant Brothers Racing", prestige=69)
Driver97 = Team(97, Temp, "Chevy", prestige=70, active=False)
Driver98 = Team(98, Temp, "Ford", "Champion Tools", "Thorsport Racing", prestige=73, active=False)
Driver99 = Team(99, Temp, "Chevy", "Clean Orgin", "StarCom Racing", prestige=75, active=False)

ChaseBriscoe = Driver(100, "Chase Briscoe", age=25, rating=68)
ChristianEckes = Driver(100, "Christian Eckes", age=19, rating=67)
HailieDeegan = Driver(100, "Hailie Deegan", age=19, rating=63)
RileyHerbst= Driver(100, "Riley Herbst", age=21, rating=64)
ThadMoffit= Driver(100, "Thad Moffit", age=19, rating=58)
TannerGray= Driver(100, "Tanner Gray", age=21, rating=60)
ZaneSmith= Driver(100, "Zane Smith", age=20, rating=62)
ToddGilliland= Driver(100, "Todd Gilliland", age=19, rating=58)
DerekKraus= Driver(100, "Derek Kraus", age=18, rating=65)
TylerAnkrum = Driver(100, "Tyler Ankrum", age=19, rating=63)
RaphaelLessard = Driver(100, "Raphael Lessard", age=18, rating=60)
BenRhodes = Driver(100, "Ben Rhodes", age=23, rating=55)
NoahGragson = Driver(100, "Noah Gragson", age=21, rating=61)
HarrisonBurton = Driver(100, "Harrison Burton", age=19, rating=62)
AustinCindric = Driver(100, "Austin Cindric", age=21, rating=60)
RyanSieg = Driver(100, "Ryan Sieg", age=32, rating=59)
JustinHaley = Driver(100, "Justin Haley", age=21, rating=60)
ChandlerSmith = Driver(100, "Chandler Smith", age=17, rating=69)
TyGibbs= Driver(100, "Ty Gibbs", age=17, rating=60)
SamMayer = Driver(100, "Sam Mayer", age=16, rating=64)
RayBlackJr = Driver(100, "Ray Black Jr", age=28, rating=53)
TimmyHill = Driver(100, "Timmy Hill", age=27, rating=56)
AlexLabbe = Driver(100, "Alex Labbe", age=27, rating=56)
BrandonJones = Driver(100, "Brandon Jones", age=23, rating=62)
MyattSnider = Driver(100, "Myatt Snider", age=25, rating=60)
MaxMcLaughlin = Driver(100, "Max McLaughlin", age=20, rating=60)
JoeGrafJr = Driver(100, "Joe Graf Jr", age=21, rating=55)
GrayGaulding = Driver(100, "Gray Gaulding", age=22, rating=60)
AustinHill = Driver(100, "Austin Hill", age=26, rating=58)
JordanAnderson = Driver(100, "Jordan Anderson", age=29, rating=58)
GrantEnfinger = Driver(100, "Grant Enfinger", age=35, rating=63)
NatalieDecker = Driver(100, "Natalie Decker", age=22, rating=55)
SpencerBoyd = Driver(100, "Spencer Boyd", age=24, rating=58)
TyMajeski = Driver(100, "Ty Majeski", age=25, rating=64)
MichaelSelf = Driver(100, "Michael Self", age=29, rating=63)
TimRichmond = Driver(100, "Tim Richmond", age=22, rating=56)
ChaseCabre = Driver(100, "Chase Cabre", age=23, rating=58)
DanielHemric = Driver(100, "Daniel Hemric", age=29, rating=75)
JustinAllgaier = Driver(100, "Justin Allgaier", age=33, rating=75)
AJAllmendinger = Driver(100, "AJ Allmendinger", age=35, rating=76)
MattKenseth = Driver(100, "Matt Kenseth", age=42, rating=90)

Custom1 = Driver(900, namegenerator(), age=10, rating=23, morale=50)
Custom2 = Driver(901, namegenerator(), age=13, rating=31, morale=50)
Custom3 = Driver(902, namegenerator(), age=14, rating=35, morale=50)
Custom4 = Driver(900, namegenerator(), age=13, rating=34, morale=50)
Custom5 = Driver(901, namegenerator(), age=9, rating=24, morale=50)
Custom6 = Driver(900, namegenerator(), age=7, rating=16, morale=50)
Custom7 = Driver(901, namegenerator(), age=7, rating=16, morale=50)
Custom8 = Driver(902, namegenerator(), age=10, rating=16, morale=50)
Custom9 = Driver(902, namegenerator(), age=13, rating=11, morale=50)
Custom10 = Driver(902, namegenerator(), age=-15, rating=-15, morale=50)
Custom11 = Driver(902, namegenerator(), age=-17, rating=-17, morale=50)
Custom12 = Driver(902, namegenerator(), age=16, rating=39, morale=50)
Custom13 = Driver(900, namegenerator(), age=3, rating=3, morale=50)
Custom14 = Driver(901, namegenerator(), age=-1, rating=1, morale=50)
Custom15 = Driver(902, namegenerator(), age=-2, rating=-1, morale=50)
Custom16 = Driver(900, namegenerator(), age=-4, rating=-4, morale=50)
Custom17 = Driver(901, namegenerator(), age=-4, rating=-4, morale=50)
Custom18 = Driver(900, namegenerator(), age=-7, rating=-6, morale=50)
Custom19 = Driver(901, namegenerator(), age=-9, rating=-6, morale=50)
Custom20 = Driver(902, namegenerator(), age=-11, rating=-6, morale=50)
Custom21 = Driver(902, namegenerator(), age=-12, rating=-11, morale=50)
Custom22 = Driver(902, namegenerator(), age=-13, rating=-15, morale=50)
Custom23 = Driver(902, namegenerator(), age=-15, rating=-17, morale=50)
Custom24 = Driver(902, namegenerator(), age=-20, rating=-19, morale=50)
Custom25 = Driver(902, namegenerator(), age=-11, rating=-6, morale=50)
Custom26 = Driver(902, namegenerator(), age=7, rating=-8, morale=50)
Custom27 = Driver(902, namegenerator(), age=6, rating=-13, morale=50)
Custom28 = Driver(901, namegenerator(), age=0, rating=14, morale=50)
Custom29 = Driver(900, namegenerator(), age=-7, rating=-6, morale=50)
Custom30 = Driver(900, namegenerator(), age=-6, rating=0, morale=50)
Custom31 = Driver(901, namegenerator(), age=-7, rating=-6, morale=50)
Custom32 = Driver(902, namegenerator(), age=10, rating=-6, morale=50)
Custom33 = Driver(902, namegenerator(), age=13, rating=-11, morale=50)
Custom33 = Driver(902, namegenerator(), age=-15, rating=-15, morale=50)
Custom34 = Driver(902, namegenerator(), age=-11, rating=-13, morale=50)
Custom35 = Driver(901, namegenerator(), age=14, rating=34, morale=50)
Custom36 = Driver(900, namegenerator(), age=7, rating=16, morale=50)
Custom37 = Driver(901, namegenerator(), age=11, rating=26, morale=50)
Custom38 = Driver(902, namegenerator(), age=-10, rating=-6, morale=50)
Custom39 = Driver(902, namegenerator(), age=-13, rating=-11, morale=50)
Custom40 = Driver(902, namegenerator(), age=-22, rating=-18, morale=50)
Custom46 = Driver(902, "Remi T Bucksworth V", age=2, rating=-18, morale=50)


FreeAgentC1 = Team(900, Custom1)
FreeAgentC2 = Team(901, Custom2)
FreeAgentC3 = Team(902, Custom3)
FreeAgentC4 = Team(903, Custom4)
FreeAgentC5 = Team(904, Custom5)
FreeAgentC6 = Team(905, Custom6)
FreeAgentC7 = Team(903, Custom7)
FreeAgentC8 = Team(904, Custom8)
FreeAgentC9 = Team(905, Custom9)
FreeAgentC10 = Team(905, Custom10)
FreeAgentC11 = Team(905, Custom11)
FreeAgentC12 = Team(905, Custom12)
FreeAgentC13 = Team(900, Custom13)
FreeAgentC14 = Team(901, Custom14)
FreeAgentC15 = Team(902, Custom15)
FreeAgentC16 = Team(903, Custom16)
FreeAgentC17 = Team(904, Custom17)
FreeAgentC18 = Team(905, Custom18)
FreeAgentC19 = Team(903, Custom19)
FreeAgentC20 = Team(904, Custom20)
FreeAgentC21 = Team(905, Custom21)
FreeAgentC22 = Team(905, Custom22)
FreeAgentC23 = Team(905, Custom23)
FreeAgentC24 = Team(905, Custom24)
FreeAgentC25 = Team(905, Custom25)
FreeAgentC26 = Team(905, Custom26)
FreeAgentC27 = Team(905, Custom27)
FreeAgentC28 = Team(905, Custom28)
FreeAgentC29 = Team(905, Custom29)
FreeAgentC30 = Team(905, Custom30)
FreeAgentC31 = Team(905, Custom31)
FreeAgentC32 = Team(905, Custom32)
FreeAgentC33 = Team(905, Custom33)
FreeAgentC34 = Team(905, Custom34)
FreeAgentC35 = Team(905, Custom35)
FreeAgentC36 = Team(905, Custom36)
FreeAgentC37 = Team(905, Custom37)
FreeAgentC38 = Team(905, Custom38)
FreeAgentC39 = Team(905, Custom39)
FreeAgentC40 = Team(905, Custom40)

FreeAgent0 = Team(100, ChristianEckes)
FreeAgent1 = Team(101, HailieDeegan)
FreeAgent2 = Team(102, ChaseBriscoe)
FreeAgent3 = Team(103, RileyHerbst)
FreeAgent4 = Team(104, TannerGray)
FreeAgent5 = Team(105, MattKenseth)
FreeAgent6 = Team(106, ZaneSmith)
FreeAgent7 = Team(107, ThadMoffit)
FreeAgent8 = Team(108, ToddGilliland)
FreeAgent9 = Team(109, DerekKraus)
FreeAgent10 = Team(110, RaphaelLessard)
FreeAgent11 = Team(111, BenRhodes)
FreeAgent12 = Team(109, NoahGragson)
FreeAgent13 = Team(110, HarrisonBurton)
FreeAgent14 = Team(111, AustinCindric)
FreeAgent15 = Team(110, RyanSieg)
FreeAgent16 = Team(111, TyGibbs)
FreeAgent17 = Team(109, ChandlerSmith)
FreeAgent18 = Team(110, SamMayer)
FreeAgent19 = Team(111, RayBlackJr)
FreeAgent20 = Team(112, AlexLabbe)
FreeAgent21 = Team(113, BrandonJones)
FreeAgent22 = Team(114, MyattSnider)
FreeAgent23 = Team(114, MaxMcLaughlin)
FreeAgent24 = Team(124, JoeGrafJr)
FreeAgent25 = Team(124, GrayGaulding)
FreeAgent26 = Team(124, AustinHill)
FreeAgent27 = Team(124, JordanAnderson)
FreeAgent28 = Team(124, NatalieDecker)
FreeAgent29 = Team(124, GrantEnfinger)
FreeAgent30 = Team(124, SpencerBoyd)
FreeAgent31 = Team(124, TyMajeski)
FreeAgent32 = Team(124, TimRichmond)
FreeAgent33 = Team(124, ChaseCabre)
FreeAgent34 = Team(124, DanielHemric)
FreeAgent35 = Team(124, JustinAllgaier)
FreeAgent36 = Team(124, AJAllmendinger)

'''
FreeAgent34, FreeAgent35, FreeAgent36, FreeAgent37, FreeAgent38, FreeAgent39,
                 FreeAgent40,
                 FreeAgent41, FreeAgent42, FreeAgent43, FreeAgent44, FreeAgent45, FreeAgent47, FreeAgent48,
                 FreeAgent49, FreeAgent50, FreeAgent51, FreeAgent52, FreeAgent53, FreeAgent54, FreeAgent55,
                 FreeAgent56, FreeAgent57, FreeAgent58, FreeAgent59, FreeAgent60, FreeAgent61, FreeAgent62,
                 FreeAgent63,
                 FreeAgent64, FreeAgent65, FreeAgent66, FreeAgent67,

'''
freeagentlist = [FreeAgent0, FreeAgent1, FreeAgent2, FreeAgent3, FreeAgent4, FreeAgent5, FreeAgent6, FreeAgent7,
                 FreeAgent8,
                 FreeAgent9, FreeAgent10, FreeAgent11, FreeAgent12, FreeAgent13, FreeAgent14, FreeAgent15,
                 FreeAgent16,
                 FreeAgent17, FreeAgent18, FreeAgent19, FreeAgent20, FreeAgent21, FreeAgent22, FreeAgent23,
                 FreeAgent24,
                 FreeAgent25, FreeAgent26, FreeAgent27, FreeAgent28, FreeAgent29, FreeAgent30, FreeAgent31,
                 FreeAgent32, FreeAgent34, FreeAgent35, FreeAgent36,
                 FreeAgent33, FreeAgentC1, FreeAgentC2,
                 FreeAgentC3,
                 FreeAgentC4, FreeAgentC5, FreeAgentC6, FreeAgentC7, FreeAgentC8, FreeAgentC9, FreeAgentC10,
                 FreeAgentC11,
                 FreeAgentC12, FreeAgentC13, FreeAgentC14, FreeAgentC15, FreeAgentC16, FreeAgentC17, FreeAgentC18,
                 FreeAgentC19,
                 FreeAgentC20, FreeAgentC21, FreeAgentC22, FreeAgentC23, FreeAgentC24, FreeAgentC25, FreeAgentC26,
                 FreeAgentC27,
                 FreeAgentC28, FreeAgentC29, FreeAgentC30, FreeAgentC31, FreeAgentC32, FreeAgentC33, FreeAgentC34,
                 FreeAgentC35, FreeAgentC36, FreeAgentC37, FreeAgentC38, FreeAgentC39, FreeAgentC40]

global freelist
freelist = []

for fa in freeagentlist:
    fa.dvr.rating -= 5
    print(fa.dvr.name, "jr1")
    freelist.append(fa.dvr)
print(freelist)

mylist = {"00", "1", "2", "3", "4", "6", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
          "22", "24", "27",
          "32", "34", "36", "37", "38", "41", "42", "43", "48", "49", "51", "52", "53", "66", "77", "88", "95", "96"}


class Org:
    def __init__(self, orgname="", orgmanu = "", orgteams = [], money=0, orgtitles=0, orgprestige=0, control=None, puppet=""):

        self.orgname = orgname
        self.orgmanu = orgmanu
        self.orgteams = orgteams
        self.orgtitles = orgtitles
        self.orgprestige = orgprestige
        self.money = money
        self.control = control
        self.puppet = puppet

    def displayMedium1(self):
        return ("| Organization: {} | Manufacture: {} | Prestige: {} | Championships: {} |".format(self.orgname,
                                                                                                self.orgmanu,
                                                                                                self.orgprestige,
                                                                                                self.orgtitles))


class Player:
    def __init__(self, playername="", organization = None):
        self.playername = playername
        self.organization = organization

LeavineFamilyRacing = Org(orgname = "Leavine Family Racing", orgmanu = "Toyota", money = 170000, orgtitles=0, orgprestige=79, orgteams=[Driver95], puppet = "Joe Gibbs Racing")
JoeGibbsRacing = Org(orgname = "Joe Gibbs Racing", orgmanu = "Toyota", money = 200000, orgtitles=5, orgprestige=97, orgteams=[Driver11, Driver18, Driver19, Driver20])
WoodBrothersRacing = Org(orgname = "Wood Brothers Racing", orgmanu = "Ford", money=80000, orgtitles=8, orgprestige=81, orgteams=[Driver21], puppet="Team Penske")
TeamPenske = Org(orgname = "Team Penske", orgmanu = "Ford", money = 180000, orgtitles=2, orgprestige=93, orgteams=[Driver2, Driver12, Driver22], control=WoodBrothersRacing)
HendrickMotorsports = Org(orgname = "Hendrick Motorsports", orgmanu = "Chevy", money = 150000, orgprestige=88, orgteams=[Driver9, Driver24, Driver48, Driver88])
SpireMotorsports = Org(orgname = "Spire Motorsports", orgmanu = "Chevy", money = 22000, orgtitles=0, orgprestige=62, orgteams=[Driver77], puppet="Chip Ganassi Racing")
StewartHaasRacing = Org(orgname = "Stewart-Haas Racing", orgmanu = "Ford", money = 180000, orgtitles=2, orgprestige=95, orgteams=[Driver4, Driver10, Driver14, Driver41])
ChipGanassiRacing = Org(orgname = "Chip Ganassi Racing", orgmanu = "Chevy", money = 100000, orgprestige=88, orgteams=[Driver1, Driver42])
RoushRacing = Org(orgname = "Roush Racing", orgmanu = "Ford", money=90000, orgprestige=83, orgteams = [Driver6, Driver17] )
JTG = Org(orgname = "JTG-Daughtery Racing", orgmanu = "Chevy", money = 80000, orgprestige=81, orgteams = [Driver37, Driver47], puppet = "Richard Childress Racing")
PettyEnterprises = Org(orgname = "Richard Petty Motorsports", orgmanu = "Chevy", money = 90000, orgtitles=7, orgprestige=74, orgteams=[Driver43])
RichardChildressRacing = Org(orgname = "Richard Childress Racing", money = 140000, orgtitles=7, orgprestige=78, orgteams=[Driver3,Driver8])
RickWareRacing = Org(orgname = "Rick Ware Racing", orgmanu = "Chevy", money = 15000, orgtitles=0, orgprestige=64, orgteams=[Driver51, Driver52, Driver53])
FrontRowMotorsports =  Org(orgname = "Front Row Motorsports", orgmanu = "Ford", money = 35000, orgtitles=0, orgprestige=73, orgteams=[Driver34, Driver38])
GoFASRacing =  Org(orgname = "GoFAS Racing", orgmanu = "Ford", money = 32000, orgtitles=0, orgprestige=70, orgteams=[Driver32])
PremiumMotorsports = Org(orgname = "Premium Motorsports", orgmanu = "Chevy", money = 15000, orgtitles=0, orgprestige=61, orgteams=[Driver15, Driver27])
GuantBrosRacing = Org(orgname = "Guant Brothers Racing", orgmanu = "Toyota", money = 17000, orgtitles=0, orgprestige=62, orgteams=[Driver96])
StarComRacing = Org(orgname = "StarCom Racing", orgmanu = "Chevy", money = 17000, orgtitles=0, orgprestige=65, orgteams=[Driver00])
GermainRacing = Org(orgname = "Germain Racing", orgmanu = "Chevy", money = 45000, orgtitles=0, orgprestige=69, orgteams=[Driver13])
MBMMotorsports = Org(orgname = "MBM Motorsports", orgmanu = "Toyota", money=10000, orgtitles=0, orgprestige=61, orgteams=[Driver49, Driver66])


global PlayerUno
PlayerUno = Player()


orglist = [ChipGanassiRacing, FrontRowMotorsports, GuantBrosRacing, GermainRacing, GoFASRacing, HendrickMotorsports, JoeGibbsRacing, JTG, MBMMotorsports, PremiumMotorsports, RichardChildressRacing, PettyEnterprises, RickWareRacing, RoushRacing, SpireMotorsports, StarComRacing, StewartHaasRacing, TeamPenske, WoodBrothersRacing]
orglist_names = []
for i in orglist:
    orglist_names.append(i.orgname)

#randomcar = random.sample(mylist,1)

def order(finish, randomcar):
    if randomcar == "0":
        Driver0.displayMedium()
    elif randomcar == "00":
        Driver00.displayMedium()
    elif randomcar == "01":
        Driver01.displayMedium()
    elif randomcar == "07":
        Driver07.displayMedium()
    elif randomcar == "08":
        Driver08.displayMedium()
    elif randomcar == "09":
        Driver09.displayMedium()
    elif randomcar == "1":
        Driver1.displayMedium()
    elif randomcar == "2":
        Driver2.displayMedium()
    elif randomcar == "4":
        Driver4.displayMedium()
    elif randomcar == "5":
        Driver5.displayMedium()
    elif randomcar == "6":
        Driver6.displayMedium()
    elif randomcar == "7":
        Driver7.displayMedium()
    elif randomcar == "8":
        Driver8.displayMedium()
    elif randomcar == "9":
        Driver9.displayMedium()
    elif randomcar == "10":
        Driver10.displayMedium()
    elif randomcar == "11":
        Driver11.displayMedium()
    elif randomcar == "12":
        Driver12.displayMedium()
    elif randomcar == "13":
        Driver13.displayMedium()
    elif randomcar == "14":
        Driver14.displayMedium()
    elif randomcar == "15":
        Driver15.displayMedium()
    elif randomcar == "16":
        Driver16.displayMedium()
    elif randomcar == "17":
        Driver17.displayMedium()
    elif randomcar == "18":
        Driver18.displayMedium()
    elif randomcar == "19":
        Driver19.displayMedium()
    elif randomcar == "20":
        Driver20.displayMedium()
    elif randomcar == "21":
        Driver21.displayMedium()
    elif randomcar == "22":
        Driver22.displayMedium()
    elif randomcar == "24":
        Driver24.displayMedium()
    elif randomcar == "25":
        Driver25.displayMedium()
    elif randomcar == "26":
        Driver26.displayMedium()
    elif randomcar == "27":
        Driver27.displayMedium()
    elif randomcar == "29":
        Driver29.displayMedium()
    elif randomcar == "31":
        Driver31.displayMedium()
    elif randomcar == "32":
        Driver32.displayMedium()
    elif randomcar == "36":
        Driver36.displayMedium()
    elif randomcar == "37":
        Driver37.displayMedium()
    elif randomcar == "38":
        Driver38.displayMedium()
    elif randomcar == "39":
        Driver39.displayMedium()
    elif randomcar == "40":
        Driver40.displayMedium()
    elif randomcar == "41":
        Driver41.displayMedium()
    elif randomcar == "42":
        Driver42.displayMedium()
    elif randomcar == "43":
        Driver43.displayMedium()
    elif randomcar == "44":
        Driver44.displayMedium()
    elif randomcar == "45":
        Driver45.displayMedium()
    elif randomcar == "46":
        Driver46.displayMedium()
    elif randomcar == "47":
        Driver47.displayMedium()
    elif randomcar == "48":
        Driver48.displayMedium()
    elif randomcar == "49":
        Driver49.displayMedium()
    elif randomcar == "50":
        Driver50.displayMedium()
    elif randomcar == "55":
        Driver55.displayMedium()
    elif randomcar == "66":
        Driver66.displayMedium()
    elif randomcar == "70":
        Driver70.displayMedium()
    elif randomcar == "72":
        Driver72.displayMedium()
    elif randomcar == "77":
        Driver77.displayMedium()
    elif randomcar == "78":
        Driver78.displayMedium()
    elif randomcar == "88":
        Driver88.displayMedium()
    elif randomcar == "89":
        Driver89.displayMedium()
    elif randomcar == "91":
        Driver91.displayMedium()

    elif randomcar == "97":
        Driver97.displayMedium()
    elif randomcar == "99":
        Driver99.displayMedium()
    else:
        pass


def assign(randomcar):
    if randomcar == "0":
        if Driver0.active:
            return Driver0
    elif randomcar == "00":
        if Driver00.active:
            return Driver00
    elif randomcar == "01":
        if Driver01.active:
            return Driver01
    elif randomcar == "02":
        if Driver02.active:
            return Driver02
    elif randomcar == "07":
        if Driver07.active:
            return Driver07
    elif randomcar == "08":
        if Driver08.active:
            return Driver08
    elif randomcar == "09":
        if Driver09.active:
            return Driver09
    elif randomcar == "1":
        if Driver1.active:
            return Driver1
    elif randomcar == "2":
        if Driver2.active:
            return Driver2
    elif randomcar == "3":
        if Driver3.active:
            return Driver3
    elif randomcar == "4":
        if Driver4.active:
            return Driver4
    elif randomcar == "5":
        if Driver5.active:
            return Driver5
    elif randomcar == "6":
        if Driver6.active:
            return Driver6
    elif randomcar == "7":
        if Driver7.active:
            return Driver7
    elif randomcar == "8":
        if Driver8.active:
            return Driver8
    elif randomcar == "9":
        if Driver9.active:
            return Driver9
    elif randomcar == "10":
        if Driver10.active:
            return Driver10
    elif randomcar == "11":
        if Driver11.active:
            return Driver11
    elif randomcar == "12":
        if Driver12.active:
            return Driver12
    elif randomcar == "13":
        if Driver13.active:
            return Driver13
    elif randomcar == "14":
        if Driver14.active:
            return Driver14
    elif randomcar == "15":
        if Driver15.active:
            return Driver15
    elif randomcar == "16":
        if Driver16.active:
            return Driver16
    elif randomcar == "17":
        if Driver17.active:
            return Driver17
    elif randomcar == "18":
        if Driver18.active:
            return Driver18
    elif randomcar == "19":
        if Driver19.active:
            return Driver19
    elif randomcar == "20":
        if Driver20.active:
            return Driver20
    elif randomcar == "21":
        if Driver21.active:
            return Driver21
    elif randomcar == "22":
        if Driver22.active:
            return Driver22
    elif randomcar == "23":
        if Driver23.active:
            return Driver23
    elif randomcar == "24":
        if Driver24.active:
            return Driver24
    elif randomcar == "25":
        if Driver25.active:
            return Driver25
    elif randomcar == "26":
        if Driver26.active:
            return Driver26
    elif randomcar == "27":
        if Driver27.active:
            return Driver27
    elif randomcar == "29":
        if Driver29.active:
            return Driver29
    elif randomcar == "30":
        if Driver30.active:
            return Driver30
    elif randomcar == "31":
        if Driver31.active:
            return Driver31
    elif randomcar == "32":
        if Driver32.active:
            return Driver32
    elif randomcar == "33":
        if Driver33.active:
            return Driver33
    elif randomcar == "34":
        if Driver34.active:
            return Driver34
    elif randomcar == "36":
        if Driver36.active:
            return Driver36
    elif randomcar == "37":
        if Driver37.active:
            return Driver37
    elif randomcar == "38":
        if Driver38.active:
            return Driver38
    elif randomcar == "39":
        if Driver39.active:
            return Driver39
    elif randomcar == "40":
        if Driver40.active:
            return Driver40
    elif randomcar == "41":
        if Driver41.active:
            return Driver41
    elif randomcar == "42":
        if Driver42.active:
            return Driver42
    elif randomcar == "43":
        if Driver43.active:
            return Driver43
    elif randomcar == "44":
        if Driver44.active:
            return Driver44
    elif randomcar == "45":
        if Driver45.active:
            return Driver45
    elif randomcar == "46":
        if Driver46.active:
            print("46464646")
            return Driver46
    elif randomcar == "47":
        if Driver47.active:
            return Driver47
    elif randomcar == "48":
        if Driver48.active:
            return Driver48
    elif randomcar == "49":
        if Driver49.active:
            return Driver49
    elif randomcar == "50":
        if Driver50.active:
            return Driver50
    elif randomcar == "51":
        if Driver51.active:
            return Driver51
    elif randomcar == "52":
        if Driver52.active:
            return Driver52
    elif randomcar == "53":
        if Driver53.active:
            return Driver53
    elif randomcar == "54":
        if Driver54.active:
            return Driver54
    elif randomcar == "55":
        if Driver55.active:
            return Driver55
    elif randomcar == "57":
        if Driver57.active:
            return Driver57
    elif randomcar == "59":
        if Driver59.active:
            return Driver59
    elif randomcar == "60":
        if Driver60.active:
            return Driver60
    elif randomcar == "66":
        if Driver66.active:
            return Driver66
    elif randomcar == "69":
        if Driver69.active:
            return Driver69
    elif randomcar == "70":
        if Driver70.active:
            return Driver70
    elif randomcar == "72":
        if Driver72.active:
            return Driver72
    elif randomcar == "77":
        if Driver77.active:
            return Driver77
    elif randomcar == "78":
        if Driver78.active:
            return Driver78
    elif randomcar == "79":
        if Driver79.active:
            return Driver79
    elif randomcar == "80":
        if Driver80.active:
            return Driver80
    elif randomcar == "81":
        if Driver81.active:
            return Driver81
    elif randomcar == "83":
        if Driver83.active:
            return Driver83
    elif randomcar == "84":
        if Driver84.active:
            return Driver84
    elif randomcar == "88":
        if Driver88.active:
            return Driver88
    elif randomcar == "89":
        if Driver89.active:
            return Driver89
        return False
    elif randomcar == "91":
        if Driver91.active:
            return Driver91
    elif randomcar == "93":
        if Driver93.active:
            return Driver93
    elif randomcar == "95":
        if Driver95.active:
            return Driver95
    elif randomcar == "94":
        if Driver94.active:
            return Driver94
    elif randomcar == "96":
        if Driver96.active:
            return Driver96
    elif randomcar == "97":
        if Driver97.active:
            return Driver97
    elif randomcar == "98":
        if Driver98.active:
            return Driver98
    elif randomcar == "99":
        if Driver99.active:
            return Driver99
    else:
        pass


def create(randomcar):
    if randomcar == "0":
        return Driver0
    elif randomcar == "00":
        return Driver00
    elif randomcar == "01":
        return Driver01
    elif randomcar == "02":
        return Driver02
    elif randomcar == "07":
        if Driver07.active:
            return Driver07
    elif randomcar == "08":
        return Driver08
    elif randomcar == "09":
        return Driver09
    elif randomcar == "1":
        if Driver1.active:
            return Driver1
    elif randomcar == "2":
        if Driver2.active:
            return Driver2
    elif randomcar == "3":
        if Driver3.active:
            return Driver3
    elif randomcar == "4":
        if Driver4.active:
            return Driver4
    elif randomcar == "5":
        return Driver5
    elif randomcar == "6":
        if Driver6.active:
            return Driver6
    elif randomcar == "7":
        return Driver7
    elif randomcar == "8":
        if Driver8.active:
            return Driver8
    elif randomcar == "9":
        if Driver9.active:
            return Driver9
    elif randomcar == "10":
        if Driver10.active:
            return Driver10
    elif randomcar == "11":
        if Driver11.active:
            return Driver11
    elif randomcar == "12":
        if Driver12.active:
            return Driver12
    elif randomcar == "13":
            return Driver13
    elif randomcar == "14":
        if Driver14.active:
            return Driver14
    elif randomcar == "15":
        if Driver15.active:
            return Driver15
    elif randomcar == "16":
        return Driver16
    elif randomcar == "17":
        if Driver17.active:
            return Driver17
    elif randomcar == "18":
        if Driver18.active:
            return Driver18
    elif randomcar == "19":
        if Driver19.active:
            return Driver19
    elif randomcar == "20":
        if Driver20.active:
            return Driver20
    elif randomcar == "21":
        if Driver21.active:
            return Driver21
    elif randomcar == "22":
        if Driver22.active:
            return Driver22
    elif randomcar == "23":
        return Driver23
    elif randomcar == "24":
        return Driver24
    elif randomcar == "25":
        return Driver25
    elif randomcar == "26":
        return Driver26
    elif randomcar == "27":
        return Driver27
    elif randomcar == "29":
        return Driver29
    elif randomcar == "30":
        return Driver30
    elif randomcar == "31":
        return Driver31
    elif randomcar == "32":
        if Driver32.active:
            return Driver32
    elif randomcar == "33":
        return Driver33
    elif randomcar == "34":
        if Driver34.active:
            return Driver34
    elif randomcar == "36":
        if Driver36.active:
            return Driver36
    elif randomcar == "37":
        if Driver37.active:
            return Driver37
    elif randomcar == "38":
        if Driver38.active:
            return Driver38
    elif randomcar == "39":
        return Driver39
    elif randomcar == "40":
        return Driver40
    elif randomcar == "41":
        return Driver41
    elif randomcar == "42":
        return Driver42
    elif randomcar == "43":
        return Driver43
    elif randomcar == "44":
        return Driver44
    elif randomcar == "45":
        return Driver45
    elif randomcar == "46":
        return Driver46
    elif randomcar == "47":
        return Driver47
    elif randomcar == "48":
        return Driver48
    elif randomcar == "49":
        return Driver49
    elif randomcar == "50":
        return Driver50
    elif randomcar == "51":
        return Driver51
    elif randomcar == "52":
        return Driver52
    elif randomcar == "53":
        return Driver53
    elif randomcar == "54":
        return Driver54
    elif randomcar == "55":
        return Driver55
    elif randomcar == "57":
        return Driver57
    elif randomcar == "59":
        return Driver59
    elif randomcar == "60":
        return Driver60
    elif randomcar == "66":
        if Driver66.active:
            return Driver66
    elif randomcar == "69":
        return Driver69
    elif randomcar == "70":
        return Driver70
    elif randomcar == "72":
        return Driver72
    elif randomcar == "77":
        return Driver77
    elif randomcar == "78":
        return Driver78
    elif randomcar == "79":
        return Driver79
    elif randomcar == "80":
        return Driver80
    elif randomcar == "81":
        return Driver81
    elif randomcar == "83":
        return Driver83
    elif randomcar == "84":
        return Driver84
    elif randomcar == "88":
        return Driver88
    elif randomcar == "89":
        return Driver89
    elif randomcar == "91":
        return Driver91
    elif randomcar == "93":
        return Driver93
    elif randomcar == "95":
        return Driver95
    elif randomcar == "94":
        return Driver94
    elif randomcar == "96":
        return Driver96
    elif randomcar == "97":
        return Driver97
    elif randomcar == "98":
        return Driver98
    elif randomcar == "99":
        return Driver99
    else:
        pass


def assign_inactive(randomcar):
    if randomcar == "0":
        if Driver0.active:
            return Driver0
    elif randomcar == "00":
        if Driver00.active:
            return Driver00
    elif randomcar == "01":
        if Driver0.active:
            return Driver01
    elif randomcar == "02":
        if Driver02.active:
            return Driver02
    elif randomcar == "07":
        if Driver07.active:
            return Driver07
    elif randomcar == "08":
        if Driver08.active:
            return Driver08
    elif randomcar == "09":
        if Driver09.active:
            return Driver09
    elif randomcar == "1":
        if Driver1.active:
            return Driver1
    elif randomcar == "2":
        if Driver2.active:
            return Driver2
    elif randomcar == "3":
        if Driver3.active:
            return Driver3
    elif randomcar == "4":
        if Driver4.active:
            return Driver4
    elif randomcar == "5":
        if Driver5.active:
            return Driver5
    elif randomcar == "6":
        if Driver6.active:
            return Driver6
    elif randomcar == "7":
        if Driver7.active:
            return Driver7
    elif randomcar == "8":
        if Driver8.active:
            return Driver8
    elif randomcar == "9":
        if Driver9.active:
            return Driver9
    elif randomcar == "10":
        if Driver10.active:
            return Driver10
    elif randomcar == "11":
        if Driver11.active:
            return Driver11
    elif randomcar == "12":
        if Driver12.active:
            return Driver12
    elif randomcar == "13":
        if Driver13.active:
            return Driver13
    elif randomcar == "14":
        if Driver14.active:
            return Driver14
    elif randomcar == "15":
        if Driver15.active:
            return Driver15
    elif randomcar == "16":
        if Driver16.active:
            return Driver16
    elif randomcar == "17":
        if Driver17.active:
            return Driver17
    elif randomcar == "18":
        if Driver18.active:
            return Driver18
    elif randomcar == "19":
        if Driver19.active:
            return Driver19
    elif randomcar == "20":
        if Driver20.active:
            return Driver20
    elif randomcar == "21":
        if Driver21.active:
            return Driver21
    elif randomcar == "22":
        if Driver22.active:
            return Driver22
    elif randomcar == "23":
        if Driver23.active:
            return Driver23
    elif randomcar == "24":
        if Driver24.active:
            return Driver24
    elif randomcar == "25":
        if Driver25.active:
            return Driver25
    elif randomcar == "26":
        if Driver26.active:
            return Driver26
    elif randomcar == "27":
        if Driver27.active:
            return Driver27
    elif randomcar == "29":
        if Driver29.active:
            return Driver29
    elif randomcar == "30":
        if Driver30.active:
            return Driver30
    elif randomcar == "31":
        if Driver31.active:
            return Driver31
    elif randomcar == "32":
        if Driver32.active:
            return Driver32
    elif randomcar == "33":
        if Driver33.active:
            return Driver33
    elif randomcar == "34":
        if Driver34:
            return Driver34
    elif randomcar == "36":
        if Driver36.active:
            return Driver36
    elif randomcar == "37":
        if Driver37.active:
            return Driver37
    elif randomcar == "38":
        if Driver38.active:
            return Driver38
    elif randomcar == "39":
        if Driver39.active:
            return Driver39
    elif randomcar == "40":
        if Driver40.active:
            return Driver40
    elif randomcar == "41":
        if Driver41.active:
            return Driver41
    elif randomcar == "42":
        if Driver42.active:
            return Driver42
    elif randomcar == "43":
        if Driver43.active:
            return Driver43
    elif randomcar == "44":
        if Driver44.active:
            return Driver44
    elif randomcar == "45":
        if Driver45.active:
            return Driver45
    elif randomcar == "46":
        if Driver46:
            return Driver46

    elif randomcar == "47":
        if Driver47:
            return Driver47

    elif randomcar == "48":
        if Driver48.active:
            return Driver48
    elif randomcar == "49":
        if Driver49:
            return Driver49
    elif randomcar == "50":
        if Driver50:
            return Driver50
    elif randomcar == "54":
        if Driver54:
            return Driver54
    elif randomcar == "55":
        if Driver55:
            return Driver55
    elif randomcar == "57":
        if Driver57:
            return Driver57
    elif randomcar == "59":
        if Driver59:
            return Driver59
    elif randomcar == "60":
        if Driver60:
            return Driver60
    elif randomcar == "66":
        if Driver66:
            return Driver66
    elif randomcar == "69":
        if Driver69:
            return Driver69
    elif randomcar == "70":
        if Driver70:
            return Driver70
    elif randomcar == "72":
        if Driver72:
            return Driver72
    elif randomcar == "77":
        if Driver77:
            return Driver77
    elif randomcar == "78":
        if Driver78:
            return Driver78
    elif randomcar == "79":
        if Driver79:
            return Driver79
    elif randomcar == "80":
        if Driver80:
            return Driver80

    elif randomcar == "81":
        if Driver81:
            return Driver81
    elif randomcar == "84":
        if Driver84:
            return Driver84
    elif randomcar == "88":
        if Driver88:
            return Driver88
    elif randomcar == "89":
        if Driver89:
            return Driver89
        return False
    elif randomcar == "91":
        if Driver91:
            return Driver91
    elif randomcar == "93":
        if Driver93:
            return Driver93
    elif randomcar == "95":
        if Driver95:
            return Driver95
    elif randomcar == "96":
        if Driver96:
            return Driver96
    elif randomcar == "98":
        if Driver98:
            return Driver98
    elif randomcar == "97":
        if Driver97:
            return Driver97
    elif randomcar == "99":
        if Driver99:
            return Driver99
    else:
        pass


def standing(mylist):
    #returnstr = "POINTS STANDINGS"
    #returnstr += '\n'
    returnstr = ""
    standings = {}
    for i in mylist:
        car = assign(i)
        if car:
            standings[i] = car.dvr.pts

    standings_sorted = sorted(standings, key=standings.get, reverse = True)
    x = 0
    for i in standings_sorted:
        x += 1
        car = assign(i)
        if car and car.dvr.pts > 0:
            returnstr += "#" + str(x) + ") " + " " + i + " " + car.dvr.name + " | Points: " + str(car.dvr.pts) + " | Wins: " + str(car.dvr.wins) + " | Top 5's: " + str(car.dvr.topfives) + " | Top 10's: " + str(car.dvr.toptens) + " |  Races Completed: " + str(car.dvr.races) + '\n'
    return returnstr

def top_five_standing(mylist):
    returnstr = "TOP 5 IN THE POINTS STANDINGS"
    returnstr += '\n'
    standings = {}
    for i in mylist:
        car = assign(i)
        standings[i] = car.dvr.pts

    standings_sorted = sorted(standings, key=standings.get, reverse = True)
    x = 0
    block = 0
    x = 0
    for i in standings_sorted:
        x += 1
        block += 1
        car = assign(i)
        if block < 6:
            returnstr += "#" + str(x) + ") " + " " + i + " " + car.dvr.name + " | Points: " + str(
                car.dvr.pts) + " | Wins: " + str(car.dvr.wins) + " | Top 5's: " + str(
                car.dvr.topfives) + " | Top 10's: " + str(car.dvr.toptens) + " |  Races Completed: " + str(
                car.dvr.races) + '\n'
    return returnstr

def champion(mylist, year):

    standings = {}
    for i in mylist:
        car = assign(i)
        standings[i] = car.dvr.pts

    standings_sorted = sorted(standings, key=standings.get, reverse = True)
    x = 0
    block = 0
    returnstr = ""
    returnstr += "YOUR " + str(year) + " CHAMPION IS: " + assign(standings_sorted[0]).dvr.name
    returnstr += '\n'
    assign(standings_sorted[0]).dvr.titles += 1
    returnstr +=  "FINAL STANDINGS"
    returnstr += '\n'
    x = 0
    for i in standings_sorted:
        x += 1
        car = assign(i)
        if car.dvr.pts > 0:
            returnstr += "#" + str(x) + ") " + " " + i + " " + car.dvr.name + " | Points: " + str(
                car.dvr.pts) + " | Wins: " + str(car.dvr.wins) + " | Top 5's: " + str(
                car.dvr.topfives) + " | Top 10's: " + str(car.dvr.toptens) + " |  Races Completed: " + str(
                car.dvr.races) + '\n'
    return returnstr

def race():
    i = 0
    odds = []
    for o in range(1,101):
        odds.append(o)
    elite = ["6", "8", "12", "17", "20", "24", "29", "48", "97"]
    upperpack = ["2", "5", "9", "16", "38", "99"]
    midpack = ["01", "15", "18", "19", "25", "31", "40", "42", "88"]
    lowpack = ["07", "0", "10", "11", "21", "22", "41", "43", "77"]
    startandpark = ["4", "7", "32", "45", "49"]
    parttime = ["09", "14", "36", "37", "44", "50", "66", "91"]
    deepparttime = ["00", "08", "1", "39", "55", "89"]
    tempsum = len(elite)+len(upperpack)+len(midpack)
    tempcount = 0
    print("tge ")
    for i in range(1, 41):
        if i < 26:
            if len(elite) > 0:
                val = odds.pop(random.randrange(len(odds)))
                if val >= 40:
                    randomcar = elite.pop(random.randrange(len(elite)))
                if val >= 20 and val < 40:
                    if len(upperpack) > 0:
                        randomcar = upperpack.pop(random.randrange(len(upperpack)))
                    else:
                        randomcar = elite.pop(random.randrange(len(elite)))

                if val >= 5 and val < 20:
                    if len(midpack) > 0:
                        randomcar = midpack.pop(random.randrange(len(midpack)))
                    else:
                        if len(upperpack) > 0:
                            randomcar = upperpack.pop(random.randrange(len(upperpack)))
                        else:
                            randomcar = elite.pop(random.randrange(len(elite)))


                if val < 5:
                    if len(lowpack) > 0:
                        randomcar = lowpack.pop(random.randrange(len(lowpack)))
                    else:
                        if len(midpack) > 0:
                            randomcar = midpack.pop(random.randrange(len(midpack)))
                        else:
                            if len(upperpack) > 0:
                                randomcar = upperpack.pop(random.randrange(len(upperpack)))
                            else:
                                randomcar = elite.pop(random.randrange(len(elite)))

            else:

                if len(upperpack) > 0:
                    randomcar = upperpack.pop(random.randrange(len(upperpack)))
                else:
                    if len(midpack) > 0:
                        randomcar = midpack.pop(random.randrange(len(midpack)))
                    else:
                        if len(parttime) > 0:
                            randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                        else:
                            if len(lowpack) > 0:
                                randomcar = lowpack.pop(random.randrange(len(lowpack)))



        if i >= 26:
            if len(lowpack) > 0:
                val = odds.pop(random.randrange(len(odds)))
                if val >= 30:
                    randomcar = lowpack.pop(random.randrange(len(lowpack)))
                else:
                    if len(startandpark) > 0:
                        randomcar = startandpark.pop(random.randrange(len(startandpark)))
                    else:
                        randomcar = lowpack.pop(random.randrange(len(lowpack)))
            else:
                if len(startandpark) > 0:
                    randomcar = startandpark.pop(random.randrange(len(startandpark)))
                else:
                    if len(upperpack) > 0:
                        randomcar = upperpack.pop(random.randrange(len(upperpack)))
                    else:
                        if len(midpack) > 0:
                            randomcar = midpack.pop(random.randrange(len(midpack)))
                        else:
                            if len(lowpack) > 0:
                                randomcar = lowpack.pop(random.randrange(len(lowpack)))
                            else:
                                if len(elite) > 0:
                                    randomcar = elite.pop(random.randrange(len(elite)))
                                else:
                                    if val > 40:
                                        if len(parttime) > 0:
                                            randomcar = parttime.pop(random.randrange(len(parttime)))
                                        else:
                                            randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                    else:
                                        if len(deepparttime) > 0:
                                            randomcar = deepparttime.pop(random.randrange(len(deepparttime)))
                                        else:
                                            randomcar = parttime.pop(random.randrange(len(parttime)))



        carvalue = assign(randomcar)


        if i == 1:
            print(randomcar, "winner is")
            carvalue.dvr.pts += 180
            carvalue.dvr.wins += 1
            carvalue.dvr.topfives += 1
            carvalue.dvr.toptens += 1
        if (i >= 2) and (i < 6):
            carvalue.dvr.pts += 175 - (5*(i-1))
            carvalue.dvr.topfives += 1
            carvalue.dvr.toptens += 1
        if i == 6:
            carvalue.dvr.pts += 175 - (5 * (i - 1))
        if i == 7:
            carvalue.dvr.pts += 175 - (5 * (i - 1)) + 1
        if (i > 7) and (i < 11):
            carvalue.dvr.pts += 175 - (5 * (i - 1)) + 3
            carvalue.dvr.toptens += 1
        if (i >= 11) and (i < 21):
            tempcount += 1
            carvalue.dvr.pts += 133 - (3 * (tempcount))
        if i >= 21:
            tempcount += 1
            carvalue.dvr.pts += 133 - (3 * (tempcount))
        carvalue.dvr.races += 1
        carvalue.dvr.totalraces += 1
        #randomcar = ''.join(str(x) for x in randomcar)

        if i in [1, 21, 31, 41]:
            print(
                "{}st Place ---------------------------------------------------------------------------- ".format(
                    i))
        elif i in [2, 12, 22, 32, 42]:
            print(
                "{}nd Place ---------------------------------------------------------------------------- ".format(
                    i))
        elif i in [3, 13, 23, 33, 43]:
            print(
                "{}rd Place ---------------------------------------------------------------------------- ".format(
                    i))
        else:
            print(
                "{}th Place ---------------------------------------------------------------------------- ".format(
                    i))

        finish1 = order(i, randomcar)


def main():
    year = 2020
    week = 1

    while True:
        if week % 37 == 0:
            print(champion(mylist, year))
            week = 1
            year += 1
            print("THIS CONCLUDES THE SEASON.")
        '''
        print("kaseys points are", Driver9.dvr.pts)
        print("kaseys wins are", Driver9.dvr.wins)
        print("kaseys topfives are", Driver9.dvr.topfives)
        print("kaseys toptens are", Driver9.dvr.toptens)
        '''
        print("===================================================")
        print("YEAR: ", year)
        print("WEEK: ", week)
        if week != 1:
            print(top_five_standing(mylist))
        print("===================================================")
        input("Are You Ready? ")
        week += 1

        raceresults = race()
        print(standing(mylist))
        False

#main()


